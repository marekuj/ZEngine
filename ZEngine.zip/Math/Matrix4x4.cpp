#include "Matrix4x4.h"

#define _USE_MATH_DEFINES
#include <cmath>

float Matrix4x4::PI_Buffer=(float)3.14159265359/180;

#if(IOSTREAN_ON)
	using std::ostream;
	using std::istream;
	using std::cout;
	using std::endl;
	ostream& operator << (ostream & out, const Matrix4x4 &Zen)
	{
		out<<"[1,1]: "<<Zen.cell[0]<<" [1,2]: "<<Zen.cell[4]<<" [1,3]: "<<Zen.cell[8]<<" [1,4]: "<<Zen.cell[12]<<endl
		   <<"[1,1]: "<<Zen.cell[1]<<" [1,2]: "<<Zen.cell[5]<<" [1,3]: "<<Zen.cell[9]<<" [1,4]: "<<Zen.cell[13]<<endl
		   <<"[1,1]: "<<Zen.cell[2]<<" [1,2]: "<<Zen.cell[6]<<" [1,3]: "<<Zen.cell[10]<<" [1,4]: "<<Zen.cell[14]<<endl
		   <<"[1,1]: "<<Zen.cell[3]<<" [1,2]: "<<Zen.cell[7]<<" [1,3]: "<<Zen.cell[11]<<" [1,4]: "<<Zen.cell[15]<<endl;
		return out;
	}
	istream& operator >> (istream & in,Matrix4x4 &Zen)
	{
		cout<<"Wprowac [1,1]: "; in>>Zen.cell[0];
		cout<<"Wprowac [1,2]: "; in>>Zen.cell[4];
		cout<<"Wprowac [1,3]: "; in>>Zen.cell[8];
		cout<<"Wprowac [1,4]: "; in>>Zen.cell[12];
		cout<<"Wprowac [2,1]: "; in>>Zen.cell[1];
		cout<<"Wprowac [2,2]: "; in>>Zen.cell[5];
		cout<<"Wprowac [2,3]: "; in>>Zen.cell[9];
		cout<<"Wprowac [2,4]: "; in>>Zen.cell[13];
		cout<<"Wprowac [3,1]: "; in>>Zen.cell[2];
		cout<<"Wprowac [3,2]: "; in>>Zen.cell[6];
		cout<<"Wprowac [3,3]: "; in>>Zen.cell[10];
		cout<<"Wprowac [3,4]: "; in>>Zen.cell[14];
		cout<<"Wprowac [4,1]: "; in>>Zen.cell[3];
		cout<<"Wprowac [4,2]: "; in>>Zen.cell[7];
		cout<<"Wprowac [4,3]: "; in>>Zen.cell[11];
		cout<<"Wprowac [4,4]: "; in>>Zen.cell[15];
		return in;
	}
#endif
bool operator==(const Matrix4x4 &L,const Matrix4x4 &P)
{
	for(int i=0; i<16; i++)
	{
		if(L.cell[i]!=P.cell[i])
			return false;
	}
	return true;
}
bool operator!=(const Matrix4x4 &L,const Matrix4x4 &P)
{
	for(int i=0; i<16; i++)
	{
		if(L.cell[i]!=P.cell[i])
			return true;
	}
	return false;
}
Matrix4x4 operator*(float Scalar, const Matrix4x4 &Zen)
{
	return Matrix4x4(Zen.cell[0]*Scalar,Zen.cell[1]*Scalar,Zen.cell[2]*Scalar,Zen.cell[3]*Scalar,
					 Zen.cell[4]*Scalar,Zen.cell[5]*Scalar,Zen.cell[6]*Scalar,Zen.cell[7]*Scalar,
					 Zen.cell[8]*Scalar,Zen.cell[9]*Scalar,Zen.cell[10]*Scalar,Zen.cell[11]*Scalar,
					 Zen.cell[12]*Scalar,Zen.cell[13]*Scalar,Zen.cell[14]*Scalar,Zen.cell[15]*Scalar);
}
Matrix4x4::Matrix4x4(void)
{
	//LoadIdentity
	memset(cell, 0, 16*sizeof(float));
	cell[0]=1.0f;
	cell[5]=1.0f;
	cell[10]=1.0f;
	cell[15]=1.0f;
}
Matrix4x4::Matrix4x4(float c00, float c10, float c20, float c30,
					 float c01, float c11, float c21, float c31,
					 float c02, float c12, float c22, float c32,
					 float c03, float c13, float c23, float c33)
{
	cell[0]=c00;	cell[1]=c10;	cell[2]=c20;	cell[3]=c30;
	cell[4]=c01;	cell[5]=c11;	cell[6]=c21;	cell[7]=c31;
	cell[8]=c02;	cell[9]=c12;	cell[10]=c22;	cell[11]=c32;
	cell[12]=c03;	cell[13]=c13;	cell[14]=c23;	cell[15]=c33;
}
Matrix4x4::Matrix4x4(const float *Zen)
{
	memcpy(cell, Zen, 16*sizeof(float));
}
Matrix4x4::Matrix4x4(const Matrix4x4 &Zen)
{
	memcpy(cell, Zen.cell, 16*sizeof(float));
}
Matrix4x4::~Matrix4x4(void)
{
}
void Matrix4x4::LoadZero(void)
{
	memset(cell, 0, 16*sizeof(float));
}
void Matrix4x4::LoadIdentity(void)
{
	memset(cell, 0, 16*sizeof(float));
	cell[0]=1.0f;
	cell[5]=1.0f;
	cell[10]=1.0f;
	cell[15]=1.0f;
}
void Matrix4x4::SetCell(int Position, float Value)
{
	if(Position>=0 && Position<=15)
		cell[Position]=Value;
}
float Matrix4x4::GetCell(int Position)
{
	if(Position>=0 && Position<=15)
		return cell[Position];
	return 0.0f;
}
Vector4D Matrix4x4::GetRow(int Position)
{
	switch(Position)
	{
	case 0:
		return Vector4D(cell[0], cell[4], cell[8], cell[12]);
		break;
	case 1:
		return Vector4D(cell[1], cell[5], cell[9], cell[13]);
		break;
	case 2:
		return Vector4D(cell[2], cell[6], cell[10], cell[14]);
		break;
	case 3:
		return Vector4D(cell[3], cell[7], cell[11], cell[15]);
		break;
	default: 
		return Vector4D(0.0f, 0.0f, 0.0f, 0.0f);
	}
}
Vector4D Matrix4x4::GetColumn(int Position)
{
	switch(Position)
	{
	case 0:
		return Vector4D(cell[0], cell[1], cell[2], cell[3]);
		break;
	case 1:
		return Vector4D(cell[4], cell[5], cell[6], cell[7]);
		break;
	case 2:
		return Vector4D(cell[8], cell[9], cell[10], cell[11]);
		break;
	case 3:
		return Vector4D(cell[12], cell[13], cell[14], cell[15]);
		break;
	default: 
		return Vector4D(0.0f, 0.0f, 0.0f, 0.0f);
	}
}
void Matrix4x4::Invert(void)
{
	*this=GetInverseTranspose();
	Transpose();
}
Matrix4x4 Matrix4x4::GetInverse(void)
{
	Matrix4x4 Buf=GetInverseTranspose();
	Buf.Transpose();
	return Buf;
}
void Matrix4x4::Transpose(void)
{
	*this=GetTranspose();
}
Matrix4x4 Matrix4x4::GetTranspose(void)
{
	return Matrix4x4(cell[0],cell[4],cell[ 8],cell[12],
					 cell[1],cell[5],cell[ 9],cell[13],
					 cell[2],cell[6],cell[10],cell[14],
					 cell[3],cell[7],cell[11],cell[15]);
}
void Matrix4x4::InvertTranspose(void)
{
	*this=GetInverseTranspose();
}
Matrix4x4 Matrix4x4::GetInverseTranspose(void)
{
	Matrix4x4 Buf;

	float tmp[12];												//temporary pair storage
	float det;													//determinant

	//calculate pairs for first 8 elements (cofactors)
	tmp[0] = cell[10] * cell[15];
	tmp[1] = cell[11] * cell[14];
	tmp[2] = cell[9] * cell[15];
	tmp[3] = cell[11] * cell[13];
	tmp[4] = cell[9] * cell[14];
	tmp[5] = cell[10] * cell[13];
	tmp[6] = cell[8] * cell[15];
	tmp[7] = cell[11] * cell[12];
	tmp[8] = cell[8] * cell[14];
	tmp[9] = cell[10] * cell[12];
	tmp[10] = cell[8] * cell[13];
	tmp[11] = cell[9] * cell[12];

	//calculate first 8 elements (cofactors)
	Buf.SetCell(0,tmp[0]*cell[5]+tmp[3]*cell[6]+tmp[4]*cell[7]
				-tmp[1]*cell[5]-tmp[2]*cell[6]-tmp[5]*cell[7]);

	Buf.SetCell(1,tmp[1]*cell[4]+tmp[6]*cell[6]+tmp[9]*cell[7]
				-tmp[0]*cell[4]-tmp[7]*cell[6]-tmp[8]*cell[7]);

	Buf.SetCell(2,tmp[2]*cell[4]+tmp[7]*cell[5]+tmp[10]*cell[7]
				-tmp[3]*cell[4]-tmp[6]*cell[5]-tmp[11]*cell[7]);

	Buf.SetCell(3,tmp[5]*cell[4]+tmp[8]*cell[5]+tmp[11]*cell[6]
				-tmp[4]*cell[4]-tmp[9]*cell[5]-tmp[10]*cell[6]);

	Buf.SetCell(4,tmp[1]*cell[1]+tmp[2]*cell[2]+tmp[5]*cell[3]
				-tmp[0]*cell[1]-tmp[3]*cell[2]-tmp[4]*cell[3]);

	Buf.SetCell(5,tmp[0]*cell[0]+tmp[7]*cell[2]+tmp[8]*cell[3]
				-tmp[1]*cell[0]-tmp[6]*cell[2]-tmp[9]*cell[3]);

	Buf.SetCell(6,tmp[3]*cell[0]+tmp[6]*cell[1]+tmp[11]*cell[3]
				-tmp[2]*cell[0]-tmp[7]*cell[1]-tmp[10]*cell[3]);

	Buf.SetCell(7,tmp[4]*cell[0]+tmp[9]*cell[1]+tmp[10]*cell[2]
				-tmp[5]*cell[0]-tmp[8]*cell[1]-tmp[11]*cell[2]);

	//calculate pairs for second 8 elements (cofactors)
	tmp[0] = cell[2]*cell[7];
	tmp[1] = cell[3]*cell[6];
	tmp[2] = cell[1]*cell[7];
	tmp[3] = cell[3]*cell[5];
	tmp[4] = cell[1]*cell[6];
	tmp[5] = cell[2]*cell[5];
	tmp[6] = cell[0]*cell[7];
	tmp[7] = cell[3]*cell[4];
	tmp[8] = cell[0]*cell[6];
	tmp[9] = cell[2]*cell[4];
	tmp[10] = cell[0]*cell[5];
	tmp[11] = cell[1]*cell[4];

	//calculate second 8 elements (cofactors)
	Buf.SetCell(8,tmp[0]*cell[13]+tmp[3]*cell[14]+tmp[4]*cell[15]
				-tmp[1]*cell[13]-tmp[2]*cell[14]-tmp[5]*cell[15]);

	Buf.SetCell(9,tmp[1]*cell[12]+tmp[6]*cell[14]+tmp[9]*cell[15]
				-tmp[0]*cell[12]-tmp[7]*cell[14]-tmp[8]*cell[15]);

	Buf.SetCell(10,tmp[2]*cell[12]+tmp[7]*cell[13]+tmp[10]*cell[15]
				-tmp[3]*cell[12]-tmp[6]*cell[13]-tmp[11]*cell[15]);

	Buf.SetCell(11,tmp[5]*cell[12]+tmp[8]*cell[13]+tmp[11]*cell[14]
				-tmp[4]*cell[12]-tmp[9]*cell[13]-tmp[10]*cell[14]);

	Buf.SetCell(12,tmp[2]*cell[10]+tmp[5]*cell[11]+tmp[1]*cell[9]
				-tmp[4]*cell[11]-tmp[0]*cell[9]-tmp[3]*cell[10]);

	Buf.SetCell(13,tmp[8]*cell[11]+tmp[0]*cell[8]+tmp[7]*cell[10]
				-tmp[6]*cell[10]-tmp[9]*cell[11]-tmp[1]*cell[8]);

	Buf.SetCell(14,tmp[6]*cell[9]+tmp[11]*cell[11]+tmp[3]*cell[8]
				-tmp[10]*cell[11]-tmp[2]*cell[8]-tmp[7]*cell[9]);

	Buf.SetCell(15,tmp[10]*cell[10]+tmp[4]*cell[8]+tmp[9]*cell[9]
				-tmp[8]*cell[9]-tmp[11]*cell[10]-tmp[5]*cell[8]);

	// calculate determinant
	det	= cell[0]*Buf.GetCell(0)+cell[1]*Buf.GetCell(1)
		  +cell[2]*Buf.GetCell(2)+cell[3]*Buf.GetCell(3);

	if(det==0.0f)
	{
		Matrix4x4 id;
		return id;
	}
	Buf=Buf/det;
	return Buf;
}
void Matrix4x4::AffineInvert(void)
{
	*this=GetAffineInverse();
}
Matrix4x4 Matrix4x4::GetAffineInverse(void)
{
	return Matrix4x4(cell[0],cell[4],cell[8],0.0f,
					 cell[1],cell[5],cell[9],0.0f,
					 cell[2],cell[6],cell[10],0.0f,
					 -(cell[0]*cell[12]+cell[1]*cell[13]+cell[2]*cell[14]),
					 -(cell[4]*cell[12]+cell[5]*cell[13]+cell[6]*cell[14]),
					 -(cell[8]*cell[12]+cell[9]*cell[13]+cell[10]*cell[14]),
					 1.0f);
}
void Matrix4x4::AffineInvertTranspose(void)
{
	*this=GetAffineInverseTranspose();
}
Matrix4x4 Matrix4x4::GetAffineInverseTranspose(void)
{
	return Matrix4x4(cell[0],cell[1],cell[2],-(cell[0]*cell[12]+cell[1]*cell[13]+cell[2]*cell[14]),
					 cell[4],cell[5],cell[6],-(cell[4]*cell[12]+cell[5]*cell[13]+cell[6]*cell[14]),
					 cell[8],cell[9],cell[10],-(cell[8]*cell[12]+cell[9]*cell[13]+cell[10]*cell[14]),
					 0.0f, 0.0f, 0.0f, 1.0f);
}
void Matrix4x4::SetTranslation(Vector3D &Translation)
{
	//LoadIdentity
	memset(cell, 0, 16*sizeof(float));
	cell[0]=1.0f;
	cell[5]=1.0f;
	cell[10]=1.0f;
	cell[15]=1.0f;
	//Translation
	cell[12]=Translation.GetX();
	cell[13]=Translation.GetY();
	cell[14]=Translation.GetZ();
}
void Matrix4x4::SetScale(Vector3D &Scale)
{
	//LoadIdentity
	memset(cell, 0, 16*sizeof(float));
	cell[0]=1.0f;
	cell[5]=1.0f;
	cell[10]=1.0f;
	cell[15]=1.0f;
	//Scale
	cell[0]=Scale.GetX();
	cell[5]=Scale.GetY();
	cell[10]=Scale.GetZ();
}
void Matrix4x4::SetUniformScale(float Scale)
{
	//LoadIdentity
	memset(cell, 0, 16*sizeof(float));
	cell[0]=1.0f;
	cell[5]=1.0f;
	cell[10]=1.0f;
	cell[15]=1.0f;
	//Scale
	cell[0]=Scale;
	cell[5]=Scale;
	cell[10]=Scale;
}
void Matrix4x4::SetRotationAxis(double Angle, Vector3D &Axis)
{
	Vector3D u(Axis.GetNormalized());

	float sinAngle=(float)sin(Angle*PI_Buffer);
	float cosAngle=(float)cos(Angle*PI_Buffer);
	float oneMinusCosAngle=1.0f-cosAngle;

	//LoadIdentity
	memset(cell, 0, 16*sizeof(float));
	cell[0]=1.0f;
	cell[5]=1.0f;
	cell[10]=1.0f;
	cell[15]=1.0f;

	cell[0]=(u.GetX())*(u.GetX()) + cosAngle*(1-(u.GetX())*(u.GetX()));
	cell[4]=(u.GetX())*(u.GetY())*(oneMinusCosAngle) - sinAngle*u.GetZ();
	cell[8]=(u.GetX())*(u.GetZ())*(oneMinusCosAngle) + sinAngle*u.GetY();

	cell[1]=(u.GetX())*(u.GetY())*(oneMinusCosAngle) + sinAngle*u.GetZ();
	cell[5]=(u.GetY())*(u.GetY()) + cosAngle*(1-(u.GetY())*(u.GetY()));
	cell[9]=(u.GetY())*(u.GetZ())*(oneMinusCosAngle) - sinAngle*u.GetX();
	
	cell[2]=(u.GetX())*(u.GetZ())*(oneMinusCosAngle) - sinAngle*u.GetY();
	cell[6]=(u.GetY())*(u.GetZ())*(oneMinusCosAngle) + sinAngle*u.GetX();
	cell[10]=(u.GetZ())*(u.GetZ()) + cosAngle*(1-(u.GetZ())*(u.GetZ()));
}
void Matrix4x4::SetRotationX( double Angle)
{
	//LoadIdentity
	memset(cell, 0, 16*sizeof(float));
	cell[0]=1.0f;
	cell[5]=1.0f;
	cell[10]=1.0f;
	cell[15]=1.0f;
	//SetRotationX
	cell[5]=(float)cos(Angle*PI_Buffer);
	cell[6]=(float)sin(Angle*PI_Buffer);
	cell[9]=-cell[6];
	cell[10]=cell[5];
}
void Matrix4x4::SetRotationY( double Angle)
{
	//LoadIdentity
	memset(cell, 0, 16*sizeof(float));
	cell[0]=1.0f;
	cell[5]=1.0f;
	cell[10]=1.0f;
	cell[15]=1.0f;
	//SetRotationY
	cell[0]=(float)cos(Angle*PI_Buffer);
	cell[2]=-(float)sin(Angle*PI_Buffer);
	cell[8]=-cell[2];
	cell[10]=cell[0];
}
void Matrix4x4::SetRotationZ( double Angle)
{
	//LoadIdentity
	memset(cell, 0, 16*sizeof(float));
	cell[0]=1.0f;
	cell[5]=1.0f;
	cell[10]=1.0f;
	cell[15]=1.0f;
	//SetRotationZ
	cell[0]=(float)cos(Angle*PI_Buffer);
	cell[1]=(float)sin(Angle*PI_Buffer);
	cell[4]=-cell[1];
	cell[5]=cell[0];

}
void Matrix4x4::SetRotationEuler( double AngleX, double AngleY, double AngleZ)
{
	//LoadIdentity
	memset(cell, 0, 16*sizeof(float));
	cell[0]=1.0f;
	cell[5]=1.0f;
	cell[10]=1.0f;
	cell[15]=1.0f;
	//SetRotationEuler
	double cr = cos( AngleX*PI_Buffer );
	double sr = sin( AngleX*PI_Buffer );
	double cp = cos( AngleY*PI_Buffer );
	double sp = sin( AngleY*PI_Buffer );
	double cy = cos( AngleZ*PI_Buffer );
	double sy = sin( AngleZ*PI_Buffer );

	cell[0] = ( float )( cp*cy );
	cell[1] = ( float )( cp*sy );
	cell[2] = ( float )( -sp );

	double srsp = sr*sp;
	double crsp = cr*sp;

	cell[4] = ( float )( srsp*cy-cr*sy );
	cell[5] = ( float )( srsp*sy+cr*cy );
	cell[6] = ( float )( sr*cp );

	cell[8] = ( float )( crsp*cy+sr*sy );
	cell[9] = ( float )( crsp*sy-sr*cy );
	cell[10] = ( float )( cr*cp );
}
void Matrix4x4::SetPerspective(float Left, float Right, float Bottom, float Top, float n, float f)
{
	float nudge=0.999f;		//prevent artifacts with infinite far plane

	//LoadZero
	memset(cell, 0, 16*sizeof(float));

	//check for division by 0
	if(Left==Right || Top==Bottom || n==f)
		return;

	cell[0]=(2*n)/(Right-Left);

	cell[5]=(2*n)/(Top-Bottom);

	cell[8]=(Right+Left)/(Right-Left);
	cell[9]=(Top+Bottom)/(Top-Bottom);

	if(f!=-1)
	{
		cell[10]=-(f+n)/(f-n);
	}
	else		//if f==-1, use an infinite far plane
	{
		cell[10]=-nudge;
	}

	cell[11]=-1;

	if(f!=-1)
	{
		cell[14]=-(2*f*n)/(f-n);
	}
	else		//if f==-1, use an infinite far plane
	{
		cell[14]=-2*n*nudge;
	}
}
void Matrix4x4::SetPerspective(float Fovy, float Aspect, float n, float f)
{
	float Left, Right, Top, Bottom;

	//convert fov from degrees to radians
	Fovy*=PI_Buffer;

	Top=n*tanf(Fovy/2.0f);
	Bottom=-Top;

	Left=Aspect*Bottom;
	Right=Aspect*Top;

	float nudge=0.999f;		//prevent artifacts with infinite far plane

	//LoadZero
	memset(cell, 0, 16*sizeof(float));

	//check for division by 0
	if(Left==Right || Top==Bottom || n==f)
		return;

	cell[0]=(2*n)/(Right-Left);

	cell[5]=(2*n)/(Top-Bottom);

	cell[8]=(Right+Left)/(Right-Left);
	cell[9]=(Top+Bottom)/(Top-Bottom);

	if(f!=-1)
	{
		cell[10]=-(f+n)/(f-n);
	}
	else		//if f==-1, use an infinite far plane
	{
		cell[10]=-nudge;
	}

	cell[11]=-1;

	if(f!=-1)
	{
		cell[14]=-(2*f*n)/(f-n);
	}
	else		//if f==-1, use an infinite far plane
	{
		cell[14]=-2*n*nudge;
	}
}
void Matrix4x4::SetOrtho(float Left, float Right, float Bottom, float Top, float n, float f)
{
	//LoadIdentity
	memset(cell, 0, 16*sizeof(float));
	cell[0]=1.0f;
	cell[5]=1.0f;
	cell[10]=1.0f;
	cell[15]=1.0f;

	cell[0]=2.0f/(Right-Left);

	cell[5]=2.0f/(Top-Bottom);

	cell[10]=-2.0f/(f-n);

	cell[12]=-(Right+Left)/(Right-Left);
	cell[13]=-(Top+Bottom)/(Top-Bottom);
	cell[14]=-(f+n)/(f-n);
}
void Matrix4x4::SetLookAt(Vector3D Eye,Vector3D Center,Vector3D Up)
{
	Vector3D X;
	Center=Eye-Center;
	Center.Normalize();

	X=CrossProduct(Up,Center);
	Up=CrossProduct(Center,X);
	
	X.Normalize();
	Up.Normalize();

	cell[0]=X.GetX();	
	cell[4]=X.GetY();	
	cell[8]=X.GetZ();	
	cell[12]=-X.GetX()*Eye.GetX()-X.GetY()*Eye.GetY()-X.GetZ()*Eye.GetZ();	

	cell[1]=Up.GetX();	
	cell[5]=Up.GetY();	
	cell[9]=Up.GetZ();	
	cell[13]=-Up.GetX()*Eye.GetX()-Up.GetY()*Eye.GetY()-Up.GetZ()*Eye.GetZ();	

	cell[2]=Center.GetX();	
	cell[6]=Center.GetY();	
	cell[10]=Center.GetZ();	
	cell[14]=-Center.GetX()*Eye.GetX()-Center.GetY()*Eye.GetY()-Center.GetZ()*Eye.GetZ();	

	cell[3]=0.0f;	
	cell[7]=0.0f;	
	cell[11]=0.0f;	
	cell[15]=1.0f;	
}
void Matrix4x4::SetTranslationPart(Vector3D &Translation)
{
	cell[12]=Translation.GetX();
	cell[13]=Translation.GetY();
	cell[14]=Translation.GetZ();
}
void Matrix4x4::SetRotationPartEuler(double AngleX, double AngleY, double AngleZ)
{
	double cr = cos( AngleX*PI_Buffer );
	double sr = sin( AngleX*PI_Buffer );
	double cp = cos( AngleY*PI_Buffer );
	double sp = sin( AngleY*PI_Buffer );
	double cy = cos( AngleZ*PI_Buffer );
	double sy = sin( AngleZ*PI_Buffer );

	cell[0] = ( float )( cp*cy );
	cell[1] = ( float )( cp*sy );
	cell[2] = ( float )( -sp );

	double srsp = sr*sp;
	double crsp = cr*sp;

	cell[4] = ( float )( srsp*cy-cr*sy );
	cell[5] = ( float )( srsp*sy+cr*cy );
	cell[6] = ( float )( sr*cp );

	cell[8] = ( float )( crsp*cy+sr*sy );
	cell[9] = ( float )( crsp*sy-sr*cy );
	cell[10] = ( float )( cr*cp );
}
void Matrix4x4::SetRotationPartEuler(Vector3D &Rotations)
{
	double cr = cos( Rotations.GetX()*PI_Buffer );
	double sr = sin( Rotations.GetX()*PI_Buffer );
	double cp = cos( Rotations.GetY()*PI_Buffer );
	double sp = sin( Rotations.GetY()*PI_Buffer );
	double cy = cos( Rotations.GetZ()*PI_Buffer );
	double sy = sin( Rotations.GetZ()*PI_Buffer );

	cell[0] = ( float )( cp*cy );
	cell[1] = ( float )( cp*sy );
	cell[2] = ( float )( -sp );

	double srsp = sr*sp;
	double crsp = cr*sp;

	cell[4] = ( float )( srsp*cy-cr*sy );
	cell[5] = ( float )( srsp*sy+cr*cy );
	cell[6] = ( float )( sr*cp );

	cell[8] = ( float )( crsp*cy+sr*sy );
	cell[9] = ( float )( crsp*sy-sr*cy );
	cell[10] = ( float )( cr*cp );
}
void Matrix4x4::RotateVector3D(Vector3D &Zen)
{
	Zen.Set(cell[0]*Zen.GetX()+cell[4]*Zen.GetY()+cell[8]*Zen.GetZ(),
					cell[1]*Zen.GetX()+cell[5]*Zen.GetY()+cell[9]*Zen.GetZ(),
					cell[2]*Zen.GetX()+cell[6]*Zen.GetY()+cell[10]*Zen.GetZ());
}
void Matrix4x4::InverseRotateVector3D(Vector3D &Zen)
{
	Zen.Set(cell[0]*Zen.GetX()+cell[1]*Zen.GetY()+cell[2]*Zen.GetZ(),
					cell[4]*Zen.GetX()+cell[5]*Zen.GetY()+cell[6]*Zen.GetZ(),
					cell[8]*Zen.GetX()+cell[9]*Zen.GetY()+cell[10]*Zen.GetZ());
}
Vector3D Matrix4x4::GetRotatedVector3D(Vector3D &Zen)
{
	return Vector3D(cell[0]*Zen.GetX()+cell[4]*Zen.GetY()+cell[8]*Zen.GetZ(),
					cell[1]*Zen.GetX()+cell[5]*Zen.GetY()+cell[9]*Zen.GetZ(),
					cell[2]*Zen.GetX()+cell[6]*Zen.GetY()+cell[10]*Zen.GetZ());
}
Vector3D Matrix4x4::GetInverseRotatedVector3D(Vector3D &Zen)
{
	return Vector3D(cell[0]*Zen.GetX()+cell[1]*Zen.GetY()+cell[2]*Zen.GetZ(),
					cell[4]*Zen.GetX()+cell[5]*Zen.GetY()+cell[6]*Zen.GetZ(),
					cell[8]*Zen.GetX()+cell[9]*Zen.GetY()+cell[10]*Zen.GetZ());
}
void Matrix4x4::TranslateVector3D(Vector3D &Zen)
{
	Zen.Set(Zen.GetX()+cell[12], Zen.GetY()+cell[13], Zen.GetZ()+cell[14]);
}
void Matrix4x4::InverseTranslateVector3D(Vector3D &Zen)
{
	Zen.Set(Zen.GetX()-cell[12], Zen.GetY()-cell[13], Zen.GetZ()-cell[14]);
}
Vector3D Matrix4x4::GetTranslatedVector3D(Vector3D &Zen)
{
	return Vector3D(Zen.GetX()+cell[12], Zen.GetY()+cell[13], Zen.GetZ()+cell[14]);
}
Vector3D Matrix4x4::GetInverseTranslatedVector3D(Vector3D &Zen)
{
	return Vector3D(Zen.GetX()-cell[12], Zen.GetY()-cell[13], Zen.GetZ()-cell[14]);
}
Matrix4x4 Matrix4x4::operator+(const Matrix4x4 &Zen) const
{
	return Matrix4x4(cell[0]+Zen.cell[0],cell[1]+Zen.cell[1],cell[2]+Zen.cell[2],cell[3]+Zen.cell[3],
					 cell[4]+Zen.cell[4],cell[5]+Zen.cell[5],cell[6]+Zen.cell[6],cell[7]+Zen.cell[7],
					 cell[8]+Zen.cell[8],cell[9]+Zen.cell[9],cell[10]+Zen.cell[10],cell[11]+Zen.cell[11],
					 cell[12]+Zen.cell[12],cell[13]+Zen.cell[13],cell[14]+Zen.cell[14],cell[15]+Zen.cell[15]);
}
Matrix4x4 Matrix4x4::operator-(const Matrix4x4 &Zen) const
{
	return Matrix4x4(cell[0]-Zen.cell[0],cell[1]-Zen.cell[1],cell[2]-Zen.cell[2],cell[3]-Zen.cell[3],
					 cell[4]-Zen.cell[4],cell[5]-Zen.cell[5],cell[6]-Zen.cell[6],cell[7]-Zen.cell[7],
					 cell[8]-Zen.cell[8],cell[9]-Zen.cell[9],cell[10]-Zen.cell[10],cell[11]-Zen.cell[11],
					 cell[12]-Zen.cell[12],cell[13]-Zen.cell[13],cell[14]-Zen.cell[14],cell[15]-Zen.cell[15]);
}
Matrix4x4 Matrix4x4::operator*(const Matrix4x4 &Zen) const
{
	//Optimise for matrices in which bottom row is (0, 0, 0, 1) in both matrices
	if(	cell[3]==0.0f && cell[7]==0.0f && cell[11]==0.0f && cell[15]==1.0f	&&
		Zen.cell[3]==0.0f && Zen.cell[7]==0.0f &&
		Zen.cell[11]==0.0f && Zen.cell[15]==1.0f)
	{
		return Matrix4x4(	cell[0]*Zen.cell[0]+cell[4]*Zen.cell[1]+cell[8]*Zen.cell[2],
							cell[1]*Zen.cell[0]+cell[5]*Zen.cell[1]+cell[9]*Zen.cell[2],
							cell[2]*Zen.cell[0]+cell[6]*Zen.cell[1]+cell[10]*Zen.cell[2],
							0.0f,
							cell[0]*Zen.cell[4]+cell[4]*Zen.cell[5]+cell[8]*Zen.cell[6],
							cell[1]*Zen.cell[4]+cell[5]*Zen.cell[5]+cell[9]*Zen.cell[6],
							cell[2]*Zen.cell[4]+cell[6]*Zen.cell[5]+cell[10]*Zen.cell[6],
							0.0f,
							cell[0]*Zen.cell[8]+cell[4]*Zen.cell[9]+cell[8]*Zen.cell[10],
							cell[1]*Zen.cell[8]+cell[5]*Zen.cell[9]+cell[9]*Zen.cell[10],
							cell[2]*Zen.cell[8]+cell[6]*Zen.cell[9]+cell[10]*Zen.cell[10],
							0.0f,
							cell[0]*Zen.cell[12]+cell[4]*Zen.cell[13]+cell[8]*Zen.cell[14]+cell[12],
							cell[1]*Zen.cell[12]+cell[5]*Zen.cell[13]+cell[9]*Zen.cell[14]+cell[13],
							cell[2]*Zen.cell[12]+cell[6]*Zen.cell[13]+cell[10]*Zen.cell[14]+cell[14],
							1.0f);
	}
	//Optimise for when bottom row of 1st matrix is (0, 0, 0, 1)
	if(	cell[3]==0.0f && cell[7]==0.0f && cell[11]==0.0f && cell[15]==1.0f)
	{
		return Matrix4x4(	cell[0]*Zen.cell[0]+cell[4]*Zen.cell[1]+cell[8]*Zen.cell[2]+cell[12]*Zen.cell[3],
							cell[1]*Zen.cell[0]+cell[5]*Zen.cell[1]+cell[9]*Zen.cell[2]+cell[13]*Zen.cell[3],
							cell[2]*Zen.cell[0]+cell[6]*Zen.cell[1]+cell[10]*Zen.cell[2]+cell[14]*Zen.cell[3],
							Zen.cell[3],
							cell[0]*Zen.cell[4]+cell[4]*Zen.cell[5]+cell[8]*Zen.cell[6]+cell[12]*Zen.cell[7],
							cell[1]*Zen.cell[4]+cell[5]*Zen.cell[5]+cell[9]*Zen.cell[6]+cell[13]*Zen.cell[7],
							cell[2]*Zen.cell[4]+cell[6]*Zen.cell[5]+cell[10]*Zen.cell[6]+cell[14]*Zen.cell[7],
							Zen.cell[7],
							cell[0]*Zen.cell[8]+cell[4]*Zen.cell[9]+cell[8]*Zen.cell[10]+cell[12]*Zen.cell[11],
							cell[1]*Zen.cell[8]+cell[5]*Zen.cell[9]+cell[9]*Zen.cell[10]+cell[13]*Zen.cell[11],
							cell[2]*Zen.cell[8]+cell[6]*Zen.cell[9]+cell[10]*Zen.cell[10]+cell[14]*Zen.cell[11],
							Zen.cell[11],
							cell[0]*Zen.cell[12]+cell[4]*Zen.cell[13]+cell[8]*Zen.cell[14]+cell[12]*Zen.cell[15],
							cell[1]*Zen.cell[12]+cell[5]*Zen.cell[13]+cell[9]*Zen.cell[14]+cell[13]*Zen.cell[15],
							cell[2]*Zen.cell[12]+cell[6]*Zen.cell[13]+cell[10]*Zen.cell[14]+cell[14]*Zen.cell[15],
							Zen.cell[15]);
	}
	//Optimise for when bottom row of 2nd matrix is (0, 0, 0, 1)
	if(	Zen.cell[3]==0.0f && Zen.cell[7]==0.0f &&
		Zen.cell[11]==0.0f && Zen.cell[15]==1.0f)
	{
		return Matrix4x4(	cell[0]*Zen.cell[0]+cell[4]*Zen.cell[1]+cell[8]*Zen.cell[2],
							cell[1]*Zen.cell[0]+cell[5]*Zen.cell[1]+cell[9]*Zen.cell[2],
							cell[2]*Zen.cell[0]+cell[6]*Zen.cell[1]+cell[10]*Zen.cell[2],
							cell[3]*Zen.cell[0]+cell[7]*Zen.cell[1]+cell[11]*Zen.cell[2],
							cell[0]*Zen.cell[4]+cell[4]*Zen.cell[5]+cell[8]*Zen.cell[6],
							cell[1]*Zen.cell[4]+cell[5]*Zen.cell[5]+cell[9]*Zen.cell[6],
							cell[2]*Zen.cell[4]+cell[6]*Zen.cell[5]+cell[10]*Zen.cell[6],
							cell[3]*Zen.cell[4]+cell[7]*Zen.cell[5]+cell[11]*Zen.cell[6],
							cell[0]*Zen.cell[8]+cell[4]*Zen.cell[9]+cell[8]*Zen.cell[10],
							cell[1]*Zen.cell[8]+cell[5]*Zen.cell[9]+cell[9]*Zen.cell[10],
							cell[2]*Zen.cell[8]+cell[6]*Zen.cell[9]+cell[10]*Zen.cell[10],
							cell[3]*Zen.cell[8]+cell[7]*Zen.cell[9]+cell[11]*Zen.cell[10],
							cell[0]*Zen.cell[12]+cell[4]*Zen.cell[13]+cell[8]*Zen.cell[14]+cell[12],
							cell[1]*Zen.cell[12]+cell[5]*Zen.cell[13]+cell[9]*Zen.cell[14]+cell[13],
							cell[2]*Zen.cell[12]+cell[6]*Zen.cell[13]+cell[10]*Zen.cell[14]+cell[14],
							cell[3]*Zen.cell[12]+cell[7]*Zen.cell[13]+cell[11]*Zen.cell[14]+cell[15]);
	}
	return Matrix4x4(	cell[0]*Zen.cell[0]+cell[4]*Zen.cell[1]+cell[8]*Zen.cell[2]+cell[12]*Zen.cell[3],
						cell[1]*Zen.cell[0]+cell[5]*Zen.cell[1]+cell[9]*Zen.cell[2]+cell[13]*Zen.cell[3],
						cell[2]*Zen.cell[0]+cell[6]*Zen.cell[1]+cell[10]*Zen.cell[2]+cell[14]*Zen.cell[3],
						cell[3]*Zen.cell[0]+cell[7]*Zen.cell[1]+cell[11]*Zen.cell[2]+cell[15]*Zen.cell[3],
						cell[0]*Zen.cell[4]+cell[4]*Zen.cell[5]+cell[8]*Zen.cell[6]+cell[12]*Zen.cell[7],
						cell[1]*Zen.cell[4]+cell[5]*Zen.cell[5]+cell[9]*Zen.cell[6]+cell[13]*Zen.cell[7],
						cell[2]*Zen.cell[4]+cell[6]*Zen.cell[5]+cell[10]*Zen.cell[6]+cell[14]*Zen.cell[7],
						cell[3]*Zen.cell[4]+cell[7]*Zen.cell[5]+cell[11]*Zen.cell[6]+cell[15]*Zen.cell[7],
						cell[0]*Zen.cell[8]+cell[4]*Zen.cell[9]+cell[8]*Zen.cell[10]+cell[12]*Zen.cell[11],
						cell[1]*Zen.cell[8]+cell[5]*Zen.cell[9]+cell[9]*Zen.cell[10]+cell[13]*Zen.cell[11],
						cell[2]*Zen.cell[8]+cell[6]*Zen.cell[9]+cell[10]*Zen.cell[10]+cell[14]*Zen.cell[11],
						cell[3]*Zen.cell[8]+cell[7]*Zen.cell[9]+cell[11]*Zen.cell[10]+cell[15]*Zen.cell[11],
						cell[0]*Zen.cell[12]+cell[4]*Zen.cell[13]+cell[8]*Zen.cell[14]+cell[12]*Zen.cell[15],
						cell[1]*Zen.cell[12]+cell[5]*Zen.cell[13]+cell[9]*Zen.cell[14]+cell[13]*Zen.cell[15],
						cell[2]*Zen.cell[12]+cell[6]*Zen.cell[13]+cell[10]*Zen.cell[14]+cell[14]*Zen.cell[15],
						cell[3]*Zen.cell[12]+cell[7]*Zen.cell[13]+cell[11]*Zen.cell[14]+cell[15]*Zen.cell[15]);
}
Matrix4x4 Matrix4x4::operator*(const float Scalar) const
{
	return Matrix4x4(cell[0]*Scalar,cell[1]*Scalar,cell[2]*Scalar,cell[3]*Scalar,
  	    			 cell[4]*Scalar,cell[5]*Scalar,cell[6]*Scalar,cell[7]*Scalar,
					 cell[8]*Scalar,cell[9]*Scalar,cell[10]*Scalar,cell[11]*Scalar,
					 cell[12]*Scalar,cell[13]*Scalar,cell[14]*Scalar,cell[15]*Scalar);

}
Matrix4x4 Matrix4x4::operator/(const float Scalar) const
{
	if (Scalar==0.0f || Scalar==1.0f) return Matrix4x4(*this);
	return Matrix4x4(cell[0]/Scalar,cell[1]/Scalar,cell[2]/Scalar,cell[3]/Scalar,
  	    			 cell[4]/Scalar,cell[5]/Scalar,cell[6]/Scalar,cell[7]/Scalar,
					 cell[8]/Scalar,cell[9]/Scalar,cell[10]/Scalar,cell[11]/Scalar,
					 cell[12]/Scalar,cell[13]/Scalar,cell[14]/Scalar,cell[15]/Scalar);
}
Matrix4x4 Matrix4x4::operator+(const Matrix4x4 &Zen)
{
	return Matrix4x4(cell[0]+Zen.cell[0],cell[1]+Zen.cell[1],cell[2]+Zen.cell[2],cell[3]+Zen.cell[3],
					 cell[4]+Zen.cell[4],cell[5]+Zen.cell[5],cell[6]+Zen.cell[6],cell[7]+Zen.cell[7],
					 cell[8]+Zen.cell[8],cell[9]+Zen.cell[9],cell[10]+Zen.cell[10],cell[11]+Zen.cell[11],
					 cell[12]+Zen.cell[12],cell[13]+Zen.cell[13],cell[14]+Zen.cell[14],cell[15]+Zen.cell[15]);
}
Matrix4x4 Matrix4x4::operator-(const Matrix4x4 &Zen)
{
	return Matrix4x4(cell[0]-Zen.cell[0],cell[1]-Zen.cell[1],cell[2]-Zen.cell[2],cell[3]-Zen.cell[3],
					 cell[4]-Zen.cell[4],cell[5]-Zen.cell[5],cell[6]-Zen.cell[6],cell[7]-Zen.cell[7],
					 cell[8]-Zen.cell[8],cell[9]-Zen.cell[9],cell[10]-Zen.cell[10],cell[11]-Zen.cell[11],
					 cell[12]-Zen.cell[12],cell[13]-Zen.cell[13],cell[14]-Zen.cell[14],cell[15]-Zen.cell[15]);
}
Matrix4x4 Matrix4x4::operator*(const Matrix4x4 &Zen)
{
	//Optimise for matrices in which bottom row is (0, 0, 0, 1) in both matrices
	if(	cell[3]==0.0f && cell[7]==0.0f && cell[11]==0.0f && cell[15]==1.0f	&&
		Zen.cell[3]==0.0f && Zen.cell[7]==0.0f &&
		Zen.cell[11]==0.0f && Zen.cell[15]==1.0f)
	{
		return Matrix4x4(	cell[0]*Zen.cell[0]+cell[4]*Zen.cell[1]+cell[8]*Zen.cell[2],
							cell[1]*Zen.cell[0]+cell[5]*Zen.cell[1]+cell[9]*Zen.cell[2],
							cell[2]*Zen.cell[0]+cell[6]*Zen.cell[1]+cell[10]*Zen.cell[2],
							0.0f,
							cell[0]*Zen.cell[4]+cell[4]*Zen.cell[5]+cell[8]*Zen.cell[6],
							cell[1]*Zen.cell[4]+cell[5]*Zen.cell[5]+cell[9]*Zen.cell[6],
							cell[2]*Zen.cell[4]+cell[6]*Zen.cell[5]+cell[10]*Zen.cell[6],
							0.0f,
							cell[0]*Zen.cell[8]+cell[4]*Zen.cell[9]+cell[8]*Zen.cell[10],
							cell[1]*Zen.cell[8]+cell[5]*Zen.cell[9]+cell[9]*Zen.cell[10],
							cell[2]*Zen.cell[8]+cell[6]*Zen.cell[9]+cell[10]*Zen.cell[10],
							0.0f,
							cell[0]*Zen.cell[12]+cell[4]*Zen.cell[13]+cell[8]*Zen.cell[14]+cell[12],
							cell[1]*Zen.cell[12]+cell[5]*Zen.cell[13]+cell[9]*Zen.cell[14]+cell[13],
							cell[2]*Zen.cell[12]+cell[6]*Zen.cell[13]+cell[10]*Zen.cell[14]+cell[14],
							1.0f);
	}
	//Optimise for when bottom row of 1st matrix is (0, 0, 0, 1)
	if(	cell[3]==0.0f && cell[7]==0.0f && cell[11]==0.0f && cell[15]==1.0f)
	{
		return Matrix4x4(	cell[0]*Zen.cell[0]+cell[4]*Zen.cell[1]+cell[8]*Zen.cell[2]+cell[12]*Zen.cell[3],
							cell[1]*Zen.cell[0]+cell[5]*Zen.cell[1]+cell[9]*Zen.cell[2]+cell[13]*Zen.cell[3],
							cell[2]*Zen.cell[0]+cell[6]*Zen.cell[1]+cell[10]*Zen.cell[2]+cell[14]*Zen.cell[3],
							Zen.cell[3],
							cell[0]*Zen.cell[4]+cell[4]*Zen.cell[5]+cell[8]*Zen.cell[6]+cell[12]*Zen.cell[7],
							cell[1]*Zen.cell[4]+cell[5]*Zen.cell[5]+cell[9]*Zen.cell[6]+cell[13]*Zen.cell[7],
							cell[2]*Zen.cell[4]+cell[6]*Zen.cell[5]+cell[10]*Zen.cell[6]+cell[14]*Zen.cell[7],
							Zen.cell[7],
							cell[0]*Zen.cell[8]+cell[4]*Zen.cell[9]+cell[8]*Zen.cell[10]+cell[12]*Zen.cell[11],
							cell[1]*Zen.cell[8]+cell[5]*Zen.cell[9]+cell[9]*Zen.cell[10]+cell[13]*Zen.cell[11],
							cell[2]*Zen.cell[8]+cell[6]*Zen.cell[9]+cell[10]*Zen.cell[10]+cell[14]*Zen.cell[11],
							Zen.cell[11],
							cell[0]*Zen.cell[12]+cell[4]*Zen.cell[13]+cell[8]*Zen.cell[14]+cell[12]*Zen.cell[15],
							cell[1]*Zen.cell[12]+cell[5]*Zen.cell[13]+cell[9]*Zen.cell[14]+cell[13]*Zen.cell[15],
							cell[2]*Zen.cell[12]+cell[6]*Zen.cell[13]+cell[10]*Zen.cell[14]+cell[14]*Zen.cell[15],
							Zen.cell[15]);
	}
	//Optimise for when bottom row of 2nd matrix is (0, 0, 0, 1)
	if(	Zen.cell[3]==0.0f && Zen.cell[7]==0.0f &&
		Zen.cell[11]==0.0f && Zen.cell[15]==1.0f)
	{
		return Matrix4x4(	cell[0]*Zen.cell[0]+cell[4]*Zen.cell[1]+cell[8]*Zen.cell[2],
							cell[1]*Zen.cell[0]+cell[5]*Zen.cell[1]+cell[9]*Zen.cell[2],
							cell[2]*Zen.cell[0]+cell[6]*Zen.cell[1]+cell[10]*Zen.cell[2],
							cell[3]*Zen.cell[0]+cell[7]*Zen.cell[1]+cell[11]*Zen.cell[2],
							cell[0]*Zen.cell[4]+cell[4]*Zen.cell[5]+cell[8]*Zen.cell[6],
							cell[1]*Zen.cell[4]+cell[5]*Zen.cell[5]+cell[9]*Zen.cell[6],
							cell[2]*Zen.cell[4]+cell[6]*Zen.cell[5]+cell[10]*Zen.cell[6],
							cell[3]*Zen.cell[4]+cell[7]*Zen.cell[5]+cell[11]*Zen.cell[6],
							cell[0]*Zen.cell[8]+cell[4]*Zen.cell[9]+cell[8]*Zen.cell[10],
							cell[1]*Zen.cell[8]+cell[5]*Zen.cell[9]+cell[9]*Zen.cell[10],
							cell[2]*Zen.cell[8]+cell[6]*Zen.cell[9]+cell[10]*Zen.cell[10],
							cell[3]*Zen.cell[8]+cell[7]*Zen.cell[9]+cell[11]*Zen.cell[10],
							cell[0]*Zen.cell[12]+cell[4]*Zen.cell[13]+cell[8]*Zen.cell[14]+cell[12],
							cell[1]*Zen.cell[12]+cell[5]*Zen.cell[13]+cell[9]*Zen.cell[14]+cell[13],
							cell[2]*Zen.cell[12]+cell[6]*Zen.cell[13]+cell[10]*Zen.cell[14]+cell[14],
							cell[3]*Zen.cell[12]+cell[7]*Zen.cell[13]+cell[11]*Zen.cell[14]+cell[15]);
	}
	return Matrix4x4(	cell[0]*Zen.cell[0]+cell[4]*Zen.cell[1]+cell[8]*Zen.cell[2]+cell[12]*Zen.cell[3],
						cell[1]*Zen.cell[0]+cell[5]*Zen.cell[1]+cell[9]*Zen.cell[2]+cell[13]*Zen.cell[3],
						cell[2]*Zen.cell[0]+cell[6]*Zen.cell[1]+cell[10]*Zen.cell[2]+cell[14]*Zen.cell[3],
						cell[3]*Zen.cell[0]+cell[7]*Zen.cell[1]+cell[11]*Zen.cell[2]+cell[15]*Zen.cell[3],
						cell[0]*Zen.cell[4]+cell[4]*Zen.cell[5]+cell[8]*Zen.cell[6]+cell[12]*Zen.cell[7],
						cell[1]*Zen.cell[4]+cell[5]*Zen.cell[5]+cell[9]*Zen.cell[6]+cell[13]*Zen.cell[7],
						cell[2]*Zen.cell[4]+cell[6]*Zen.cell[5]+cell[10]*Zen.cell[6]+cell[14]*Zen.cell[7],
						cell[3]*Zen.cell[4]+cell[7]*Zen.cell[5]+cell[11]*Zen.cell[6]+cell[15]*Zen.cell[7],
						cell[0]*Zen.cell[8]+cell[4]*Zen.cell[9]+cell[8]*Zen.cell[10]+cell[12]*Zen.cell[11],
						cell[1]*Zen.cell[8]+cell[5]*Zen.cell[9]+cell[9]*Zen.cell[10]+cell[13]*Zen.cell[11],
						cell[2]*Zen.cell[8]+cell[6]*Zen.cell[9]+cell[10]*Zen.cell[10]+cell[14]*Zen.cell[11],
						cell[3]*Zen.cell[8]+cell[7]*Zen.cell[9]+cell[11]*Zen.cell[10]+cell[15]*Zen.cell[11],
						cell[0]*Zen.cell[12]+cell[4]*Zen.cell[13]+cell[8]*Zen.cell[14]+cell[12]*Zen.cell[15],
						cell[1]*Zen.cell[12]+cell[5]*Zen.cell[13]+cell[9]*Zen.cell[14]+cell[13]*Zen.cell[15],
						cell[2]*Zen.cell[12]+cell[6]*Zen.cell[13]+cell[10]*Zen.cell[14]+cell[14]*Zen.cell[15],
						cell[3]*Zen.cell[12]+cell[7]*Zen.cell[13]+cell[11]*Zen.cell[14]+cell[15]*Zen.cell[15]);
}
Matrix4x4 Matrix4x4::operator*(const float Scalar)
{
	return Matrix4x4(cell[0]*Scalar,cell[1]*Scalar,cell[2]*Scalar,cell[3]*Scalar,
  	    			 cell[4]*Scalar,cell[5]*Scalar,cell[6]*Scalar,cell[7]*Scalar,
					 cell[8]*Scalar,cell[9]*Scalar,cell[10]*Scalar,cell[11]*Scalar,
					 cell[12]*Scalar,cell[13]*Scalar,cell[14]*Scalar,cell[15]*Scalar);

}
Matrix4x4 Matrix4x4::operator/(const float Scalar)
{
	if (Scalar==0.0f || Scalar==1.0f) return Matrix4x4(*this);
	return Matrix4x4(cell[0]/Scalar,cell[1]/Scalar,cell[2]/Scalar,cell[3]/Scalar,
  	    			 cell[4]/Scalar,cell[5]/Scalar,cell[6]/Scalar,cell[7]/Scalar,
					 cell[8]/Scalar,cell[9]/Scalar,cell[10]/Scalar,cell[11]/Scalar,
					 cell[12]/Scalar,cell[13]/Scalar,cell[14]/Scalar,cell[15]/Scalar);
}
void Matrix4x4::operator+=(const Matrix4x4 &Zen)
{
	cell[0]+=Zen.cell[0];	cell[1]+=Zen.cell[1];	cell[2]+=Zen.cell[2];	cell[3]+=Zen.cell[3];	
	cell[4]+=Zen.cell[4];	cell[5]+=Zen.cell[5];	cell[6]+=Zen.cell[6];	cell[7]+=Zen.cell[7];	
	cell[8]+=Zen.cell[8];	cell[9]+=Zen.cell[9];	cell[10]+=Zen.cell[10];	cell[11]+=Zen.cell[11];	
	cell[12]+=Zen.cell[12];	cell[13]+=Zen.cell[13];	cell[14]+=Zen.cell[14];	cell[15]+=Zen.cell[15];	
}
void Matrix4x4::operator-=(const Matrix4x4 &Zen)
{
	cell[0]-=Zen.cell[0];	cell[1]-=Zen.cell[1];	cell[2]-=Zen.cell[2];	cell[3]-=Zen.cell[3];	
	cell[4]-=Zen.cell[4];	cell[5]-=Zen.cell[5];	cell[6]-=Zen.cell[6];	cell[7]-=Zen.cell[7];	
	cell[8]-=Zen.cell[8];	cell[9]-=Zen.cell[9];	cell[10]-=Zen.cell[10];	cell[11]-=Zen.cell[11];	
	cell[12]-=Zen.cell[12];	cell[13]-=Zen.cell[13];	cell[14]-=Zen.cell[14];	cell[15]-=Zen.cell[15];	
}
void Matrix4x4::operator*=(const Matrix4x4 &Zen)
{
	*this=*this*Zen;
}
void Matrix4x4::operator*=(const float Scalar)
{
	cell[0]*=Scalar;	cell[1]*=Scalar;	cell[2]*=Scalar;	cell[3]*=Scalar;	
	cell[4]*=Scalar;	cell[5]*=Scalar;	cell[6]*=Scalar;	cell[7]*=Scalar;	
	cell[8]*=Scalar;	cell[9]*=Scalar;	cell[10]*=Scalar;	cell[11]*=Scalar;	
	cell[12]*=Scalar;	cell[13]*=Scalar;	cell[14]*=Scalar;	cell[15]*=Scalar;	
}
void Matrix4x4::operator/=(const float Scalar)
{
	if (!(Scalar==0.0f || Scalar==1.0f))
	{
		cell[0]/=Scalar;	cell[1]/=Scalar;	cell[2]/=Scalar;	cell[3]/=Scalar;	
		cell[4]/=Scalar;	cell[5]/=Scalar;	cell[6]/=Scalar;	cell[7]/=Scalar;	
		cell[8]/=Scalar;	cell[9]/=Scalar;	cell[10]/=Scalar;	cell[11]/=Scalar;	
		cell[12]/=Scalar;	cell[13]/=Scalar;	cell[14]/=Scalar;	cell[15]/=Scalar;	
	}
}
Vector4D Matrix4x4::operator*(Vector4D Zen)
{
	//Optimise for matrices in which bottom row is (0, 0, 0, 1)
	if(cell[3]==0.0f && cell[7]==0.0f && cell[11]==0.0f && cell[15]==1.0f)
	{
		return Vector4D(cell[0]*Zen.GetX()+cell[4]*Zen.GetY()+cell[8]*Zen.GetZ()+cell[12]*Zen.GetW(),
						cell[1]*Zen.GetX()+cell[5]*Zen.GetY()+cell[9]*Zen.GetZ()+cell[13]*Zen.GetW(),
						cell[2]*Zen.GetX()+cell[6]*Zen.GetY()+cell[10]*Zen.GetZ()+cell[14]*Zen.GetW(),
						Zen.GetW());
	}
	
	return Vector4D(cell[0]*Zen.GetX()+cell[4]*Zen.GetY()+cell[8]*Zen.GetZ()+cell[12]*Zen.GetW(),
					cell[1]*Zen.GetX()+cell[5]*Zen.GetY()+cell[9]*Zen.GetZ()+cell[13]*Zen.GetW(),
					cell[2]*Zen.GetX()+cell[6]*Zen.GetY()+cell[10]*Zen.GetZ()+cell[14]*Zen.GetW(),
					cell[3]*Zen.GetX()+cell[7]*Zen.GetY()+cell[11]*Zen.GetZ()+cell[15]*Zen.GetW());
}

Matrix4x4 Matrix4x4::operator-(void)
{
	Matrix4x4 Zen(*this);
	Zen.cell[0]=-Zen.cell[0];	Zen.cell[1]=-Zen.cell[1];	Zen.cell[2]=-Zen.cell[2];	Zen.cell[3]=-Zen.cell[3];
	Zen.cell[4]=-Zen.cell[4];	Zen.cell[5]=-Zen.cell[5];	Zen.cell[6]=-Zen.cell[6];	Zen.cell[7]=-Zen.cell[7];
	Zen.cell[8]=-Zen.cell[8];	Zen.cell[9]=-Zen.cell[9];	Zen.cell[10]=-Zen.cell[10];	Zen.cell[11]=-Zen.cell[11];
	Zen.cell[12]=-Zen.cell[12];	Zen.cell[13]=-Zen.cell[13];	Zen.cell[14]=-Zen.cell[14];	Zen.cell[15]=-Zen.cell[15];
	return Zen;
}
Matrix4x4 Matrix4x4::operator+(void)
{
	return (*this);
}
Matrix4x4::operator const float*(void)
{
	return (const float*) this;
}
Matrix4x4::operator float*(void)
{
	return (float*) this;
}