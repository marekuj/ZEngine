#include "Vector2D.h"
#include <cmath>

#if(IOSTREAN_ON)
	using std::ostream;
	using std::istream;
	using std::cout;
	ostream& operator << (ostream & out, const Vector2D &Zen)
	{
		out<<"X: "<<Zen.x<<" Y: "<<Zen.y;
		return out;
	}
	istream& operator >> (istream & in,Vector2D &Zen)
	{
		cout<<"Wprowac x: "; in>>Zen.x;
		cout<<"Wprowac y: "; in>>Zen.y;
		return in;
	}
#endif
bool operator==(const Vector2D& L, const Vector2D& R)
{
	return L.x==R.x && L.y==R.y;
}
bool operator!=(const Vector2D& L, const Vector2D& R)
{
	return !(L.x==R.x && L.y==R.y);
}
Vector2D operator*(float Scalar, const Vector2D &Zen)
{
	return  Vector2D(Zen.x*Scalar,Zen.y*Scalar);
}
float DotProduct(const Vector2D& L, const Vector2D& R)
{
	return L.x*R.x+L.y*R.y;
}
float CrossProduct(const Vector2D& L, const Vector2D& R)
{
	return L.x*R.y-L.y*R.x;
}
Vector2D LinearInterpolate(const Vector2D V1,const Vector2D& V2,float Factor)
{
	return V1*(1.0f-Factor) + V2*Factor;
}
Vector2D QuadraticInterpolate(const Vector2D V1,const Vector2D& V2,const Vector2D& V3,float Factor)
{
	return V1*(1.0f-Factor)*(1.0f-Factor) + 2*V2*Factor*(1.0f-Factor) + V3*Factor*Factor;
}
Vector2D::Vector2D(float x, float y):x(x),y(y)
{
}
Vector2D::Vector2D(const float *Zen):x(Zen[0]),y(Zen[1])
{
}
Vector2D::Vector2D(const Vector2D &Zen):x(Zen.x),y(Zen.y)
{
}
Vector2D::~Vector2D(void)
{
}
void Vector2D::LoadZero(void)
{
	x=y=0;
}
void Vector2D:: LoadOne(void)
{
	x=y=1;
}
void Vector2D::Set(float x,float y)
{
	this->x=x;
	this->y=y;
}
void Vector2D::Set(const float *Zen)
{
	x=Zen[0];
	y=Zen[1];
}
void Vector2D::SetX(float x)
{
	this->x=x;
}
void Vector2D::SetY(float y)
{
	this->y=y;
}
float Vector2D::GetX(void)
{
	return x;
}
float Vector2D::GetY(void)
{
	return y;
}
float Vector2D::GetLength(void)
{
	return sqrt((x*x)+(y*y));		//201.25
}
float Vector2D::GetSquaredLength(void)
{
	return x*x+y*y;
}
void Vector2D::Normalize(void)
{
	float BufLength=GetLength();
	if(BufLength!=1 || BufLength!=0)
	{
		float Factor;
		Factor=1.0f/BufLength;
		x*=Factor;
		y*=Factor;
	}
}
Vector2D Vector2D::GetNormalized(void)
{
	float BufLength=GetLength();
	if(BufLength!=1 || BufLength!=0)
	{
		Vector2D Buf(*this);
		float Factor;
		Factor=1.0f/BufLength;
		Buf.x*=Factor;
		Buf.y*=Factor;
		return Buf;
	}
	return *this;
}
void Vector2D::operator=(const Vector2D& Zen)
{
	x=Zen.x;
	y=Zen.y;
}
Vector2D Vector2D::operator+(const Vector2D& Zen) const
{
	return Vector2D(x+Zen.x,y+Zen.y);
}
Vector2D Vector2D::operator-(const Vector2D& Zen) const
{
	return Vector2D(x-Zen.x,y-Zen.y);;
}
Vector2D Vector2D::operator*(const float Scalar) const
{
	return Vector2D(x*Scalar,y*Scalar);
}
Vector2D Vector2D::operator/(const float Scalar) const
{
	return Scalar?Vector2D(x/Scalar,y/Scalar):Vector2D(0,0);
}
Vector2D Vector2D::operator+(const Vector2D& Zen)
{
	return Vector2D(x+Zen.x,y+Zen.y);
}
Vector2D Vector2D::operator-(const Vector2D& Zen)
{
	return Vector2D(x-Zen.x,y-Zen.y);;
}
Vector2D Vector2D::operator*(const float Scalar)
{
	return Vector2D(x*Scalar,y*Scalar);
}
Vector2D Vector2D::operator/(const float Scalar)
{
	return Scalar?Vector2D(x/Scalar,y/Scalar):Vector2D(0,0);
}
void Vector2D::operator+=(const Vector2D& Zen)
{
	x+=Zen.x;
	y+=Zen.y;
}
void Vector2D::operator-=(const Vector2D& Zen)
{
	x-=Zen.x;
	y-=Zen.y;
}
void Vector2D::operator*=(const float Scalar)
{
	x=x*Scalar;
	y=y*Scalar;
}
void Vector2D::operator/=(const float Scalar)
{
	if(Scalar)
	{
		x=x/Scalar;
		y=y/Scalar;
	}
}
Vector2D Vector2D::operator-(void)
{
	return Vector2D(-x,-y);
}
Vector2D Vector2D::operator+() 
{
	return *this;
}
Vector2D::operator const float*(void)
{
	return (const float*)this;
}
Vector2D::operator float*(void)
{
	return (float*)this;
}