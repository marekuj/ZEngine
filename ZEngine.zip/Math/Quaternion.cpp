#include "Quaternion.h"

#define _USE_MATH_DEFINES
#include <cmath>

float Quaternion::PI_Buffer=(float)3.14159265359/180;

Quaternion::Quaternion()
{
	x = 0.0f;
	y = 0.0f;
	z = 0.0f;
	w = 1.0f;
}
Quaternion::~Quaternion()
{
}
void Quaternion::ZCreateFromAxisAngle(float x, float y, float z, float Degrees)
{
	// First we want to convert the degrees to radians 
	// since the angle is assumed to be in radians
	float Angle = Degrees*PI_Buffer;
	// Here we calculate the sin( theta / 2) once for optimization
	float Result = sin(Angle/2.0f);
	// Calcualte the w value by cos( theta / 2 )
	this->w = cos(Angle/2.0f);
	// Calculate the x, y and z of the quaternion
	this->x = x*Result;
	this->y = y*Result;
	this->z = z*Result;
}
void Quaternion::ZCreateMatrix4x4(Matrix4x4 &Zen)
{
	// First row
	Zen.SetCell(0,1.0f - 2.0f * ( y * y + z * z ));
	Zen.SetCell(1,2.0f * (x * y + z * w));
	Zen.SetCell(2,2.0f * (x * z - y * w));
	Zen.SetCell(3,0.0f);
	// Second row
	Zen.SetCell(4,2.0f * ( x * y - z * w ));
	Zen.SetCell(5,1.0f - 2.0f * ( x * x + z * z ));
	Zen.SetCell(6,2.0f * (z * y + x * w ));
	Zen.SetCell(7,0.0f);
	// Third row
	Zen.SetCell(8,2.0f * ( x * z + y * w ));
	Zen.SetCell(9,2.0f * ( y * z - x * w ));
	Zen.SetCell(10,1.0f - 2.0f * ( x * x + y * y ));
	Zen.SetCell(11,0.0f);
	// Fourth row
	Zen.SetCell(12,0);
	Zen.SetCell(13,0);
	Zen.SetCell(14,0);
	Zen.SetCell(15,1.0f);
	// Now Zen is a 4x4 homogeneous matrix that can be applied to an OpenGL Matrix
}
Quaternion Quaternion::operator*(const Quaternion &Zen)
{
	static Quaternion Buf;
	Buf.x = w*Zen.x + x*Zen.w + y*Zen.z - z*Zen.y;
	Buf.y = w*Zen.y + y*Zen.w + z*Zen.x - x*Zen.z;
	Buf.z = w*Zen.z + z*Zen.w + x*Zen.y - y*Zen.x;
	Buf.w = w*Zen.w - x*Zen.x - y*Zen.y - z*Zen.z;
	return Buf;
}