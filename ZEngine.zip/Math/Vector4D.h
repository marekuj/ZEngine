#pragma once

#include "Vector3D.h"

#define IOSTREAN_ON 1
#if(IOSTREAN_ON)
	#include <iostream>
#endif

class Vector4D
{
private:
private:
	static float PI_Buffer;												//Pi/180
	float x;
	float y;
	float z;
	float w;
	#if(IOSTREAN_ON)
		friend std::ostream& operator << (std::ostream &out, const Vector4D &Zen);
		friend std::istream& operator >> (std::istream &in,Vector4D &Zen);
	#endif	
	friend bool operator==(const Vector4D &L, const Vector4D &R);
	friend bool operator!=(const Vector4D &L, const Vector4D &R);
	friend Vector4D operator*(float Scalar, const Vector4D &Zen);
	friend float DotProduct(const Vector4D &L, const Vector4D &R);			//Iloczyn skalarny wektor�w
	friend Vector4D CrossProduct(const Vector4D &L, const Vector4D &R);		//wyznacznik wektor�w
	friend Vector4D LinearInterpolate(const Vector4D V1,const Vector4D& V2,float Factor);							//interpolacja liniowa(lerp)
	friend Vector4D QuadraticInterpolate(const Vector4D V1,const Vector4D& V2,const Vector4D& V3,float Factor);		//interpolacja kwadratowa
protected:
public:
	Vector4D(float x=0, float y=0, float z=0, float w=0);		//konstruktor domyslny
	Vector4D(const float *Zen);								//konstruktor "z tablicy"
	Vector4D(const Vector4D &Zen);							//konstructor kopiuj�cy
	Vector4D(const Vector3D &Zen);							//konstructor Vector3D do Vector4D
	~Vector4D(void);

	void LoadZero();										//Zerowanie
	void LoadOne();											//Jedynkowannie;)

	void Set(float x=0,float y=0,float z=0,float w=0);		//ustaw YXZW
	void Set(const float *Zen);								//ustaw YXZW
	void SetX(float x=0);									//ustaw X
	void SetY(float y=0);									//ustaw Y
	void SetZ(float z=0);									//ustaw Y
	void SetW(float w=0);									//ustaw W
	float GetX(void) const;									//pobierz X
	float GetY(void) const;									//pobierz Y
	float GetZ(void) const;									//pobierz Y
	float GetW(void) const;									//pobierz W
	//obroty
	void RotateX(float Angle);
	void RotateY(float Angle);
	void RotateZ(float Angle);
	void Rotate(float Angle, const Vector3D &Axis);

	Vector4D GetRotatedX(float Angle) const;
	Vector4D GetRotatedY(float Angle) const;
	Vector4D GetRotatedZ(float Angle) const;
	Vector4D GetRotated(float Angle, const Vector3D &Axis) const;
	//operatory
	void operator=(const Vector4D& Zen);

	Vector4D operator+(const Vector4D& Zen) const;
	Vector4D operator-(const Vector4D& Zen) const;
	Vector4D operator*(const float Scalar) const;
	Vector4D operator/(const float Scalar) const;

	Vector4D operator+(const Vector4D& Zen);
	Vector4D operator-(const Vector4D& Zen);
	Vector4D operator*(const float Scalar);
	Vector4D operator/(const float Scalar);

	void operator+=(const Vector4D& Zen);
	void operator-=(const Vector4D& Zen);
	void operator*=(const float Scalar);
	void operator/=(const float Scalar);

	Vector4D operator-(void); 
	Vector4D operator+(void); 
	//operatory dla OpenGL np. glColor4fv
	operator const float*(void);
	operator float*(void);
	
	Vector3D ToVector3D(void);
};
