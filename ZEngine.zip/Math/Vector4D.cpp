#include "Vector4D.h"

#define _USE_MATH_DEFINES
#include <cmath>

float Vector4D::PI_Buffer=(float)3.14159265359/180;

#if(IOSTREAN_ON)
	using std::ostream;
	using std::istream;
	using std::cout;
	ostream& operator << (ostream &out, const Vector4D &Zen)
	{
		out<<"X: "<<Zen.x<<" Y: "<<Zen.y<<" Z: "<<Zen.z<<" W: "<<Zen.w;
		return out;
	}
	istream& operator >> (istream &in,Vector4D &Zen)
	{
		cout<<"Wprowac x: "; in>>Zen.x;
		cout<<"Wprowac y: "; in>>Zen.y;
		cout<<"Wprowac z: "; in>>Zen.z;
		cout<<"Wprowac w: "; in>>Zen.w;
		return in;
	}
#endif
bool operator==(const Vector4D &L, const Vector4D &R)
{
	return L.x==R.x && L.y==R.y && L.z==R.z && L.w==R.w;
}
bool operator!=(const Vector4D &L, const Vector4D &R)
{
	return !(L.x==R.x && L.y==R.y && L.z==R.z && L.w==R.w);
}
Vector4D operator*(float Scalar, const Vector4D &Zen)
{
	return  Vector4D(Zen.x*Scalar,Zen.y*Scalar,Zen.z*Scalar,Zen.w*Scalar);
}
float DotProduct(const Vector4D &L, const Vector4D &R)
{
	return L.x*R.x+L.y*R.y+L.z*R.z+L.w*R.w;
}
Vector4D CrossProduct(const Vector4D &L, const Vector4D &R)
{
	return Vector4D(L.y*R.z-L.z*R.y,L.z*R.x-L.x*R.z,L.x*R.y-L.y*R.x,L.w);
}
Vector4D LinearInterpolate(const Vector4D V1,const Vector4D& V2,float Factor)
{
	return V1*(1.0f-Factor) + V2*Factor;
}
Vector4D QuadraticInterpolate(const Vector4D V1,const Vector4D& V2,const Vector4D& V3,float Factor)
{
	return V1*(1.0f-Factor)*(1.0f-Factor) + 2*V2*Factor*(1.0f-Factor) + V3*Factor*Factor;
}
Vector4D::Vector4D(float x, float y, float z, float w):x(x),y(y),z(z),w(w)
{
}
Vector4D::Vector4D(const float *Zen):x(Zen[0]),y(Zen[1]),z(Zen[2]),w(Zen[3])
{
}
Vector4D::Vector4D(const Vector4D &Zen):x(Zen.x),y(Zen.y),z(Zen.z),w(Zen.w)
{
}
Vector4D::~Vector4D(void)
{
}
Vector4D::Vector4D(const Vector3D &Zen)
{
	x=Zen.GetX();
	y=Zen.GetY();
	z=Zen.GetZ();
	w=1.0f;
}
void Vector4D::LoadZero(void)
{
	x=y=z=w=0;
}
void Vector4D::LoadOne(void)
{
	x=y=z=w=1;
}
void Vector4D::Set(float x,float y,float z,float w)
{
	this->x=x;
	this->y=y;
	this->z=z;
	this->w=w;
}
void Vector4D::Set(const float *Zen)
{
	x=Zen[0];
	y=Zen[1];
	z=Zen[2];
	w=Zen[3];
}
void Vector4D::SetX(float x)
{
	this->x=x;
}
void Vector4D::SetY(float y)
{
	this->y=y;
}
void Vector4D::SetZ(float z)
{
	this->z=z;
}
void Vector4D::SetW(float w)
{
	this->w=w;
}
float Vector4D::GetX(void) const
{
	return x;
}
float Vector4D::GetY(void) const
{
	return y;
}
float Vector4D::GetZ(void) const
{
	return z;
}
float Vector4D::GetW(void) const
{
	return w;
}
void Vector4D::RotateX(float Angle)
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	float BufY=y;
	y=y*CosAngle - z*SinAngle;
	z=BufY*SinAngle + z*CosAngle;
}
void Vector4D::RotateY(float Angle)
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	float BufX=x;
	x=x*CosAngle + z*SinAngle;
	z=-BufX*SinAngle + z*CosAngle;
}
void Vector4D::RotateZ(float Angle)
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	float BufX=x;
	x=x*CosAngle - y*SinAngle;
	y=BufX*SinAngle + y*CosAngle;
}
void Vector4D::Rotate(float Angle, const Vector3D &Axis)
{
	Vector3D ANorm(Axis);
	ANorm.Normalize();
	Vector3D rotMRow0, rotMRow1, rotMRow2;
	float X=ANorm.GetX(),Y=ANorm.GetY(),Z=ANorm.GetZ();

	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	float OneMinusCosAngle=1.0f-CosAngle;

	rotMRow0.Set((X)*(X) + CosAngle*(1-(X)*(X)),(X)*(Y)*(OneMinusCosAngle) - SinAngle*Z,
					(X)*(Z)*(OneMinusCosAngle) + SinAngle*Z);
	rotMRow1.Set((X)*(Y)*(OneMinusCosAngle) + SinAngle*Z,(Y)*(Y) + CosAngle*(1-(Y)*(Y)),
					(Y)*(Z)*(OneMinusCosAngle) - SinAngle*X);
	rotMRow2.Set((X)*(Z)*(OneMinusCosAngle) - SinAngle*Y,(Y)*(Z)*(OneMinusCosAngle) + SinAngle*X,
					(Z)*(Z) + CosAngle*(1-(Z)*(Z)));
	Set(DotProduct(*this,rotMRow0),DotProduct(*this,rotMRow1),DotProduct(*this,rotMRow2),w);
}
Vector4D Vector4D::GetRotatedX(float Angle) const
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	return Vector4D(x,y*CosAngle - z*SinAngle,y*SinAngle + z*CosAngle,w);
}
Vector4D Vector4D::GetRotatedY(float Angle) const
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	return Vector4D(x*CosAngle + z*SinAngle,y,-x*SinAngle + z*CosAngle,w);
}
Vector4D Vector4D::GetRotatedZ(float Angle) const
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	return Vector4D(x*CosAngle - y*SinAngle,x*SinAngle + y*CosAngle,z,w);
}
Vector4D Vector4D::GetRotated(float Angle, const Vector3D &Axis) const
{
	Vector3D ANorm(Axis);
	ANorm.Normalize();
	Vector3D rotMRow0, rotMRow1, rotMRow2;
	float X=ANorm.GetX(),Y=ANorm.GetY(),Z=ANorm.GetZ();

	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	float OneMinusCosAngle=1.0f-CosAngle;

	rotMRow0.Set((X)*(X) + CosAngle*(1-(X)*(X)),(X)*(Y)*(OneMinusCosAngle) - SinAngle*Z,
					(X)*(Z)*(OneMinusCosAngle) + SinAngle*Z);
	rotMRow1.Set((X)*(Y)*(OneMinusCosAngle) + SinAngle*Z,(Y)*(Y) + CosAngle*(1-(Y)*(Y)),
					(Y)*(Z)*(OneMinusCosAngle) - SinAngle*X);
	rotMRow2.Set((X)*(Z)*(OneMinusCosAngle) - SinAngle*Y,(Y)*(Z)*(OneMinusCosAngle) + SinAngle*X,
					(Z)*(Z) + CosAngle*(1-(Z)*(Z)));
	return  Vector4D(DotProduct(*this,rotMRow0),DotProduct(*this,rotMRow1),	DotProduct(*this,rotMRow2),w);
}
void Vector4D::operator=(const Vector4D& Zen)
{
	x=Zen.x;
	y=Zen.y;
	z=Zen.z;
	w=Zen.w;
}
Vector4D Vector4D::operator+(const Vector4D& Zen) const
{
	return Vector4D(x+Zen.x,y+Zen.y,z+Zen.z,w+Zen.w);
}
Vector4D Vector4D::operator-(const Vector4D& Zen) const
{
	return Vector4D(x-Zen.x,y-Zen.y,z-Zen.z,w+Zen.w);
}
Vector4D Vector4D::operator*(const float Scalar) const
{
	return Vector4D(x*Scalar,y*Scalar,z*Scalar,w*Scalar);
}
Vector4D Vector4D::operator/(const float Scalar) const
{
	return Scalar?Vector4D(x/Scalar,y/Scalar,z/Scalar,z/Scalar):Vector4D(0,0,0,0);
}
Vector4D Vector4D::operator+(const Vector4D& Zen)
{
	return Vector4D(x+Zen.x,y+Zen.y,z+Zen.z,w+Zen.w);
}
Vector4D Vector4D::operator-(const Vector4D& Zen)
{
	return Vector4D(x-Zen.x,y-Zen.y,z-Zen.z,w+Zen.w);
}
Vector4D Vector4D::operator*(const float Scalar)
{
	return Vector4D(x*Scalar,y*Scalar,z*Scalar,w*Scalar);
}
Vector4D Vector4D::operator/(const float Scalar)
{
	return Scalar?Vector4D(x/Scalar,y/Scalar,z/Scalar,z/Scalar):Vector4D(0,0,0,0);
}
void Vector4D::operator+=(const Vector4D& Zen)
{
	x+=Zen.x;
	y+=Zen.y;
	z+=Zen.z;
	w+=Zen.w;
}
void Vector4D::operator-=(const Vector4D& Zen)
{
	x-=Zen.x;
	y-=Zen.y;
	z-=Zen.z;
	w-=Zen.w;
}
void Vector4D::operator*=(const float Scalar)
{
	x=x*Scalar;
	y=y*Scalar;
	z=z*Scalar;
	w=w*Scalar;
}
void Vector4D::operator/=(const float Scalar)
{
	if(Scalar)
	{
		x=x/Scalar;
		y=y/Scalar;
		z=z/Scalar;
		w=w/Scalar;
	}
}
Vector4D Vector4D::operator-(void)
{
	return Vector4D(-x,-y,-z,-w);
}
Vector4D Vector4D::operator+(void) 
{
	return *this;
}
Vector4D::operator const float*(void)
{
	return (const float*)this;
}
Vector4D::operator float*(void)
{
	return (float*)this;
}
Vector3D Vector4D::ToVector3D(void)
{
	return (w==0.0f || w==1.0f)?Vector3D(x,y,z):Vector3D(x/w,y/w,z/w);
}
