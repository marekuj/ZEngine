#pragma once

#define IOSTREAN_ON 1
#if(IOSTREAN_ON)
	#include <iostream>
#endif

class Vector2D
{
private:
	float x;
	float y;
	#if(IOSTREAN_ON)
		friend std::ostream& operator << (std::ostream & out, const Vector2D &Zen);
		friend std::istream& operator >> (std::istream & in,Vector2D &Zen);
	#endif
	friend bool operator==(const Vector2D& L, const Vector2D& R);
	friend bool operator!=(const Vector2D& L, const Vector2D& R);
	friend Vector2D operator*(float Scalar,const Vector2D &Zen);
	friend float DotProduct(const Vector2D& L, const Vector2D& R);		//Iloczyn skalarny wektor�w
	friend float CrossProduct(const Vector2D& L, const Vector2D& R);		//wyznacznik wektor�w
	friend Vector2D LinearInterpolate(const Vector2D V1,const Vector2D& V2,float Factor);							//interpolacja liniowa(lerp)
	friend Vector2D QuadraticInterpolate(const Vector2D V1,const Vector2D& V2,const Vector2D& V3,float Factor);		//interpolacja kwadratowa
protected:
public:
	Vector2D(float x=0, float y=0);					//konstruktor domyslny
	Vector2D(const float *Zen);						//konstruktor "z tablicy"
	Vector2D(const Vector2D &Zen);					//konstructor kopiuj�cy
	~Vector2D(void);								//destructor
	
	void LoadZero(void);							//Zerowanie
	void LoadOne(void);								//Jedynkowannie;)

	void Set(float x=0,float y=0);					//ustaw YX
	void Set(const float *Zen);						//ustaw YX
	void SetX(float x=0);							//ustaw X
	void SetY(float y=0);							//ustaw Y
	float GetX();									//pobierz X
	float GetY();									//pobierz Y

	float GetLength(void);							//zwraca d�ugo�� wektora(w przeszczeni kartezja�skiej)  
	float GetSquaredLength(void);					//zwraca r�nice kwadrat�w wsp�rz�dnych 
	void Normalize(void);							//normalizuj wektor(Wersor)
	Vector2D GetNormalized(void);					//zwraca wektor znormalizowany(Wersor)
 	//operatory
	void operator=(const Vector2D& Zen);

	Vector2D operator+(const Vector2D& Zen) const;
	Vector2D operator-(const Vector2D& Zen) const;
	Vector2D operator*(const float Scalar) const;
	Vector2D operator/(const float Scalar) const;

	Vector2D operator+(const Vector2D& Zen);
	Vector2D operator-(const Vector2D& Zen);
	Vector2D operator*(const float Scalar);
	Vector2D operator/(const float Scalar);

	void operator+=(const Vector2D& Zen);
	void operator-=(const Vector2D& Zen);
	void operator*=(const float Scalar);
	void operator/=(const float Scalar);

	Vector2D operator-(void); 
	Vector2D operator+(void); 
	//operatory dla OpenGL np. glVertex3fv
	operator const float*(void);
	operator float*(void);
};