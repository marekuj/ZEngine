#pragma once

#include "Vector3D.h"
#include "Vector4D.h"

#define IOSTREAN_ON 1
#if(IOSTREAN_ON)
	#include <iostream>
#endif

class Matrix4x4
{
private:
	static float PI_Buffer;												//Pi/180
	float cell[16];
	#if(IOSTREAN_ON)
		friend std::ostream& operator << (std::ostream & out, const Matrix4x4 &Zen);
		friend std::istream& operator >> (std::istream & in,Matrix4x4 &Zen);
	#endif	
	friend bool operator==(const Matrix4x4 &L,const Matrix4x4 &P);
	friend bool operator!=(const Matrix4x4 &L,const Matrix4x4 &P);
	friend Matrix4x4 operator*(float Scalar, const Matrix4x4 &Zen);
protected:
public:
	Matrix4x4(void);													//konstruktor domyslny
	Matrix4x4(float c00, float c10, float c20, float c30,				//konstruktor "z wartosciami"
			  float c01, float c11, float c21, float c31,
			  float c02, float c12, float c22, float c32,
			  float c03, float c13, float c23, float c33);	
	Matrix4x4(const float *Zen);										//konstruktor "z tablicy"
	Matrix4x4(const Matrix4x4 &Zen);									//konstructor kopiuj�cy
	~Matrix4x4(void);													//destructor

	void LoadZero(void);												//Zerowanie
	void LoadIdentity(void);											//Zerowanie + Jedynkowannie przekatnej;)

	void SetCell(int Position, float Value);							//Ustaw kom�rke (dorpbi� ustawianie wszystkich kom�rek na raz!?)
	float GetCell(int Position);										//Pobierz kom�rke
	Vector4D GetRow(int Position);										//Pobierz wiersz
	Vector4D GetColumn(int Position);									//Pobierz columne
	
	void Invert(void);													//Oblicz macierz przeciwn�
	Matrix4x4 GetInverse(void);											//Oblicz macierz przeciwn�
	void Transpose(void);												//Oblicz macierz transponowana
	Matrix4x4 GetTranspose(void);										//Oblicz macierz transponowana
	void InvertTranspose(void);											//Obicz macierz przeciwna i tansponowan�
	Matrix4x4 GetInverseTranspose(void);								//Obicz macierz przeciwna i tansponowan�

	void AffineInvert(void);
	Matrix4x4 GetAffineInverse(void);
	void AffineInvertTranspose(void);
	Matrix4x4 GetAffineInverseTranspose(void);

	//set to perform an operation on space - removes other entries
	void SetTranslation(Vector3D &Translation);
	void SetScale(Vector3D &Scale);
	void SetUniformScale(float Scale);
	void SetRotationAxis(double Angle,Vector3D &Axis);
	void SetRotationX(double Angle);
	void SetRotationY(double Angle);
	void SetRotationZ(double Angle);
	void SetRotationEuler(double AngleX, double AngleY, double AngleZ);
	void SetPerspective(float Left, float Right, float Bottom, float Top, float n, float f);
	void SetPerspective(float Fovy, float Aspect, float n, float f);
	void SetOrtho(float Left, float Right, float Bottom, float Top, float n, float f);
	void SetLookAt(Vector3D Eye,Vector3D Center,Vector3D Up);
	//set parts of the matrix
	void SetTranslationPart(Vector3D &Translation);
	void SetRotationPartEuler(double AngleX, double AngleY, double AngleZ);
	void SetRotationPartEuler(Vector3D &Rotations);

	//obr�t wektora wzgl�dem  element�w obrotu macierzy
	void RotateVector3D(Vector3D &Zen);
	void InverseRotateVector3D(Vector3D &Zen);
	Vector3D GetRotatedVector3D(Vector3D &Zen);
	Vector3D GetInverseRotatedVector3D(Vector3D &Zen);

	//przesuniecie wektora wzgl�dem  element�w tranzlacji macierzy
	void TranslateVector3D(Vector3D &Zen);
	void InverseTranslateVector3D(Vector3D &Zen);
	Vector3D GetTranslatedVector3D(Vector3D &Zen);
	Vector3D GetInverseTranslatedVector3D(Vector3D &Zen);

	//operatory
	Matrix4x4 operator+(const Matrix4x4 &Zen) const;
	Matrix4x4 operator-(const Matrix4x4 &Zen) const;
	Matrix4x4 operator*(const Matrix4x4 &Zen) const;
	Matrix4x4 operator*(const float Scalar) const;
	Matrix4x4 operator/(const float Scalar) const;

	Matrix4x4 operator+(const Matrix4x4 &Zen);
	Matrix4x4 operator-(const Matrix4x4 &Zen);
	Matrix4x4 operator*(const Matrix4x4 &Zen);
	Matrix4x4 operator*(const float Scalar);
	Matrix4x4 operator/(const float Scalar);

	void operator+=(const Matrix4x4 &Zen);
	void operator-=(const Matrix4x4 &Zen);
	void operator*=(const Matrix4x4 &Zen);
	void operator*=(const float Scalar);
	void operator/=(const float Scalar);

	Vector4D operator*(Vector4D Zen);

	Matrix4x4 operator-(void);
	Matrix4x4 operator+(void);
	//operatory dla OpenGL np. glMultMatrixf
	operator const float*(void);
	operator float*(void);
};
