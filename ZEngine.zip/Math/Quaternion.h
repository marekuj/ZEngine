#pragma once

#include "Matrix4x4.h"

class Quaternion  
{
private:
	static float PI_Buffer;												//Pi/180

	float x;
	float y;
	float z;
	float w;
public:
	Quaternion();
	~Quaternion();

	void ZCreateMatrix4x4(Matrix4x4 &Zen);
	void ZCreateFromAxisAngle(float x, float y, float z, float Degrees);

	Quaternion operator*(const Quaternion &Zen);
};
