#pragma once

#define IOSTREAN_ON 1
#if(IOSTREAN_ON)
	#include <iostream>
	//using namespace std;
#endif

class Vector3D
{
private:
	static float PI_Buffer;												//Pi/180
	float x;
	float y;
	float z;
	#if(IOSTREAN_ON)
		friend std::ostream& operator << (std::ostream &out,const Vector3D &Zen);
		friend std::istream& operator >> (std::istream &in,Vector3D &Zen);
	#endif	
	friend bool operator==(const Vector3D &L,const Vector3D &R);
	friend bool operator!=(const Vector3D &L,const Vector3D &R);
	friend Vector3D operator*(float Scalar,const Vector3D &Zen);
	friend float DotProduct(const Vector3D &L,const Vector3D &R);		//Iloczyn skalarny wektor�w
	friend Vector3D CrossProduct(const Vector3D &L,const Vector3D &R);	//wyznacznik wektor�w
	friend Vector3D LinearInterpolate(const Vector3D V1,const Vector3D& V2,float Factor);							//interpolacja liniowa(lerp)
	friend Vector3D QuadraticInterpolate(const Vector3D V1,const Vector3D& V2,const Vector3D& V3,float Factor);		//interpolacja kwadratowa
protected:
public:
	Vector3D(float x=0, float y=0, float z=0);		//konstruktor domyslny
	Vector3D(const float *Zen);						//konstruktor "z tablicy"
	Vector3D(const Vector3D &Zen);					//konstructor kopiuj�cy
	~Vector3D(void);								//destructor

	void LoadZero();								//Zerowanie
	void LoadOne();									//Jedynkowannie;)

	void Set(float x=0,float y=0,float z=0);		//ustaw YXZ
	void Set(const float *Zen);						//ustaw YXZ
	void SetX(float x=0);							//ustaw X
	void SetY(float y=0);							//ustaw Y
	void SetZ(float z=0);							//ustaw Y
	float GetX() const;								//pobierz X
	float GetY() const;								//pobierz Y
	float GetZ() const;								//pobierz Y

	float GetLength(void) const;					//zwraca d�ugo�� wektora(w przeszczeni kartezja�skiej)  
	float GetSquaredLength(void) const;				//zwraca r�nice kwadrat�w wsp�rz�dnych 
	void Normalize(void);							//normalizuj wektor(Wersor)
	Vector3D GetNormalized(void) const;				//zwraca wektor znormalizowany(Wersor)
	//obroty
	void RotateX(float Angle);
	void RotateY(float Angle);
	void RotateZ(float Angle);
	void Rotate(float Angle, const Vector3D &Axis);

	Vector3D GetRotatedX(float Angle) const;
	Vector3D GetRotatedY(float Angle) const;
	Vector3D GetRotatedZ(float Angle) const;
	Vector3D GetRotated(float Angle, const Vector3D &Axis) const;
	//Odbicie
	void Reflection(const Vector3D &Normal);
	Vector3D GetReflection(const Vector3D &Normal) const;
	//operatory
	void operator=(const Vector3D& Zen);

	Vector3D operator+(const Vector3D& Zen) const;
	Vector3D operator-(const Vector3D& Zen) const;
	Vector3D operator*(const float Scalar) const;
	Vector3D operator/(const float Scalar) const;

	Vector3D operator+(const Vector3D& Zen);
	Vector3D operator-(const Vector3D& Zen);
	Vector3D operator*(const float Scalar);
	Vector3D operator/(const float Scalar);

	void operator+=(const Vector3D& Zen);
	void operator-=(const Vector3D& Zen);
	void operator*=(const float Scalar);
	void operator/=(const float Scalar);

	Vector3D operator-(void);
	Vector3D operator+(void); 
	//operatory dla OpenGL np. glColor3fv
	operator const float*(void);
	operator float*(void);
};	