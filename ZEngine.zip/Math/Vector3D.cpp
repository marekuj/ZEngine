#include "Vector3D.h"

#define _USE_MATH_DEFINES
#include <cmath>

float Vector3D::PI_Buffer=(float)3.14159265359/180;

#if(IOSTREAN_ON)
	using std::ostream;
	using std::istream;
	using std::cout;
	ostream& operator << (ostream &out, const Vector3D &Zen)
	{
		out<<"X: "<<Zen.x<<" Y: "<<Zen.y<<" Z: "<<Zen.z;
		return out;
	}
	istream& operator >> (istream &in,Vector3D &Zen)
	{
		cout<<"Wprowac x: "; in>>Zen.x;
		cout<<"Wprowac y: "; in>>Zen.y;
		cout<<"Wprowac z: "; in>>Zen.z;
		return in;
	}
#endif
bool operator==(const Vector3D &L,const Vector3D &R)
{
	return L.x==R.x && L.y==R.y && L.z==R.z;
}
bool operator!=(const Vector3D &L,const Vector3D &R)
{
	return !(L.x==R.x && L.y==R.y && L.z==R.z);
}
Vector3D operator*(float Scalar,const Vector3D &Zen)
{
	return Vector3D(Zen.x*Scalar,Zen.y*Scalar,Zen.z*Scalar);
}
float DotProduct(const Vector3D &L,const Vector3D &R)
{
	return L.x*R.x+L.y*R.y+L.z*R.z;
}
Vector3D CrossProduct(const Vector3D &L,const Vector3D &R)
{
	return Vector3D(L.y*R.z-L.z*R.y,L.z*R.x-L.x*R.z,L.x*R.y-L.y*R.x);
}
Vector3D LinearInterpolate(const Vector3D V1,const Vector3D& V2,float Factor)
{
	return V1*(1.0f-Factor) + V2*Factor;
}
Vector3D QuadraticInterpolate(const Vector3D V1,const Vector3D& V2,const Vector3D& V3,float Factor)
{
	return V1*(1.0f-Factor)*(1.0f-Factor) + 2*V2*Factor*(1.0f-Factor) + V3*Factor*Factor;
}
Vector3D::Vector3D(float x, float y, float z):x(x),y(y),z(z)
{
}
Vector3D::Vector3D(const float *Zen):x(Zen[0]),y(Zen[1]),z(Zen[2])
{
}
Vector3D::Vector3D(const Vector3D &Zen):x(Zen.x),y(Zen.y),z(Zen.z)
{
}
Vector3D::~Vector3D(void)
{
}
void Vector3D::LoadZero(void)
{
	x=y=z=0;
}
void Vector3D::LoadOne(void)
{
	x=y=z=1;
}
void Vector3D::Set(float x,float y,float z)
{
	this->x=x;
	this->y=y;
	this->z=z;
}
void Vector3D::Set(const float *Zen)
{
	x=Zen[0];
	y=Zen[1];
	z=Zen[2];
}
void Vector3D::SetX(float x)
{
	this->x=x;
}
void Vector3D::SetY(float y)
{
	this->y=y;
}
void Vector3D::SetZ(float z)
{
	this->z=z;
}
float Vector3D::GetX(void) const
{
	return x;
}
float Vector3D::GetY(void) const
{
	return y;
}
float Vector3D::GetZ(void) const
{
	return z;
}
float Vector3D::GetLength(void) const
{
	return sqrt((x*x)+(y*y)+(z*z));
}
float Vector3D::GetSquaredLength(void) const
{
	return x*x+y*y+z*z;
}
void Vector3D::Normalize(void)
{
	float BufLength=GetLength();
	if(BufLength!=1 || BufLength!=0)
	{
		float Factor;
		Factor=1.0f/BufLength;
		x*=Factor;
		y*=Factor;
		z*=Factor;
	}
}
Vector3D Vector3D::GetNormalized(void) const
{
	float BufLength=GetLength();
	if(BufLength!=1 || BufLength!=0)
	{
		Vector3D Buf(*this);
		float Factor;
		Factor=1.0f/BufLength;
		Buf.x*=Factor;
		Buf.y*=Factor;
		Buf.z*=Factor;
		return Buf;
	}
	return *this;
}
void Vector3D::RotateX(float Angle)
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	float BufY=y;
	y=y*CosAngle - z*SinAngle;
	z=BufY*SinAngle + z*CosAngle;
}
void Vector3D::RotateY(float Angle)
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	float BufX=x;
	x=x*CosAngle + z*SinAngle;
	z=-BufX*SinAngle + z*CosAngle;
}
void Vector3D::RotateZ(float Angle)
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	float BufX=x;
	x=x*CosAngle - y*SinAngle;
	y=BufX*SinAngle + y*CosAngle;
}
void Vector3D::Rotate(float Angle, const Vector3D &Axis)
{
	Vector3D ANorm(Axis);
	ANorm.Normalize();
	Vector3D rotMRow0, rotMRow1, rotMRow2;

	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	float OneMinusCosAngle=1.0f-CosAngle;

	rotMRow0.x=(ANorm.x)*(ANorm.x) + CosAngle*(1-(ANorm.x)*(ANorm.x));
	rotMRow0.y=(ANorm.x)*(ANorm.y)*(OneMinusCosAngle) - SinAngle*ANorm.z;
	rotMRow0.z=(ANorm.x)*(ANorm.z)*(OneMinusCosAngle) + SinAngle*ANorm.y;

	rotMRow1.x=(ANorm.x)*(ANorm.y)*(OneMinusCosAngle) + SinAngle*ANorm.z;
	rotMRow1.y=(ANorm.y)*(ANorm.y) + CosAngle*(1-(ANorm.y)*(ANorm.y));
	rotMRow1.z=(ANorm.y)*(ANorm.z)*(OneMinusCosAngle) - SinAngle*ANorm.x;
	
	rotMRow2.x=(ANorm.x)*(ANorm.z)*(OneMinusCosAngle) - SinAngle*ANorm.y;
	rotMRow2.y=(ANorm.y)*(ANorm.z)*(OneMinusCosAngle) + SinAngle*ANorm.x;
	rotMRow2.z=(ANorm.z)*(ANorm.z) + CosAngle*(1-(ANorm.z)*(ANorm.z));
	Set(DotProduct(*this,rotMRow0),DotProduct(*this,rotMRow1),DotProduct(*this,rotMRow2));
}
Vector3D Vector3D::GetRotatedX(float Angle) const
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	return Vector3D(x,y*CosAngle - z*SinAngle,y*SinAngle + z*CosAngle);
}
Vector3D Vector3D::GetRotatedY(float Angle) const
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	return Vector3D(x*CosAngle + z*SinAngle,y,-x*SinAngle + z*CosAngle);
}
Vector3D Vector3D::GetRotatedZ(float Angle) const
{
	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	return Vector3D(x*CosAngle - y*SinAngle,x*SinAngle + y*CosAngle,z);
}
Vector3D Vector3D::GetRotated(float Angle, const Vector3D &Axis) const
{
	Vector3D ANorm(Axis);
	ANorm.Normalize();
	Vector3D rotMRow0, rotMRow1, rotMRow2;

	float SinAngle=(float)sin(PI_Buffer*Angle);
	float CosAngle=(float)cos(PI_Buffer*Angle);
	float OneMinusCosAngle=1.0f-CosAngle;

	rotMRow0.x=(ANorm.x)*(ANorm.x) + CosAngle*(1-(ANorm.x)*(ANorm.x));
	rotMRow0.y=(ANorm.x)*(ANorm.y)*(OneMinusCosAngle) - SinAngle*ANorm.z;
	rotMRow0.z=(ANorm.x)*(ANorm.z)*(OneMinusCosAngle) + SinAngle*ANorm.y;

	rotMRow1.x=(ANorm.x)*(ANorm.y)*(OneMinusCosAngle) + SinAngle*ANorm.z;
	rotMRow1.y=(ANorm.y)*(ANorm.y) + CosAngle*(1-(ANorm.y)*(ANorm.y));
	rotMRow1.z=(ANorm.y)*(ANorm.z)*(OneMinusCosAngle) - SinAngle*ANorm.x;
	
	rotMRow2.x=(ANorm.x)*(ANorm.z)*(OneMinusCosAngle) - SinAngle*ANorm.y;
	rotMRow2.y=(ANorm.y)*(ANorm.z)*(OneMinusCosAngle) + SinAngle*ANorm.x;
	rotMRow2.z=(ANorm.z)*(ANorm.z) + CosAngle*(1-(ANorm.z)*(ANorm.z));
	return  Vector3D(DotProduct(*this,rotMRow0),DotProduct(*this,rotMRow1),	DotProduct(*this,rotMRow2));
}
void Vector3D::Reflection(const Vector3D &Normal)
{
	Vector3D Bufor=GetNormalized();
	*this=(Bufor-Normal*2.0*(DotProduct(Bufor,Normal)))*GetLength();
}
Vector3D Vector3D::GetReflection(const Vector3D &Normal) const
{
	Vector3D Bufor=GetNormalized();
	return (Bufor-Normal*2.0*(DotProduct(Bufor,Normal)))*GetLength();
}
Vector3D Vector3D::operator+(const Vector3D& Zen) const
{
	return Vector3D(x+Zen.x,y+Zen.y,z+Zen.z);
}
Vector3D Vector3D::operator-(const Vector3D& Zen) const
{
	return Vector3D(x-Zen.x,y-Zen.y,z-Zen.z);;
}
Vector3D Vector3D::operator*(const float Scalar) const
{
	return Vector3D(x*Scalar,y*Scalar,z*Scalar);
}
Vector3D Vector3D::operator/(const float Scalar) const
{
	return Scalar?Vector3D(x/Scalar,y/Scalar,z/Scalar):Vector3D(0,0,0);
}
void Vector3D::operator=(const Vector3D& Zen)
{
	x=Zen.x;
	y=Zen.y;
	z=Zen.z;
}
Vector3D Vector3D::operator+(const Vector3D& Zen)
{
	return Vector3D(x+Zen.x,y+Zen.y,z+Zen.z);
}
Vector3D Vector3D::operator-(const Vector3D& Zen)
{
	return Vector3D(x-Zen.x,y-Zen.y,z-Zen.z);;
}
Vector3D Vector3D::operator*(const float Scalar)
{
	return Vector3D(x*Scalar,y*Scalar,z*Scalar);
}
Vector3D Vector3D::operator/(const float Scalar)
{
	return Scalar?Vector3D(x/Scalar,y/Scalar,z/Scalar):Vector3D(0,0,0);
}
void Vector3D::operator+=(const Vector3D& Zen)
{
	x+=Zen.x;
	y+=Zen.y;
	z+=Zen.z;
}
void Vector3D::operator-=(const Vector3D& Zen)
{
	x-=Zen.x;
	y-=Zen.y;
	z-=Zen.z;
}
void Vector3D::operator*=(const float Scalar)
{
	x=x*Scalar;
	y=y*Scalar;
	z=z*Scalar;
}
void Vector3D::operator/=(const float Scalar)
{
	if(Scalar)
	{
		x=x/Scalar;
		y=y/Scalar;
		z=z/Scalar;
	}
}
Vector3D Vector3D::operator-(void)
{
	return Vector3D(-x,-y,-z);
}
Vector3D Vector3D::operator+(void) 
{
	return *this;
}
Vector3D::operator const float*(void)
{
	return (const float*)this;
}
Vector3D::operator float*(void)
{
	return (float*)this;
}