#pragma once

#include "../Log/ZLog.h"
#include "../Tree/ZTree.h"
#include "../ZDate.h"
#include "../Manager/ZManager.h"
#include "../Physisc/ZPhysisc.h"

class ZObject : public ZTree
{
//private:
protected:
	Matrix4x4 Alpha;
	Matrix4x4 Beta;
	Matrix4x4 Gamma;

	Matrix4x4 ProjectionMatrix;
	Matrix4x4 ViewMatrix;
	Matrix4x4 ModelBackMatrix;					//Macierz transformacji od root do parent
	ZObject *Camera;
protected:
	virtual bool ZOnCollision(ZObject *Zen){return false;}		//Wykrywa zderzenia; //true by�o false nie by�o
public:
	ZObject(ZTree *Parent=0);
	virtual ~ZObject(void);

	static ZManager Manager;
	ZPhysisc Physisc;
	ZDate Date;

	ZCursor TexturesId;
	ZCursor MaterialId;
	ZCursor LightId;
	ZCursor FragmentId;
	ZCursor VertexId;

	Matrix4x4 ModelMatrix;
public:
	virtual Matrix4x4 ZGetModelMatrix(void);
	virtual Matrix4x4 ZGetViewMatrix(void);
	virtual Matrix4x4 ZGetProjectionMatrix(void);
	virtual Matrix4x4 ZGetModelViewMatrix(void);
	virtual Matrix4x4 ZGetModelViewProjMatrix(void);

	virtual void ZLoad(void);
	virtual void ZCollision(ZObject *Zen);		// Wykrywa zderzenia;
	virtual void ZPrepare(void);				//Przygotowanie obiekt�w -> Wykrywanie zderze�
	virtual void ZAnimate(float DeltaTime);		//Wyznacza po�o�enie obiekt�w -> ZCalculateScene();
public:
	virtual void ZSetTexture(unsigned int NrTexture);
};