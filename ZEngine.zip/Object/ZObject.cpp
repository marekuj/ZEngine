#include "ZObject.h"

ZManager ZObject::Manager;

ZObject::ZObject(ZTree *Parent):ZTree(Parent)
{
	ComponentName="ZObject";
	Camera = 0;
//		(ZObject*)ZFindIdUp("ZCamera");
	TexturesId.Creator=this;
	MaterialId.Creator=this;
	LightId.Creator=this;
	VertexId.Creator=this;
	FragmentId.Creator=this;
}
ZObject::~ZObject(void)
{
}
Matrix4x4 ZObject::ZGetModelMatrix(void)
{
	return ModelBackMatrix*ModelMatrix;
}
Matrix4x4 ZObject::ZGetViewMatrix(void)
{
	return ViewMatrix;
}
Matrix4x4 ZObject::ZGetProjectionMatrix(void)
{
	return ProjectionMatrix;
}
Matrix4x4 ZObject::ZGetModelViewMatrix(void)
{
	return ViewMatrix*(ModelBackMatrix*ModelMatrix);
}
Matrix4x4 ZObject::ZGetModelViewProjMatrix(void)
{
	return ProjectionMatrix*ViewMatrix*(ModelBackMatrix*ModelMatrix);
}
void ZObject::ZLoad(void)
{
	Camera = (ZObject*)ZFindIdUp("ZCamera");
	//Matrix4x4 *A=&Camera->ProjectionMatrix;
	#ifdef Z_TREE_LOG
	ZPrintChapterLog(Z_FILE_NAME_LOG,Z_TREE_OBJECT_NAME_LOG,typeid(*this).name());
	if(Camera) ZPrintLog(Z_FILE_NAME_LOG,Z_TREE_FIND_COMPONENT_LOG_OK,"ZCamera");
	else ZPrintLog(Z_FILE_NAME_LOG,Z_TREE_FIND_COMPONENT_LOG_ERROR,"ZCamera");
	#endif
	ZTree::ZLoad();
}
void ZObject::ZCollision(ZObject *Zen)
{
	if(ZOnCollision(Zen))
	{
		if(ZHasChild())
			((ZObject*)ChildNode)->ZCollision(Zen);
		if(ZHasParent() && !ZIsLastChild())
			((ZObject*)NextNode)->ZCollision(Zen);
	}
	if(Zen->ZHasChild())
		ZCollision((ZObject*)Zen->ChildNode);
	if(Zen->ZHasParent() && !Zen->ZIsLastChild())
		ZCollision((ZObject*)Zen->NextNode);
}
void ZObject::ZPrepare(void)
{
	ZCollision((ZObject*)ZFindRoot());	
	ZTree::ZPrepare();
}
void ZObject::ZAnimate(float DeltaTime)
{
	ProjectionMatrix=Camera->ZGetProjectionMatrix();
	ViewMatrix=Camera->ZGetViewMatrix();
	ModelBackMatrix=((ZObject*)ParentNode)->ZGetModelMatrix();
	Physisc.BackPosition.Set(ModelBackMatrix.GetColumn(3));
	ZTree::ZAnimate(DeltaTime);
}
void ZObject::ZSetTexture(unsigned int NrTexture)
{
	if(Manager.Texture.ZGetAnisotropy()>1)
		glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAX_ANISOTROPY_EXT,Manager.Texture.ZGetAnisotropy());
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

//	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR_MIPMAP_LINEAR);
//	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, 16);
//**********************************************************************************
}
