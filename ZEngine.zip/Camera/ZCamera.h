#pragma once

#include <windows.h>
#include "../Type/ZType.h"
#include "../Tree/ZTree.h"
#include "../Object/ZObject.h"

class ZCamera : public ZObject
{
public:
private:
	bool CameraType;
	bool InterfaceCamera;			//Czy stoi dla Orto2d

	int Width; 
	int Height;
	double Scale;

	double Fovy; 
	double Aspect;
	double ZNear;
	double ZFar;

	int CenterX; 
	int CenterY;
	int MouseX;
	int MouseY;

	float DeltaMouse;
	POINT Mouse;
	float Sensitivity;

	float MaxPitchRate;
	float MaxHeadingRate;
	float HeadingDegrees;
	float PitchDegrees;
	float MaxForwardVelocity;
	
	Vector3D Position;
	Vector3D DirectionVector;
	
	Quaternion QuaternionHeading;
	Quaternion QuaternionPitch;
	float ForwardVelocity;

	Matrix4x4 ProjectionMatrix;
	Matrix4x4 ViewMatrix;		//to zrobi�!
public:

	ZCamera(ZTree *Parent=0);
	virtual ~ZCamera(void);

	void ZSetPerspCam(int Width, int Height,double Fovy=45,double ZNear=1,double ZFar=100);
	void ZSetOrthoCam(int Width, int Height, double Scale=10);
	void ZSetInterface(bool T=1);

	virtual void ZOnDraw(void);
	virtual void ZDraw(void);
	virtual void ZOnAnimate(float &DeltaTime);
//	virtual void ZDrawBuffer(void);

	void ZSetMove(float MaxForwardVelocity,float MaxPitchRate,float MaxHeadingRate,
					   float PitchDegrees,float HeadingDegrees);
	void ZChangeVelocity(float Vel);		//zmiana predko�ci 	
	void ZChangeHeading(float Degrees);		//zmiana kierunku
	void ZChangePitch(float Degrees);		//zmiana pochylenie
	
	float ZGetSensitivity(void);				//Pobira Czu�o�� myszki
	void ZSetSensitivity(float Sensitivity);	//Ustawia Czu�o�� myszki
	void ZCheckMouse(void);						//zmiana z myszki:)
	void ZCheckMouse(int X,int Y,int Dx,int Dy);

	virtual Matrix4x4 ZGetModelMatrix(void){return Matrix4x4();}
	virtual Matrix4x4 ZGetModelViewMatrix(void){return Matrix4x4();}
	virtual Matrix4x4 ZGetModelViewProjMatrix(void){return Matrix4x4();}

	virtual Matrix4x4 ZGetViewMatrix(void);
	virtual Matrix4x4 ZGetProjectionMatrix(void);

	virtual void ZAnimate(float DeltaTime);
};
