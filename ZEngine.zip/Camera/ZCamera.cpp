#include "ZCamera.h"

#define _USE_MATH_DEFINES
#include <cmath>

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

ZCamera::ZCamera(ZTree *Parent):ZObject(Parent)
{
	ComponentName="ZCamera";

	CameraType=0;
	InterfaceCamera=1;

	Width=0;
	Height=0;
	Scale=0;
	
	Fovy=0; 
	Aspect=0;
	ZNear=0;
	ZFar=0;

	CenterX=0; 
	CenterY=0;
	MouseX=0;
	MouseY=0;
	DeltaMouse=0;
	Mouse.x=0;
	Mouse.y=0;
	Sensitivity=1.0f;

	MaxPitchRate=0;
	MaxHeadingRate=0;
	HeadingDegrees=0;
	PitchDegrees=0;
	MaxForwardVelocity=0;
	ForwardVelocity=0;
}
ZCamera::~ZCamera(void)
{
}
void ZCamera::ZSetPerspCam(int Width, int Height,double Fovy,double ZNear,double ZFar)
{
	CameraType=0;
	CenterX=Width/2;
	CenterY=Height/2;

	if (Height==0)	Height=1;
	this->Width=Width;
	this->Height=Height;
	this->Fovy=Fovy;
	this->ZNear=ZNear;
	this->ZFar=ZFar;

	this->Aspect=(float)this->Width/(float)this->Height;
	#ifdef Z_OPENGL_ENABLE_STATE
	glViewport(0,0,Width,Height);
	glMatrixMode(GL_PROJECTION);
	ProjectionMatrix.SetPerspective((float)Fovy,(float)Aspect,(float)ZNear,(float)ZFar);	//<->	gluPerspective(Fovy,Aspect,4,ZFar);
	glLoadMatrixf(ProjectionMatrix);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	#else
	glViewport(0,0,Width,Height);
	ProjectionMatrix.SetPerspective((float)Fovy,(float)Aspect,(float)ZNear,(float)ZFar);	//<->	gluPerspective(Fovy,Aspect,4,ZFar);
	#endif
}
void ZCamera::ZSetOrthoCam(int Width, int Height, double Scale)
{
	CameraType=1;
	CenterX=Width/2;
	CenterY=Height/2;

	if (Height==0)	Height=1;

	this->Width=Width;
	this->Height=Height;
	this->Scale=Scale;
	
	#ifdef Z_OPENGL_ENABLE_STATE
	glViewport(0,0,Width,Height);
    glMatrixMode(GL_PROJECTION);
	if(Width<=Height) ProjectionMatrix.SetOrtho(-(float)Scale,(float)Scale,-(float)Scale*(float)Height/(float)Width,(float)Scale*(float)Height/(float)Width,-(float)Scale,(float)Scale);
    else ProjectionMatrix.SetOrtho(-(float)Scale*(float)Width/(float)Height,(float)Scale*(float)Width/(float)Height,-(float)Scale,(float)Scale,-(float)Scale,(float)Scale);
	glLoadMatrixf(ProjectionMatrix);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
	#else
	glViewport(0,0,Width,Height);
	if(Width<=Height) ProjectionMatrix.SetOrtho(-(float)Scale,(float)Scale,-(float)Scale*(float)Height/(float)Width,(float)Scale*(float)Height/(float)Width,-(float)Scale,(float)Scale);
    else ProjectionMatrix.SetOrtho(-(float)Scale*(float)Width/(float)Height,(float)Scale*(float)Width/(float)Height,-(float)Scale,(float)Scale,-(float)Scale,(float)Scale);
	#endif
}
void ZCamera::ZSetInterface(bool T)
{
	InterfaceCamera=T;
}
void ZCamera::ZDraw(void)
{
	#ifdef Z_OPENGL_ENABLE_STATE
	if(CameraType && InterfaceCamera)
	{
		glPushAttrib(GL_ALL_ATTRIB_BITS);
			glDisable(GL_FOG);
			glDisable(GL_LIGHTING);
			glDisable(GL_DEPTH_TEST);
			glDisable(GL_TEXTURE_2D);
		glPushMatrix();
			glLoadIdentity();
			ZTree::ZDraw();
		glPopMatrix();
		glPopAttrib();
	}
	else
	{
		ZTree::ZDraw();
	}
	#else
	ZTree::ZDraw();
	#endif
}
void ZCamera::ZOnDraw(void)
{	
	#ifdef Z_OPENGL_ENABLE_STATE
	if(CameraType)		//OrthoCamera
	{
		glMatrixMode(GL_PROJECTION);
		if(Width<=Height) ProjectionMatrix.SetOrtho(-(float)Scale,(float)Scale,-(float)Scale*(float)Height/(float)Width,(float)Scale*(float)Height/(float)Width,-(float)Scale,(float)Scale);
		else ProjectionMatrix.SetOrtho(-(float)Scale*(float)Width/(float)Height,(float)Scale*(float)Width/(float)Height,-(float)Scale,(float)Scale,-(float)Scale,(float)Scale);
		glLoadMatrixf(ProjectionMatrix);
		glMatrixMode(GL_MODELVIEW);
		glLoadMatrixf(ViewMatrix);
	}
	else				//PerspCamera
	{
		glMatrixMode(GL_PROJECTION);
		ProjectionMatrix.SetPerspective((float)Fovy,(float)Aspect,(float)ZNear,(float)ZFar);	//<->	gluPerspective(Fovy,Aspect,4,ZFar);
		glLoadMatrixf(ProjectionMatrix);
		glMatrixMode(GL_MODELVIEW);
		glLoadMatrixf(ViewMatrix);
	}
	#else
	if(CameraType)		//OrthoCamera
	{
//			glMatrixMode(GL_PROJECTION);
		if(Width<=Height) ProjectionMatrix.SetOrtho(-(float)Scale,(float)Scale,-(float)Scale*(float)Height/(float)Width,(float)Scale*(float)Height/(float)Width,-(float)Scale,(float)Scale);
		else ProjectionMatrix.SetOrtho(-(float)Scale*(float)Width/(float)Height,(float)Scale*(float)Width/(float)Height,-(float)Scale,(float)Scale,-(float)Scale,(float)Scale);

		glLoadMatrixf(ProjectionMatrix); // to skasowa� po zrobieniu schadera dla literek

//			glMatrixMode(GL_MODELVIEW);
//			glLoadMatrixf(ViewMatrix);
	}
	else				//PerspCamera
	{
//			glMatrixMode(GL_PROJECTION);
		ProjectionMatrix.SetPerspective((float)Fovy,(float)Aspect,(float)ZNear,(float)ZFar);	//<->	gluPerspective(Fovy,Aspect,4,ZFar);
//			glLoadMatrixf(ProjectionMatrix);
//			glMatrixMode(GL_MODELVIEW);
//			glLoadMatrixf(ViewMatrix);
	}
	#endif
}
//void ZCamera::ZDrawBuffer(void)
//{
//}
void ZCamera::ZOnAnimate(float &DeltaTime)
{
	static Quaternion BufQuaternion;
	static Matrix4x4 BufMatrix;

	// Make the Quaternions that will represent our rotations
	QuaternionPitch.ZCreateFromAxisAngle(1.0f, 0.0f, 0.0f, PitchDegrees);
	QuaternionHeading.ZCreateFromAxisAngle(0.0f, 1.0f, 0.0f, HeadingDegrees);
	
	// Combine the pitch and heading rotations and store the results in q
	BufQuaternion = QuaternionPitch*QuaternionHeading;
	BufQuaternion.ZCreateMatrix4x4(BufMatrix);
	ViewMatrix=BufMatrix;
	// Let OpenGL set our new prespective on the world!
	
	// Create a matrix from the pitch Quaternion and get the j vector 
	// for our direction.
	QuaternionPitch.ZCreateMatrix4x4(BufMatrix);
	DirectionVector.SetY(BufMatrix.GetCell(9));
	// Combine the heading and pitch rotations and make a matrix to get
	// the i and j vectors for our direction.
	BufQuaternion = QuaternionHeading*QuaternionPitch;
	BufQuaternion.ZCreateMatrix4x4(BufMatrix);
	DirectionVector.SetX(BufMatrix.GetCell(8));
	DirectionVector.SetZ(BufMatrix.GetCell(10));

	// Scale the direction by our speed.
	DirectionVector *= ForwardVelocity;
	// Increment our position by the vector
	Position+=DirectionVector;
	// Translate to our new position.
	BufMatrix.SetTranslation(Vector3D(-Position.GetX(), -Position.GetY(), Position.GetZ()));
	ViewMatrix*=BufMatrix;

//	ViewMatrix.SetLookAt(Vector3D(0,0,0),Vector3D(0,0,-3),Vector3D(0,1,0));
}
void ZCamera::ZSetMove(GLfloat MaxForwardVelocity,GLfloat MaxPitchRate,GLfloat MaxHeadingRate,
					   GLfloat PitchDegrees,GLfloat HeadingDegrees)
{
	this->MaxForwardVelocity=MaxForwardVelocity;
	this->MaxPitchRate=MaxPitchRate;
	this->MaxHeadingRate=MaxHeadingRate;
	this->PitchDegrees=PitchDegrees;
	this->HeadingDegrees=HeadingDegrees;
}
void ZCamera::ZChangePitch(GLfloat Degrees)
{
	if(fabs(Degrees) < fabs(MaxPitchRate))
	{
		// Our pitch is less than the max pitch rate that we 
		// defined so lets increment it.
		PitchDegrees += Degrees;
	}
	else
	{
		// Our pitch is greater than the max pitch rate that
		// we defined so we can only increment our pitch by the 
		// maximum allowed value.
		if(Degrees < 0)
		{
			// We are pitching down so decrement
			PitchDegrees -= MaxPitchRate;
		}
		else
		{
			// We are pitching up so increment
			PitchDegrees += MaxPitchRate;
		}
	}

	// We don't want our pitch to run away from us. Although it
	// really doesn't matter I prefer to have my pitch Degrees
	// within the range of -360.0f to 360.0f
	if(PitchDegrees > 360.0f)
	{
		PitchDegrees -= 360.0f;
	}
	else if(PitchDegrees < -360.0f)
	{
		PitchDegrees += 360.0f;
	}
}

void ZCamera::ZChangeHeading(GLfloat Degrees)
{
	if(fabs(Degrees) < fabs(MaxHeadingRate))
	{
		// Our Heading is less than the max heading rate that we 
		// defined so lets increment it but first we must check
		// to see if we are inverted so that our heading will not
		// become inverted.
		if(PitchDegrees > 90 && PitchDegrees < 270 || (PitchDegrees < -90 && PitchDegrees > -270))
		{
			HeadingDegrees -= Degrees;
		}
		else
		{
			HeadingDegrees += Degrees;
		}
	}
	else
	{
		// Our heading is greater than the max heading rate that
		// we defined so we can only increment our heading by the 
		// maximum allowed value.
		if(Degrees < 0)
		{
			// Check to see if we are upside down.
			if((PitchDegrees > 90 && PitchDegrees < 270) || (PitchDegrees < -90 && PitchDegrees > -270))
			{
				// Ok we would normally decrement here but since we are upside
				// down then we need to increment our heading
				HeadingDegrees += MaxHeadingRate;
			}
			else
			{
				// We are not upside down so decrement as usual
				HeadingDegrees -= MaxHeadingRate;
			}
		}
		else
		{
			// Check to see if we are upside down.
			if(PitchDegrees > 90 && PitchDegrees < 270 || (PitchDegrees < -90 && PitchDegrees > -270))
			{
				// Ok we would normally increment here but since we are upside
				// down then we need to decrement our heading.
				HeadingDegrees -= MaxHeadingRate;
			}
			else
			{
				// We are not upside down so increment as usual.
				HeadingDegrees += MaxHeadingRate;
			}
		}
	}
	
	// We don't want our heading to run away from us either. Although it
	// really doesn't matter I prefer to have my heading Degrees
	// within the range of -360.0f to 360.0f
	if(HeadingDegrees > 360.0f)
	{
		HeadingDegrees -= 360.0f;
	}
	else if(HeadingDegrees < -360.0f)
	{
		HeadingDegrees += 360.0f;
	}
}

void ZCamera::ZChangeVelocity(GLfloat Vel)
{
	if(fabs(Vel) < fabs(MaxForwardVelocity))
	{
		// Our velocity is less than the max velocity increment that we 
		// defined so lets increment it.
		ForwardVelocity += Vel;
	}
	else
	{
		// Our velocity is greater than the max velocity increment that
		// we defined so we can only increment our velocity by the 
		// maximum allowed value.
		if(Vel < 0)
		{
			// We are slowing down so decrement
			ForwardVelocity -= -MaxForwardVelocity;
		}
		else
		{
			// We are speeding up so increment
			ForwardVelocity += MaxForwardVelocity;
		}
	}
}
float ZCamera::ZGetSensitivity(void)
{
	return Sensitivity;
}
void ZCamera::ZSetSensitivity(float Sensitivity)
{
	if(Sensitivity>0)
		this->Sensitivity=Sensitivity;
	else Sensitivity=0;
}
void ZCamera::ZCheckMouse(void)
{
	GetCursorPos(&Mouse);
	MouseX = Mouse.x;
	MouseY = Mouse.y;
	if(MouseX < CenterX)
	{
		DeltaMouse = GLfloat(CenterX-MouseX);

		ZChangeHeading(-0.2f*Sensitivity*DeltaMouse);
	}
	else if(MouseX > CenterX)
	{
		DeltaMouse = GLfloat(MouseX-CenterX);

		ZChangeHeading(0.2f*Sensitivity*DeltaMouse);
	}
	if(MouseY < CenterY)
	{
		DeltaMouse = GLfloat(CenterY-MouseY);

		ZChangePitch(-0.2f*Sensitivity*DeltaMouse);
	}
	else if(MouseY > CenterY)
	{
		DeltaMouse = GLfloat(MouseY-CenterY);

		ZChangePitch(0.2f*Sensitivity*DeltaMouse);
	}
	SetCursorPos(CenterX, CenterY);
}
void ZCamera::ZCheckMouse(int X,int Y,int Dx,int Dy)
{
	if(X < Dx)
	{
		ZChangeHeading(-0.2f*Dx);
	}
	else if(X > Dx)
	{
		ZChangeHeading(0.2f*Dx);
	}
	if(Y < Dy)
	{
		ZChangePitch(-0.2f*Dy);
	}
	else if(Y > Dy)
	{
		ZChangePitch(0.2f*Dy);
	}
	//SetCursorPos(X,Y);
}
Matrix4x4 ZCamera::ZGetViewMatrix(void)
{
	return ViewMatrix;
}
Matrix4x4 ZCamera::ZGetProjectionMatrix(void)
{
	return ProjectionMatrix;
}
void ZCamera::ZAnimate(float DeltaTime)
{
	ZTree::ZAnimate(DeltaTime);
}