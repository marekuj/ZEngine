#pragma once

#include <string>

#include "../Log/ZLog.h"

#include "../Timer/ZTimer.h"
#include "../Type/ZOpenGL.h"
#include "../Object/ZObject.h"
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glext.h>
#include <gl/wglext.h>

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")

#include "../ZWinStruct.h"

class ZBaseEngine : private ZObject
{
private:
	ZTimer Timer;

	bool FullScreen;
	bool Keys[256];
	long Width;
	long Height;
	long Aspect;

	LPARAM Drag;	// mouse drag
	bool bLMB;		// left mouse button
	bool bRMB;		// right mouse button
	int MouseX;		//po�o�enie kursora w poziomie
	int MouseY;		//po�o�enie kursora w pionie

	bool Error;
private:
	int ZGetMouseX(LPARAM lParam);		// get true mouse coordinates
	int ZGetMouseY(LPARAM lParam);
	float ZGetNormalizedPosX(LPARAM lParam);	// get normalized mouse coordinates
	float ZGetNormalizedPosY(LPARAM lParam);	// between (-1.0 and 1.0)
public:
	ZCamera *CameraLook;
	ZCamera *CameraHud;
	ZTree *Root;

	friend LRESULT APIENTRY ZWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
protected:
	//to da� do ZWndProc
	virtual bool ZOnCreate(void) { return true; }
	virtual bool ZOnClose(void) { return true; }
	virtual void ZOnSize(void) { }
	virtual void ZOnMouseDownL(float x, float y) { }
	virtual void ZOnMouseDownR(float x, float y) { }
	virtual void ZOnMouseUpL(void) { }
	virtual void ZOnMouseUpR(void) { }
	virtual void ZOnMouseMove(int x, int y, int centerX, int centerY){ }
	virtual void ZOnMouseMove(int deltaX, int deltaY) { }
	virtual void ZOnMouseDragL(int x, int y, int dx, int dy) { }
	virtual void ZOnMouseDragR(int x, int y, int dx, int dy) { }
	virtual void ZOnCommand(WORD wNotifyCode, WORD wID, HWND hWndCtrl) { }
	virtual void ZOnContextMenu(HWND hWnd, int x, int y) { }
	virtual void ZOnKeyUp(int nVirtKey) { }
	virtual void ZOnInitMenu(HMENU hMenu) { }
	virtual void ZOnKeyDown(int nVirtKey) { }
	virtual void ZOnChar(char c) { }
public :
	ZBaseEngine(void);														//Konstruktor
	virtual ~ZBaseEngine(void);												//Destruktor

	ZWindow Window;							//Przechowuje dane o oknie Windows
	ZOpenGL OpenGL;							//Przechowuje stany OpenGL

	void ZSetCameraLook(ZCamera *Camera);		//Pobiera kamere
	void ZSetCameraHud(ZCamera *Camera);		//Pobiera kamere
	void ZSetRoot(ZTree *Root);			//Pobiera uchwyt do obiekt�w
	bool ZCheck(void);					//Sprawdza czy s� dostarczone Camera i Root (0 - ok | 1 - error) 

	virtual void ZLoad(void);					//Wczytanie obiekt�w
	virtual void ZPrepare(void);				//Przygotowanie obiekt�w -> Wykrywanie zderze�
	virtual void ZDraw(void);					//Rysuje obiekty -> ZDrawScene();
	virtual void ZAnimate(float DeltaTime);		//Wyznacza po�o�enie obiekt�w -> ZCalculateScene();

	virtual void ZCycle(float DeltaTime);	//Cykl wykonywalny programu

	LRESULT ZEnterMessageLoop(void);		//Petla komunikat�w Windows 

	virtual void ZCheckInput(float &DeltaTime){}
	//Begin Dodatkowe
	virtual void ZCreateObject(void){}
	virtual void ZSetObject(void){}
	virtual void ZUpdateObject(void){}
	virtual void ZDestrojObject(void){}
	//End Dodatkowe
	
	bool ZCreateEngine(ZInitEngine &Zen);		//Tworzy obiekt gry

	bool ZEnableOpenGL (const char* Title,int Width, int Height,
						int ColorBits=32, bool FullScreenFlag=0);		//(0 - ok, 1 - Error) 
	void ZDisableOpenGL (void);
	bool ZEnableFSAA(const char* Title,int Width,int Height,
					 int ColorBits=32,int Samples=4);					//FSAA -> MULTISAMPLE (0 - ok, 1 - Error) 
	bool ZEnableExtension(void);										//(0 - ok, 1 - Error) 

	void ZEnablePixelBuffer(ZPixelBuffer *ZPixBuf);
	void ZDisablePixelBuffer(ZPixelBuffer *ZPixBuf);
	//Zegar
	int  ZGetFPS(void);
	//Sprawdza klawisze
	void ZSetKeys(int Key,bool T);
	bool ZGetKeys(int Key);

	//Obs�uga komunikat�w
	void ZErrorExtensionMessageBox(const char *FileName);

	virtual void ZMessageBox(std::string Message);			//Wypisanie b�edu i wyj�cie z programu
	virtual void ZMessageBox(const char *Message);			//Wypisanie komunikatu
	virtual void ZErrorMessageBox(std::string Mesage);		//Wypisanie b�edu i wyj�cie z programu
	virtual void ZErrorMessageBox(const char *Message);		//Wypisanie komunikatu
	virtual void ZErrorLoadMessageBox(const char *FileName);	//B��d wczytania pliku
	virtual void ZErrorLoadMessageBox(std::string FileName);	//B��d wczytania pliku

	void ZShowCursor(bool T=1);
	void ZSetWindowField(long WinWidth,long WinHeight);

	char* ZPrintScreenBMP(char* FileName);			//Zapisuje aktualna klatk� na dysk(~0 - ok |0 - error
	char* ZPrintScreenTGA(char* FileName);			//Zapisuje aktualna klatk� na dysk(~0 - ok |0 - error
};