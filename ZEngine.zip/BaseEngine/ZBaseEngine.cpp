#include "ZBaseEngine.h"

#include <windows.h>
#include "../Extension/ZExtension.h"

using std::string;
#include <fstream>
using std::ifstream;
using std::cout;
using std::endl;
using std::ios;

ZBaseEngine* VoidEngine=0;

LRESULT APIENTRY ZWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	static int x=0; 
	static int y=0;
	static int dx=0;
	static int dy=0;

	switch (uMsg)
    {
    case WM_CREATE:
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	case WM_ACTIVATEAPP:		// activate app
		//if (wParam)
		//{	
		//	ShowWindow(VoidEngine->Window.hWnd, SW_RESTORE);
		//	UpdateWindow(VoidEngine->Window.hWnd);
		//}
		//else
		//{	
		//	ShowWindow(VoidEngine->Window.hWnd, SW_MINIMIZE);
		//	UpdateWindow(VoidEngine->Window.hWnd);
		//}
		return 0;
	case WM_SIZE:		
		switch (wParam)	
		{
			case SIZE_MINIMIZED:
				break;				
			case SIZE_MAXIMIZED:
				break;						
			case SIZE_RESTORED:				
				break;				
		}
		VoidEngine->ZSetWindowField(LOWORD (lParam), HIWORD (lParam));
		if(VoidEngine->CameraLook && VoidEngine->CameraHud)
		{
			VoidEngine->CameraLook->ZSetPerspCam(LOWORD (lParam), HIWORD (lParam),45,0.1,1000);
			VoidEngine->CameraHud->ZSetOrthoCam(LOWORD (lParam), HIWORD (lParam),1);
		}
		return 0;
	case WM_MOUSEMOVE:			// mouse movement
		x=VoidEngine->ZGetMouseX(lParam); 
		y=VoidEngine->ZGetMouseY(lParam);
		dx=x-VoidEngine->ZGetMouseX(VoidEngine->Drag);
		dy=y-VoidEngine->ZGetMouseY(VoidEngine->Drag);

		VoidEngine->ZOnMouseMove(x,y,VoidEngine->Width,VoidEngine->Height);
		// left mouse button
		if (VoidEngine->bLMB)
		{
			VoidEngine->ZOnMouseDragL(x,y,dx,dy);
		}
		// right mouse button
		if (VoidEngine->bRMB)
		{	
			VoidEngine->ZOnMouseDragR(x,y,dx,dy);
		}
		VoidEngine->Drag=lParam;
		//VoidEngine->CameraLook->ZCheckMouse();
		return 0;
	case WM_LBUTTONDOWN:		// left mouse button
		VoidEngine->Drag=lParam;
		VoidEngine->bLMB=true;
		VoidEngine->ZOnMouseDownL(VoidEngine->ZGetNormalizedPosX(lParam),VoidEngine->ZGetNormalizedPosY(lParam));
		return 0;
	case WM_RBUTTONDOWN:		// right mouse button
		VoidEngine->Drag=lParam;
		VoidEngine->bRMB=true;
		VoidEngine->ZOnMouseDownR(VoidEngine->ZGetNormalizedPosX(lParam),VoidEngine->ZGetNormalizedPosY(lParam));
		return 0;
	case WM_LBUTTONUP:			// left button release
		VoidEngine->bLMB=false;
		VoidEngine->ZOnMouseUpL();
		return 0;
	case WM_RBUTTONUP:			// right button release
		VoidEngine->bRMB = false;
		VoidEngine->ZOnMouseUpR();
		return 0;
    case WM_KEYDOWN:
		VoidEngine->ZOnKeyUp(wParam);
		VoidEngine->ZSetKeys(wParam,1);
		return 0;
	case WM_KEYUP:
		VoidEngine->ZOnKeyDown(wParam);
		VoidEngine->ZSetKeys(wParam,0);
		return 0;
	default:
        return DefWindowProc(hWnd, uMsg, wParam, lParam);
    }
    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}
ZBaseEngine::ZBaseEngine(void):ZObject(0)
{
	#ifdef Z_ENABLE_LOG
	ZPrintBeginLog(Z_FILE_NAME_LOG);
	#endif
	ComponentName="ZBaseEngine"; 
	memset(Keys,0,sizeof(Keys[0])*256);
	Drag = 0;
	bLMB = false;
	bRMB = false;
	MouseX=0;
	MouseY=0;
	FullScreen=0;
	Width=0;
	Height=0;
	Aspect=0;
	Camera=0;
	CameraLook=0;
	CameraHud=0;
	Root=0;
	Error=false;

	VoidEngine=this;
}
ZBaseEngine::~ZBaseEngine(void)
{
	if(Root) delete Root;
}
int ZBaseEngine::ZGetMouseX(LPARAM lParam)
{
	MouseX=LOWORD(lParam);
	return MouseX;
}
int ZBaseEngine::ZGetMouseY(LPARAM lParam)
{
	MouseY=HIWORD(lParam);
	return MouseY;
}
float ZBaseEngine::ZGetNormalizedPosX(LPARAM lParam)
{
	if(VoidEngine->CameraLook)
	return CameraLook->ZGetSensitivity() * (float)((short)LOWORD(lParam) - Width/2) / Aspect;
	return 0;
}
float ZBaseEngine::ZGetNormalizedPosY(LPARAM lParam)
{
	if(VoidEngine->CameraLook)
	return CameraLook->ZGetSensitivity() * (float)((short)HIWORD(lParam) - Height/2) / Aspect;
	return 0;
}
void ZBaseEngine::ZSetCameraLook(ZCamera *Camera)
{
	if(Camera)
		CameraLook=Camera;
}
void ZBaseEngine::ZSetCameraHud(ZCamera *Camera)
{
	if(Camera)
		CameraHud=Camera;
}
void ZBaseEngine::ZSetRoot(ZTree *Root)
{
	if(Root)
	{
		this->Root=Root;
		Root->ZAttachTo(this);
	}
}
void ZBaseEngine::ZLoad(void)
{
	if(Timer.ZSet()) ZErrorMessageBox("System not support a high-resolution performance counter.");
	Root->ZLoad();
}
void ZBaseEngine::ZPrepare(void)
{
	Root->ZPrepare();
}
void ZBaseEngine::ZDraw(void)
{
	Root->ZDraw();
}
void ZBaseEngine::ZAnimate(float DeltaTime)
{
	Manager.Texture.ZCleanTexture(DeltaTime);
	ZOnAnimate(DeltaTime);
	Root->ZAnimate(DeltaTime);
}
bool ZBaseEngine::ZCheck(void)
{
	return !(CameraLook && CameraHud && Root);
}
void ZBaseEngine::ZCycle(float DeltaTime)
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		//Przygotowanie obiekt�w wykrywanie kolizji
		ZPrepare();
		//Oblicza nowe po�o�enie obiekt�w
		ZAnimate(DeltaTime);
		//Rysuje obiekty
		ZDraw();
		//Sprawdza Wej�cia <-> Klawiatura/Mysz
		ZCheckInput(DeltaTime);
	glFlush();
	Timer.ZAddFrames();
	SwapBuffers(Window.hDC);
}
LRESULT ZBaseEngine::ZEnterMessageLoop(void)
{
	MSG Msg;
	bool Quit=false;
	
	ZSetObject();
	ZLoad();
	if(Error)
	{
		Quit=true;
		PeekMessage(&Msg, NULL, 0, 0, PM_REMOVE);
	}
	while(!Quit)
    {
		ZUpdateObject();
		ZCycle(Timer.ZGetSeconds());
		/* check for messages */
		if(PeekMessage(&Msg, NULL, 0, 0, PM_REMOVE))
		{
			/* handle or dispatch messages */
			if(Msg.message == WM_QUIT)
			{
				Quit = TRUE;
			}
			TranslateMessage (&Msg);
			DispatchMessage (&Msg);
		}
	}
	ZDestrojObject();
	//ZSpac->ZDisablePixelBuffer(&ZPixBuf);	//do Z8
	ZDisableOpenGL();
	return Msg.wParam;
}
bool ZBaseEngine::ZCreateEngine(ZInitEngine &Zen)
{
	ZCreateObject();
	if(ZCheck())
	{
		ZErrorMessageBox("Camera or Root not set.");
		return 1;
	}
	if(ZEnableOpenGL(Zen.Title.c_str(),Zen.Width,Zen.Height,Zen.ColorBits,Zen.FullScreen))
		return 1;
	if(ZEnableExtension())
		return 1;
	if(Zen.SamplesFSAA)
	{
		if(ZEnableFSAA(Zen.Title.c_str(),Zen.Width,Zen.Height,Zen.ColorBits,Zen.SamplesFSAA))
			return 1;
	}
	if(!Zen.VSync)
		wglSwapIntervalEXT(0);
	Manager.Texture.ZSetAnisotropy(Zen.SamplesAnis);

	ShowWindow(Window.hWnd, SW_SHOW);
	UpdateWindow(Window.hWnd);
	SetForegroundWindow(Window.hWnd);

	return 0;
}
bool ZBaseEngine::ZEnableOpenGL(const char* Title,int Width, int Height,
						int ColorBits, bool FullScreenFlag)
{
	DWORD dwExStyle;
	DWORD dwStyle;
	RECT WindowRect;

	WindowRect.left=(long)0;
	WindowRect.right=(long)Width;
	WindowRect.top=(long)0;
	WindowRect.bottom=(long)Height;

	FullScreen=FullScreenFlag;
	
	//Get hInstance
	Window.hInstance=(HINSTANCE)GetModuleHandle(NULL);
	if(!Window.hInstance) 
	{
		ZErrorMessageBox("Window Creation Error.");
		ZDisableOpenGL();
		return 1;
	}
	//Get WndProc
	Window.WndProc=ZWndProc;

//****************************************************************************************************************
//HINSTANCE hInstance - jest to tzw. uchwyt realizacji ( ???? ). Czym z kolei jest uchwyt ? Uchwyt to po prostu 
//liczba, kt�rej u�ywa aplikacja do identyfikowania czego� czego mo�e "dotkn��". W naszym wypadku uchwyt 
//przekazywany do tej funkcji identyfikuje nasz program. Nie musimy jednak zawraca� sobie tym g�owy bo b�dziemy 
//z tego bardzo rzadko korzysta�.
//****************************************************************************************************************
//HINSTANCE hPrevInstance - jest to uchwyt ( ju� wiemy co to ) do poprzedniej realizacji programu. W Windows mo�emy 
//uruchomi� kilka kopii tego samego programu ( o czym mo�e nie wszyscy wiedza :), s� to w�a�nie tzw. realizacje. 
//W starym Windows ka�dy nowy program uruchamiany z pliku exe korzysta� z zasob�w programu, kt�ry by� za�adowany 
//jako pierwszy, z tego samego exec'a, natomiast w nowym, tym bardziej pokr�conym zrezygnowano z tego i ten 
//parametr jest zawsze ustawiany na NULL, wiec nie powinien nas obchodzi� w najmniejszym stopniu.
//****************************************************************************************************************
//LPSTR lpCmdLine - w ko�cu cos znajomego. Nic innego jak linia polece� programu. Tu umieszczany jest �a�cuch 
//znak�w, kt�ry nast�puje zaraz po nazwie naszego programu, np. "aqq.exe". Przewa�nie oczywi�cie nie wpisujemy 
//�adnych parametr�w programu ( zw�aszcza, �e szczeg�lnie w Windows jest to bardzo utrudnione ), ale my�l�, ze o 
//tym parametrze warto pami�ta�, bo mo�e si� kiedy� przyda�.
//****************************************************************************************************************
//int nCmdShow - parametr ten m�wi naszej aplikacji w jakiej postaci ma zosta� uruchomiony nasz program 
//( dok�adniej m�wi�c jego okno ), czy ma by� zminimalizowane na pasku zada�, czy wype�nia� pe�ny ekran czy 
//jeszcze jako� inaczej.
//****************************************************************************************************************
	Window.WndClass.style  = CS_HREDRAW | CS_VREDRAW | CS_OWNDC;
	Window.WndClass.lpfnWndProc = Window.WndProc;
    Window.WndClass.cbClsExtra = 0;
    Window.WndClass.cbWndExtra = 0;
    Window.WndClass.hInstance  = Window.hInstance;
   	Window.WndClass.hIcon  = LoadIcon(NULL,IDI_EXCLAMATION); 
    Window.WndClass.hCursor  = LoadCursor(NULL, IDC_ARROW);
    Window.WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
    Window.WndClass.lpszMenuName = NULL;
    Window.WndClass.lpszClassName = "ZBaseEngine_OpenGL";
//****************************************************************************************************************
//Skoro mamy ju� wype�nion� struktur� WNDCLASS, mo�emy przyst�pi� do bardzo wa�nej rzeczy, jaka jest rejestracja
//okna w systemie. Jak ju� pisa�em wy�ej robi to funkcja RegisterClass(), pobieraj�c jako parametr adres struktury
//WNDCLASS. W naszym przyk�adzie mamy cos takiego:
//****************************************************************************************************************
	if(!RegisterClass(&Window.WndClass)) 
	{
		ZErrorMessageBox("Failed To Register The Window Class.");
		ZDisableOpenGL();
		return 1;
	}
	if(FullScreen)
	{
		DEVMODE dmScreenSettings;								
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		
		dmScreenSettings.dmPelsWidth	= Width;				
		dmScreenSettings.dmPelsHeight	= Height;				
		dmScreenSettings.dmBitsPerPel	= ColorBits;			
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Spr�buj ustawi� pe�ny ekran. CDS_FULLSCREEN usuwa pasek start.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","Error...",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				FullScreen=0;
			}
			else
			{
				ZErrorMessageBox("Window Creation Error.");
				ZDisableOpenGL();
				return 1;
			}
		}
	}
	if (FullScreen)
	{
		dwExStyle=WS_EX_APPWINDOW;
		dwStyle=WS_POPUP;
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
		dwStyle=WS_OVERLAPPEDWINDOW;
	}
	AdjustWindowRectEx(&WindowRect, dwStyle, 0, dwExStyle);	
//****************************************************************************************************************
//Skoro mamy ju� klas� okna, mo�emy przyst�pi� do tak d�ugo oczekiwanego momentu czyli utworzenia okna. Robimy 
//to po prostu tak:
//****************************************************************************************************************
	Window.hWnd = CreateWindowEx(dwExStyle,"ZBaseEngine_OpenGL", Title, 
								dwStyle | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
								0, 0,
								WindowRect.right-WindowRect.left,
								WindowRect.bottom-WindowRect.top, 
								NULL, NULL,  
								Window.hInstance, NULL);
  	
	if(!Window.hWnd) 
	{
		ZErrorMessageBox("Window Creation Error.");
		ZDisableOpenGL();
		return 1;
	}
	PIXELFORMATDESCRIPTOR pfd;
    int PixelFormat;

	//* set the pixel format for the DC ///
    ZeroMemory (&pfd, sizeof (pfd));
    pfd.nSize = sizeof (pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = ColorBits;
    pfd.cDepthBits = 32;
    pfd.iLayerType = PFD_MAIN_PLANE;
   //* get the device context (DC) /
    Window.hDC = GetDC(Window.hWnd);

	PixelFormat = ChoosePixelFormat(Window.hDC, &pfd);
    SetPixelFormat(Window.hDC, PixelFormat, &pfd);
	if(!PixelFormat) 
	{
		ZErrorMessageBox("Window Creation Error.");
		ZDisableOpenGL();
		return 1;
	}
    //* create and enable the render context (RC) /
    Window.hRC = wglCreateContext(Window.hDC);
    wglMakeCurrent(Window.hDC, Window.hRC);
	return 0;
}

void ZBaseEngine::ZDisableOpenGL(void)
{
	if (FullScreen)
	{
		ChangeDisplaySettings(NULL,0);
	}
	wglMakeCurrent (Window.hDC, NULL);
    wglDeleteContext (Window.hRC);
    ReleaseDC(Window.hWnd, Window.hDC);
	DestroyWindow(Window.hWnd);
	UnregisterClass("ZBaseEngine_OpenGL",Window.hInstance);
}
bool ZBaseEngine::ZEnableFSAA(const char* Title,int Width,int Height,
						 int ColorBits,int Samples)
{
	DWORD dwExStyle;
	DWORD dwStyle;
	RECT WindowRect;

	WindowRect.left=(long)0;
	WindowRect.right=(long)Width;
	WindowRect.top=(long)0;
	WindowRect.bottom=(long)Height;

	if (FullScreen)
	{
		dwExStyle=WS_EX_APPWINDOW;
		dwStyle=WS_POPUP;
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;
		dwStyle=WS_OVERLAPPEDWINDOW;
	}

	Window.hWnd = CreateWindowEx(dwExStyle,"ZBaseEngine_OpenGL", Title,
							    dwStyle | WS_CLIPCHILDREN | WS_CLIPSIBLINGS,
							    0, 0, 
								WindowRect.right-WindowRect.left,
								WindowRect.bottom-WindowRect.top, 
							    NULL, NULL, 
							    Window.hInstance, NULL);
	if(!Window.hWnd) 
	{
		ZErrorMessageBox("Window Creation Error.");
		ZDisableOpenGL();
		return 1;
	}
//usuwanie istniejacych po��czen
	if (Window.hDC) wglMakeCurrent(Window.hDC, NULL);
	if (Window.hRC) wglDeleteContext(Window.hRC);
	ReleaseDC(Window.hWnd, Window.hDC);
//end
	int		PixelFormat;
	UINT	numFormats;
	float	fAttributes[] = {0,0};
	int iAttributes[] =
	{
		WGL_DRAW_TO_WINDOW_ARB,GL_TRUE,
		WGL_SUPPORT_OPENGL_ARB,GL_TRUE,
		WGL_ACCELERATION_ARB,WGL_FULL_ACCELERATION_ARB,
		WGL_COLOR_BITS_ARB,ColorBits,
		WGL_ALPHA_BITS_ARB,8,
		WGL_DEPTH_BITS_ARB,24,
		WGL_STENCIL_BITS_ARB,0,
		WGL_DOUBLE_BUFFER_ARB,GL_TRUE,
		WGL_SAMPLE_BUFFERS_ARB,GL_TRUE,
		WGL_SAMPLES_ARB,Samples,
		0,0
	};
	PIXELFORMATDESCRIPTOR pfd;

	ZeroMemory (&pfd, sizeof (pfd));
    pfd.nSize = sizeof (pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = ColorBits;
    pfd.cDepthBits = 32;
    pfd.iLayerType = PFD_MAIN_PLANE;

	Window.hDC = GetDC (Window.hWnd);
	wglChoosePixelFormatARB(Window.hDC,iAttributes,fAttributes,1,&PixelFormat,&numFormats);
	//gdy �le  ustawimy ilo�� pr�bek to ustawia max warto�� pr�bkownia.  
	while(!numFormats)
	{
		iAttributes[19]--;
		wglChoosePixelFormatARB(Window.hDC,iAttributes,fAttributes,1,&PixelFormat,&numFormats);
	}
	SetPixelFormat (Window.hDC, PixelFormat, &pfd);
    Window.hRC = wglCreateContext( Window.hDC );
    wglMakeCurrent( Window.hDC, Window.hRC );
	return 0;
}
bool  ZBaseEngine::ZEnableExtension()
{
//*************
		int a;
		//glGetIntegerv(GL_MAX_TEXTURE_UNITS,&a);		// stare max 4 
		//glGetIntegerv(GL_MAX_TEXTURE_COORDS,&a);		// 8 wsp�rz�dnych tekstur -> to jest wa�ne!!! 
		//glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS,&a);	// 32 tekstury w shaderze -> i to
		// tangent i binormal na texture 7 i 8 zrobic
		a;
//*************
	char* glextstring=(char *)glGetString(GL_EXTENSIONS);
//glext extension
	if (!strstr(glextstring,"GL_EXT_fog_coord"))	
	{
		ZErrorExtensionMessageBox("GL_EXT_fog_coord");
		return 1;
	}
	glFogCoordfEXT		 = (PFNGLFOGCOORDFEXTPROC) wglGetProcAddress("glFogCoordfEXT");
	glFogCoordfvEXT		 = (PFNGLFOGCOORDFVEXTPROC) wglGetProcAddress("glFogCoordfvEXT");
	glFogCoorddEXT		 = (PFNGLFOGCOORDDEXTPROC) wglGetProcAddress("glFogCoorddEXT");
	glFogCoorddvEXT		 = (PFNGLFOGCOORDDVEXTPROC) wglGetProcAddress("glFogCoorddvEXT");
	glFogCoordPointerEXT = (PFNGLFOGCOORDPOINTEREXTPROC) wglGetProcAddress("glFogCoordPointerEXT");

	if (!strstr(glextstring,"GL_ARB_multitexture"))
	{
		ZErrorExtensionMessageBox("GL_ARB_multitexture");
		return 1;
	}
	glActiveTextureARB =(PFNGLACTIVETEXTUREARBPROC) wglGetProcAddress("glActiveTextureARB");
	glClientActiveTextureARB = (PFNGLCLIENTACTIVETEXTUREARBPROC) wglGetProcAddress("glClientActiveTextureARB");
	glMultiTexCoord1dARB =(PFNGLMULTITEXCOORD1DARBPROC) wglGetProcAddress("glMultiTexCoord1dARB");
	glMultiTexCoord1dvARB = (PFNGLMULTITEXCOORD1DVARBPROC) wglGetProcAddress("glMultiTexCoord1dvARB");
	glMultiTexCoord1fARB = (PFNGLMULTITEXCOORD1FARBPROC) wglGetProcAddress("glMultiTexCoord1fARB");
	glMultiTexCoord1fvARB = (PFNGLMULTITEXCOORD1FVARBPROC) wglGetProcAddress("glMultiTexCoord1fvARB");
	glMultiTexCoord1iARB = (PFNGLMULTITEXCOORD1IARBPROC) wglGetProcAddress("glMultiTexCoord1iARB");
	glMultiTexCoord1ivARB = (PFNGLMULTITEXCOORD1IVARBPROC) wglGetProcAddress("glMultiTexCoord1ivARB");
	glMultiTexCoord1sARB = (PFNGLMULTITEXCOORD1SARBPROC) wglGetProcAddress("glMultiTexCoord1sARB");
	glMultiTexCoord1svARB = (PFNGLMULTITEXCOORD1SVARBPROC) wglGetProcAddress("glMultiTexCoord1svARB");
	glMultiTexCoord2dARB = (PFNGLMULTITEXCOORD2DARBPROC) wglGetProcAddress("glMultiTexCoord2dARB");
	glMultiTexCoord2dvARB = (PFNGLMULTITEXCOORD2DVARBPROC) wglGetProcAddress("glMultiTexCoord2dvARB");
	glMultiTexCoord2fARB = (PFNGLMULTITEXCOORD2FARBPROC) wglGetProcAddress("glMultiTexCoord2fARB");
	glMultiTexCoord2fvARB = (PFNGLMULTITEXCOORD2FVARBPROC) wglGetProcAddress("glMultiTexCoord2fvARB");
	glMultiTexCoord2iARB = (PFNGLMULTITEXCOORD2IARBPROC) wglGetProcAddress("glMultiTexCoord2iARB");
	glMultiTexCoord2ivARB = (PFNGLMULTITEXCOORD2IVARBPROC) wglGetProcAddress("glMultiTexCoord2ivARB");
	glMultiTexCoord2sARB = (PFNGLMULTITEXCOORD2SARBPROC) wglGetProcAddress("glMultiTexCoord2sARB");
	glMultiTexCoord2svARB = (PFNGLMULTITEXCOORD2SVARBPROC) wglGetProcAddress("glMultiTexCoord2svARB");
	glMultiTexCoord3dARB = (PFNGLMULTITEXCOORD3DARBPROC) wglGetProcAddress("glMultiTexCoord3dARB");
	glMultiTexCoord3dvARB = (PFNGLMULTITEXCOORD3DVARBPROC) wglGetProcAddress("glMultiTexCoord3dvARB");
	glMultiTexCoord3fARB = (PFNGLMULTITEXCOORD3FARBPROC) wglGetProcAddress("glMultiTexCoord3fARB");
	glMultiTexCoord3fvARB = (PFNGLMULTITEXCOORD3FVARBPROC) wglGetProcAddress("glMultiTexCoord3fvARB");
	glMultiTexCoord3iARB = (PFNGLMULTITEXCOORD3IARBPROC) wglGetProcAddress("glMultiTexCoord3iARB");
	glMultiTexCoord3ivARB = (PFNGLMULTITEXCOORD3IVARBPROC) wglGetProcAddress("glMultiTexCoord3ivARB");
	glMultiTexCoord3sARB = (PFNGLMULTITEXCOORD3SARBPROC) wglGetProcAddress("glMultiTexCoord3sARB");
	glMultiTexCoord3svARB = (PFNGLMULTITEXCOORD3SVARBPROC) wglGetProcAddress("glMultiTexCoord3svARB");
	glMultiTexCoord4dARB = (PFNGLMULTITEXCOORD4DARBPROC) wglGetProcAddress("glMultiTexCoord4dARB");
	glMultiTexCoord4dvARB = (PFNGLMULTITEXCOORD4DVARBPROC) wglGetProcAddress("glMultiTexCoord4dvARB");
	glMultiTexCoord4fARB = (PFNGLMULTITEXCOORD4FARBPROC) wglGetProcAddress("glMultiTexCoord4fARB");
	glMultiTexCoord4fvARB = (PFNGLMULTITEXCOORD4FVARBPROC) wglGetProcAddress("glMultiTexCoord4fvARB");
	glMultiTexCoord4iARB = (PFNGLMULTITEXCOORD4IARBPROC) wglGetProcAddress("glMultiTexCoord4iARB");
	glMultiTexCoord4ivARB = (PFNGLMULTITEXCOORD4IVARBPROC) wglGetProcAddress("glMultiTexCoord4ivARB");
	glMultiTexCoord4sARB = (PFNGLMULTITEXCOORD4SARBPROC) wglGetProcAddress("glMultiTexCoord4sARB");
	glMultiTexCoord4svARB = (PFNGLMULTITEXCOORD4SVARBPROC) wglGetProcAddress("glMultiTexCoord4svARB");
	
	if (!strstr(glextstring,"GL_EXT_texture_filter_anisotropic"))
	{
		ZErrorExtensionMessageBox("GL_EXT_texture_filter_anisotropic");
		return 1;
	}
	
	if (!strstr(glextstring,"GL_ARB_texture_env_combine"))
	{
		ZErrorExtensionMessageBox("GL_ARB_texture_env_combine");
		return 1;
	}
	
	if (!strstr(glextstring,"GL_ARB_texture_cube_map"))
	{
		ZErrorExtensionMessageBox("GL_ARB_texture_cube_map");
		return 1;
	}

	if (!strstr(glextstring,"GL_ARB_vertex_program"))
	{
		ZErrorExtensionMessageBox("GL_ARB_vertex_program");
		return 1;
	}
	glVertexAttrib1dARB = (PFNGLVERTEXATTRIB1DARBPROC) wglGetProcAddress("glVertexAttrib1dARB");
	glVertexAttrib1dvARB = (PFNGLVERTEXATTRIB1DVARBPROC) wglGetProcAddress("glVertexAttrib1dvARB");
	glVertexAttrib1fARB = (PFNGLVERTEXATTRIB1FARBPROC) wglGetProcAddress("glVertexAttrib1fARB");
	glVertexAttrib1fvARB = (PFNGLVERTEXATTRIB1FVARBPROC) wglGetProcAddress("glVertexAttrib1fvARB");
	glVertexAttrib1sARB = (PFNGLVERTEXATTRIB1SARBPROC) wglGetProcAddress("glVertexAttrib1sARB");
	glVertexAttrib1svARB = (PFNGLVERTEXATTRIB1SVARBPROC) wglGetProcAddress("glVertexAttrib1svARB");
	glVertexAttrib2dARB = (PFNGLVERTEXATTRIB2DARBPROC) wglGetProcAddress("glVertexAttrib2dARB");
	glVertexAttrib2dvARB = (PFNGLVERTEXATTRIB2DVARBPROC) wglGetProcAddress("glVertexAttrib2dvARB");
	glVertexAttrib2fARB = (PFNGLVERTEXATTRIB2FARBPROC) wglGetProcAddress("glVertexAttrib2fARB");
	glVertexAttrib2fvARB = (PFNGLVERTEXATTRIB2FVARBPROC) wglGetProcAddress("glVertexAttrib2fvARB");
	glVertexAttrib2sARB = (PFNGLVERTEXATTRIB2SARBPROC) wglGetProcAddress("glVertexAttrib2sARB");
	glVertexAttrib2svARB = (PFNGLVERTEXATTRIB2SVARBPROC) wglGetProcAddress("glVertexAttrib2svARB");
	glVertexAttrib3dARB = (PFNGLVERTEXATTRIB3DARBPROC) wglGetProcAddress("glVertexAttrib3dARB");
	glVertexAttrib3dvARB = (PFNGLVERTEXATTRIB3DVARBPROC) wglGetProcAddress("glVertexAttrib3dvARB");
	glVertexAttrib3fARB = (PFNGLVERTEXATTRIB3FARBPROC) wglGetProcAddress("glVertexAttrib3fARB");
	glVertexAttrib3fvARB = (PFNGLVERTEXATTRIB3FVARBPROC) wglGetProcAddress("glVertexAttrib3fvARB");
	glVertexAttrib3sARB = (PFNGLVERTEXATTRIB3SARBPROC) wglGetProcAddress("glVertexAttrib3sARB");
	glVertexAttrib3svARB = (PFNGLVERTEXATTRIB3SVARBPROC) wglGetProcAddress("glVertexAttrib3svARB");
	glVertexAttrib4NbvARB = (PFNGLVERTEXATTRIB4NBVARBPROC) wglGetProcAddress("glVertexAttrib4NbvARB");
	glVertexAttrib4NivARB = (PFNGLVERTEXATTRIB4NIVARBPROC) wglGetProcAddress("glVertexAttrib4NivARB");
	glVertexAttrib4NsvARB = (PFNGLVERTEXATTRIB4NSVARBPROC) wglGetProcAddress("glVertexAttrib4NsvARB");
	glVertexAttrib4NubARB = (PFNGLVERTEXATTRIB4NUBARBPROC) wglGetProcAddress("glVertexAttrib4NubARB");
	glVertexAttrib4NubvARB = (PFNGLVERTEXATTRIB4NUBVARBPROC) wglGetProcAddress("glVertexAttrib4NubvARB");
	glVertexAttrib4NuivARB = (PFNGLVERTEXATTRIB4NUIVARBPROC) wglGetProcAddress("glVertexAttrib4NuivARB");
	glVertexAttrib4NusvARB = (PFNGLVERTEXATTRIB4NUSVARBPROC) wglGetProcAddress("glVertexAttrib4NusvARB");
	glVertexAttrib4bvARB = (PFNGLVERTEXATTRIB4BVARBPROC) wglGetProcAddress("glVertexAttrib4bvARB");
	glVertexAttrib4dARB = (PFNGLVERTEXATTRIB4DARBPROC) wglGetProcAddress("glVertexAttrib4dARB");
	glVertexAttrib4dvARB = (PFNGLVERTEXATTRIB4DVARBPROC) wglGetProcAddress("glVertexAttrib4dvARB");
	glVertexAttrib4fARB = (PFNGLVERTEXATTRIB4FARBPROC) wglGetProcAddress("glVertexAttrib4fARB");
	glVertexAttrib4fvARB = (PFNGLVERTEXATTRIB4FVARBPROC) wglGetProcAddress("glVertexAttrib4fvARB");
	glVertexAttrib4ivARB = (PFNGLVERTEXATTRIB4IVARBPROC) wglGetProcAddress("glVertexAttrib4ivARB");
	glVertexAttrib4sARB = (PFNGLVERTEXATTRIB4SARBPROC) wglGetProcAddress("glVertexAttrib4sARB");
	glVertexAttrib4svARB = (PFNGLVERTEXATTRIB4SVARBPROC) wglGetProcAddress("glVertexAttrib4svARB");
	glVertexAttrib4ubvARB = (PFNGLVERTEXATTRIB4UBVARBPROC) wglGetProcAddress("glVertexAttrib4ubvARB");
	glVertexAttrib4uivARB = (PFNGLVERTEXATTRIB4UIVARBPROC) wglGetProcAddress("glVertexAttrib4uivARB");
	glVertexAttrib4usvARB = (PFNGLVERTEXATTRIB4USVARBPROC) wglGetProcAddress("glVertexAttrib4usvARB");
	glVertexAttribPointerARB = (PFNGLVERTEXATTRIBPOINTERARBPROC) wglGetProcAddress("glVertexAttribPointerARB");
	glEnableVertexAttribArrayARB = (PFNGLENABLEVERTEXATTRIBARRAYARBPROC) wglGetProcAddress("glEnableVertexAttribArrayARB");
	glDisableVertexAttribArrayARB = (PFNGLDISABLEVERTEXATTRIBARRAYARBPROC) wglGetProcAddress("glDisableVertexAttribArrayARB");
	glProgramStringARB = (PFNGLPROGRAMSTRINGARBPROC) wglGetProcAddress("glProgramStringARB");
	glBindProgramARB = (PFNGLBINDPROGRAMARBPROC) wglGetProcAddress("glBindProgramARB");
	glDeleteProgramsARB = (PFNGLDELETEPROGRAMSARBPROC) wglGetProcAddress("glDeleteProgramsARB");
	glGenProgramsARB = (PFNGLGENPROGRAMSARBPROC) wglGetProcAddress("glGenProgramsARB");
	glProgramEnvParameter4dARB = (PFNGLPROGRAMENVPARAMETER4DARBPROC) wglGetProcAddress("glProgramEnvParameter4dARB");
	glProgramEnvParameter4dvARB = (PFNGLPROGRAMENVPARAMETER4DVARBPROC) wglGetProcAddress("glProgramEnvParameter4dvARB");
	glProgramEnvParameter4fARB = (PFNGLPROGRAMENVPARAMETER4FARBPROC) wglGetProcAddress("glProgramEnvParameter4fARB");
	glProgramEnvParameter4fvARB = (PFNGLPROGRAMENVPARAMETER4FVARBPROC) wglGetProcAddress("glProgramEnvParameter4fvARB");
	glProgramLocalParameter4dARB = (PFNGLPROGRAMLOCALPARAMETER4DARBPROC) wglGetProcAddress("glProgramLocalParameter4dARB");
	glProgramLocalParameter4dvARB = (PFNGLPROGRAMLOCALPARAMETER4DVARBPROC) wglGetProcAddress("glProgramLocalParameter4dvARB");
	glProgramLocalParameter4fARB = (PFNGLPROGRAMLOCALPARAMETER4FARBPROC) wglGetProcAddress("glProgramLocalParameter4fARB");
	glProgramLocalParameter4fvARB = (PFNGLPROGRAMLOCALPARAMETER4FVARBPROC) wglGetProcAddress("glProgramLocalParameter4fvARB");
	glGetProgramEnvParameterdvARB = (PFNGLGETPROGRAMENVPARAMETERDVARBPROC) wglGetProcAddress("glGetProgramEnvParameterdvARB");
	glGetProgramEnvParameterfvARB = (PFNGLGETPROGRAMENVPARAMETERFVARBPROC) wglGetProcAddress("glGetProgramEnvParameterfvARB");
	glGetProgramLocalParameterdvARB = (PFNGLGETPROGRAMLOCALPARAMETERDVARBPROC) wglGetProcAddress("glGetProgramLocalParameterdvARB");
	glGetProgramLocalParameterfvARB = (PFNGLGETPROGRAMLOCALPARAMETERFVARBPROC) wglGetProcAddress("glGetProgramLocalParameterfvARB");
	glGetProgramivARB = (PFNGLGETPROGRAMIVARBPROC) wglGetProcAddress("glGetProgramivARB");
	glGetProgramStringARB = (PFNGLGETPROGRAMSTRINGARBPROC) wglGetProcAddress("glGetProgramStringARB");
	glGetVertexAttribdvARB = (PFNGLGETVERTEXATTRIBDVARBPROC) wglGetProcAddress("glGetVertexAttribdvARB");
	glGetVertexAttribfvARB = (PFNGLGETVERTEXATTRIBFVARBPROC) wglGetProcAddress("glGetVertexAttribfvARB");
	glGetVertexAttribivARB = (PFNGLGETVERTEXATTRIBIVARBPROC) wglGetProcAddress("glGetVertexAttribivARB");
	glGetVertexAttribPointervARB = (PFNGLGETVERTEXATTRIBPOINTERVARBPROC) wglGetProcAddress("glGetVertexAttribPointervARB");
	glIsProgramARB = (PFNGLISPROGRAMARBPROC) wglGetProcAddress("glIsProgramARB");

	if (!strstr(glextstring,"GL_EXT_draw_range_elements"))
	{
		ZErrorExtensionMessageBox("GL_EXT_draw_range_elements");
		return 1;
	}
	glDrawRangeElementsEXT = (PFNGLDRAWRANGEELEMENTSEXTPROC) wglGetProcAddress("glDrawRangeElementsEXT");

	if (!strstr(glextstring,"GL_EXT_compiled_vertex_array"))
	{
		ZErrorExtensionMessageBox("GL_EXT_compiled_vertex_array");
		return 1;
	}
	glLockArraysEXT = (PFNGLLOCKARRAYSEXTPROC) wglGetProcAddress("glLockArraysEXT");
	glUnlockArraysEXT = (PFNGLUNLOCKARRAYSEXTPROC) wglGetProcAddress("glUnlockArraysEXT");

//	if (!strstr(glextstring,"WGL_EXT_extensions_string")) return "WGL_EXT_extensions_string";
	wglGetExtensionsStringEXT = (PFNWGLGETEXTENSIONSSTRINGEXTPROC)wglGetProcAddress("wglGetExtensionsStringEXT");
	wglGetExtensionsStringARB = (PFNWGLGETEXTENSIONSSTRINGARBPROC)wglGetProcAddress("wglGetExtensionsStringARB");

	char* wglextstring = (char*)wglGetExtensionsStringARB(Window.hDC);
//wglext extension
	if (!strstr(wglextstring,"WGL_ARB_multisample"))
	{
		ZErrorExtensionMessageBox("WGL_ARB_multisample");
		return 1;
	}

	if (!strstr(wglextstring,"WGL_ARB_render_texture"))
	{
		ZErrorExtensionMessageBox("WGL_ARB_render_texture");
		return 1;
	}
	wglReleaseTexImageARB   = (PFNWGLRELEASETEXIMAGEARBPROC)wglGetProcAddress("wglReleaseTexImageARB");
	wglBindTexImageARB      = (PFNWGLBINDTEXIMAGEARBPROC)wglGetProcAddress("wglBindTexImageARB"); 
	wglSetPbufferAttribARB  = (PFNWGLSETPBUFFERATTRIBARBPROC)wglGetProcAddress("wglSetPbufferAttribARB");

	if (!strstr(wglextstring,"WGL_ARB_pbuffer"))
	{
		ZErrorExtensionMessageBox("WGL_ARB_pbuffer");
		return 1;
	}
	wglCreatePbufferARB     = (PFNWGLCREATEPBUFFERARBPROC)wglGetProcAddress("wglCreatePbufferARB");
	wglGetPbufferDCARB      = (PFNWGLGETPBUFFERDCARBPROC)wglGetProcAddress("wglGetPbufferDCARB");
	wglReleasePbufferDCARB  = (PFNWGLRELEASEPBUFFERDCARBPROC)wglGetProcAddress("wglReleasePbufferDCARB");
	wglDestroyPbufferARB    = (PFNWGLDESTROYPBUFFERARBPROC)wglGetProcAddress("wglDestroyPbufferARB");
	wglQueryPbufferARB      = (PFNWGLQUERYPBUFFERARBPROC)wglGetProcAddress("wglQueryPbufferARB");

	if (!strstr(wglextstring,"WGL_ARB_pixel_format"))
	{
		ZErrorExtensionMessageBox("WGL_ARB_pixel_format");
		return 1;
	}
	wglGetPixelFormatAttribivARB = (PFNWGLGETPIXELFORMATATTRIBIVARBPROC)wglGetProcAddress("wglGetPixelFormatAttribivARB");
	wglGetPixelFormatAttribfvARB = (PFNWGLGETPIXELFORMATATTRIBFVARBPROC)wglGetProcAddress("wglGetPixelFormatAttribfvARB");
	wglChoosePixelFormatARB      = (PFNWGLCHOOSEPIXELFORMATARBPROC)wglGetProcAddress("wglChoosePixelFormatARB");
 
	if (!strstr(wglextstring,"WGL_EXT_swap_control"))
	{
		ZErrorExtensionMessageBox("WGL_EXT_swap_control");
		return 1;
	}
	wglSwapIntervalEXT = (PFNWGLSWAPINTERVALEXTPROC)wglGetProcAddress("wglSwapIntervalEXT");
	wglGetSwapIntervalEXT = (PFNWGLGETSWAPINTERVALEXTPROC)wglGetProcAddress("wglGetSwapIntervalEXT");
	return 0;
}
void ZBaseEngine::ZEnablePixelBuffer(ZPixelBuffer *ZPixBuf)
{
	int   format;
	int   pformat[256];
	unsigned int   nformats;
	int   iattribs[512];
	float fattribs[512];
	int   niattribs =0;
	int   nfattribs =0;

	ZPixBuf->Buffer=0;
	ZPixBuf->hDC=0;
	ZPixBuf->hRC=0;
	memset(iattribs, 0, sizeof(int)*512);
	memset(fattribs, 0, sizeof(float)*512);

	iattribs[niattribs++] = WGL_DRAW_TO_PBUFFER_ARB;
	iattribs[niattribs++] = GL_TRUE;
	iattribs[niattribs++] = WGL_BIND_TO_TEXTURE_RGBA_ARB;
	iattribs[niattribs++] = GL_TRUE;

	HDC hdc = wglGetCurrentDC();

	wglChoosePixelFormatARB(hdc, iattribs, fattribs, 256, pformat, &nformats);
	format = pformat[0];

	memset(iattribs, 0, sizeof(int)*512);
	niattribs=0;
	iattribs[niattribs++] = WGL_TEXTURE_FORMAT_ARB;
	iattribs[niattribs++] = WGL_TEXTURE_RGBA_ARB;
	iattribs[niattribs++] = WGL_TEXTURE_TARGET_ARB;
	iattribs[niattribs++] = WGL_TEXTURE_CUBE_MAP_ARB;
	iattribs[niattribs++] = WGL_MIPMAP_TEXTURE_ARB;
	iattribs[niattribs++] = GL_FALSE;
	iattribs[niattribs++] = WGL_PBUFFER_LARGEST_ARB;
	iattribs[niattribs++] = GL_FALSE;
	
	if(!ZPixBuf->Width) ZPixBuf->Width=256;
	if(!ZPixBuf->Height) ZPixBuf->Height=256;
	
	ZPixBuf->Buffer = wglCreatePbufferARB(hdc, format, ZPixBuf->Width, ZPixBuf->Height, iattribs);
	ZPixBuf->hDC     = wglGetPbufferDCARB(ZPixBuf->Buffer);
	ZPixBuf->hRC     = wglCreateContext(ZPixBuf->hDC);

	wglQueryPbufferARB(ZPixBuf->Buffer, WGL_PBUFFER_WIDTH_ARB, &ZPixBuf->Width);
	wglQueryPbufferARB(ZPixBuf->Buffer, WGL_PBUFFER_HEIGHT_ARB, &ZPixBuf->Height);
}
void ZBaseEngine::ZDisablePixelBuffer(ZPixelBuffer *ZPixBuf)
{
	if (ZPixBuf->Buffer)
	{
		wglMakeCurrent(ZPixBuf->hDC, 0);
		wglDeleteContext(ZPixBuf->hRC);
		wglReleasePbufferDCARB(ZPixBuf->Buffer, ZPixBuf->hDC);
		wglDestroyPbufferARB(ZPixBuf->Buffer);
	}
}
int ZBaseEngine::ZGetFPS(void)
{
	return (int)Timer.ZGetFPS();
}
void ZBaseEngine::ZErrorExtensionMessageBox(const char * FileName)
{
	if(FileName)
	{
		string ErrorInfo;
		ErrorInfo = "Your graphics card doesn't support : \n\n";
		ErrorInfo+=FileName;
		ErrorInfo+="\n\n ZBaseEngine will now exit.";
		MessageBox(NULL,ErrorInfo.c_str(),"Init Extension Error", MB_OK | MB_ICONSTOP );
		PostQuitMessage(0);
		Error=true; 
	}
}
void ZBaseEngine::ZMessageBox(string Message)
{
	if(!Message.length())
	{
		MessageBox(NULL,Message.c_str(),"ZEngine Message.", MB_OK | MB_ICONSTOP );
	}
}
void ZBaseEngine::ZMessageBox(const char *Message)
{
	if(Message)
	{
		MessageBox(NULL,Message,"ZEngine Message.", MB_OK | MB_ICONSTOP );
	}
}
void ZBaseEngine::ZErrorMessageBox(string Message)
{
	if(!Message.length())
	{
		MessageBox(NULL,Message.c_str(),"ZEngine Error Message.", MB_OK | MB_ICONSTOP );
		PostQuitMessage(0);
		Error=true; 
	}
}
void ZBaseEngine::ZErrorMessageBox(const char *Message)
{
	if(Message)
	{
		MessageBox(NULL,Message,"ZEngine Error Message.", MB_OK | MB_ICONSTOP );
		PostQuitMessage(0);
		Error=true; 
	}
}
void ZBaseEngine::ZErrorLoadMessageBox(const char *FileName)
{
	if(FileName)
	{
		string ErrorInfo;
		ErrorInfo="File: ";
		ErrorInfo+= FileName;
		ErrorInfo+=" is bad or not exist."; 
		MessageBox(NULL, ErrorInfo.c_str(), "Load File Error!", MB_OK);
		PostQuitMessage(0);
		Error=true; 
	}
}
void ZBaseEngine::ZErrorLoadMessageBox(string FileName)
{
	if(!FileName.length())
	{
		string ErrorInfo;
		ErrorInfo="File: ";
		ErrorInfo+= FileName;
		ErrorInfo+=" is bad or not exist."; 
		MessageBox(NULL, ErrorInfo.c_str(), "Load File Error!", MB_OK);
		PostQuitMessage(0);
		Error=true; 
	}
}
void ZBaseEngine::ZSetKeys(int Key,bool T)
{
	Keys[Key]=T;
}
bool ZBaseEngine::ZGetKeys(int Key)
{
	return Keys[Key];
}
void ZBaseEngine::ZShowCursor(bool T)
{
	ShowCursor(T);
}
void ZBaseEngine::ZSetWindowField(long WinWidth,long WinHeight)
{
	Width=WinWidth;
	Height=WinHeight;
	if (Width > Height)
		Aspect=Width;
	else
		Aspect=Height;
}
char* ZBaseEngine::ZPrintScreenBMP(char* FileName)
{
	//begin generewonie nazwy pliku.
	bool Find=1;
	unsigned int i=0;
	char Out[129];
	char Number[65];
	ifstream IsCreate;
	while(Find)
	{
		strcpy_s(Out,sizeof(Out),FileName);	
	    _itoa_s( i, Number, sizeof(Number), 10);

		strcpy_s(Out+strlen(Out),sizeof(Out)-strlen(Out),Number);
		
		strcpy_s(Out+strlen(Out),sizeof(Out)-strlen(Out),".bmp");
		cout<<Out<<"  "<<strlen(Out)<<endl;

		//Find=0;	
		IsCreate.open(Out,ios::_Nocreate);
		if(!IsCreate) 
		{
			Find=0;	
			//cout<<"Podany plik istnieje."<<endl;
		}
		//else cout<<"istnieje"<<endl;
		IsCreate.close();
		i++;
	}
	//end generewonie nazwy pliku.

	ZTexture2D Image;
	Image.Type=GL_UNSIGNED_BYTE;
	Image.Format=GL_RGB;
	Image.SizeWidth=Width;
	Image.SizeHeight=Height;
	Image.Components=GL_RGB;

	Image.SizeImage=Image.SizeWidth*Image.SizeHeight*3;	//abs(Height) - nie potrzebne ?
	Image.ZCreateImageDate(Image.SizeImage);
	glReadPixels(0,0,Image.SizeWidth-1,Image.SizeHeight-1,Image.Format,Image.Type,Image.ImageDate);
	//glReadPixels(0,0,100-1,100-1,GL_RGB,GL_UNSIGNED_BYTE,Image.ImageDate);
	if(Manager.Texture.ZSaveFileBMP(Image,Out))
	{
		return "PrintScreen is not create.";
	}
	return 0;
}
char* ZBaseEngine::ZPrintScreenTGA(char* FileName)
{
	//begin generewonie nazwy pliku.
	bool Find=1;
	unsigned int i=0;
	char Out[129];
	char Number[65];
	ifstream IsCreate;
	while(Find)
	{
		strcpy_s(Out,sizeof(Out),FileName);	
	    _itoa_s(i, Number, sizeof(Number), 10);

		strcpy_s(Out+strlen(Out),sizeof(Out)-strlen(Out),Number);
		
		strcpy_s(Out+strlen(Out),sizeof(Out)-strlen(Out),".tga");
		cout<<Out<<"  "<<strlen(Out)<<endl;

		//Find=0;	
		IsCreate.open(Out,ios::_Nocreate);
		if(!IsCreate) 
		{
			Find=0;	
			//cout<<"Podany plik istnieje."<<endl;
		}
		//else cout<<"istnieje"<<endl;
		IsCreate.close();
		i++;
	}
	//end generewonie nazwy pliku.

	ZTexture2D Image;
	Image.Type=GL_UNSIGNED_BYTE;
	Image.Format=GL_RGB;
	Image.Components=GL_RGB;

	Image.SizeWidth=Width;
	Image.SizeHeight=Height;

	Image.SizeImage=Image.SizeWidth*Image.SizeHeight*3;
	
	Image.ZCreateImageDate(Image.SizeImage);
	glReadPixels(0,0,Image.SizeWidth-1,Image.SizeHeight-1,Image.Format,GL_UNSIGNED_BYTE,Image.ImageDate);
	if(Manager.Texture.ZSaveFileTGA(Image,Out))
	{
		return "PrintScreen is not create.";
	}
	return 0;
}