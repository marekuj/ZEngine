#include "ZDate.h"

#include "Object/ZObject.h"
#include <iostream>
#include <fstream>
using namespace std;

ZDate::ZDate()
{
	Index=0;
	Vertex=0;
	Normal=0;
	TextureCoord=0;
	FogCoord=0;
	
	PointIndex=0;
	PointVertex=0;
	PointNormal=0;
	PointTextureCoord=0;
	PointFogCoord=0;
}
ZDate::~ZDate()
{
	if(PointIndex) delete [] PointIndex;
	if(PointVertex) delete[] PointVertex;
	if(PointNormal) delete[] PointNormal;
	if(PointTextureCoord) delete[] PointTextureCoord;
	if(PointFogCoord) delete[] PointFogCoord;
}
void ZDate::ZCreatePointIndex(unsigned int Size)
{
	if(PointIndex) delete [] PointIndex;
	PointIndex=new unsigned int[Size];
	Index=Size;
}
void ZDate::ZCreatePointVertex(unsigned int Size)
{
	if(PointVertex) delete[] PointVertex;
	PointVertex=new Vector3D[Size];
	Vertex=Size;
}
void ZDate::ZCreatePointNormal(unsigned int Size)
{
	if(PointNormal) delete[] PointNormal;
	PointNormal=new Vector3D[Size];
	Normal=Size;
}
void ZDate::ZCreatePointTextureCoord(unsigned int Size)
{
	if(PointTextureCoord) delete[] PointTextureCoord;
	PointTextureCoord=new Vector2D[Size];
	TextureCoord=Size;
}
void ZDate::ZCreatePointFogCoord(unsigned int Size)
{
	if(PointFogCoord) delete[] PointFogCoord;
	PointFogCoord=new float[Size];
	FogCoord=Size;
}
void ZDate::ZSetScale(Vector3D &Scale)
{
	for(unsigned int i=0; i<Vertex; i++)
	{
		PointVertex[i].Set( Scale.GetX()*PointVertex[i].GetX(),
						    Scale.GetY()*PointVertex[i].GetY(),
						    Scale.GetZ()*PointVertex[i].GetZ() );
	}
		
}
void ZDate::ZSetScale(float X, float Y, float Z)
{
	for(unsigned int i=0; i<Vertex; i++)
	{
		PointVertex[i].Set( X*PointVertex[i].GetX(),
						    Y*PointVertex[i].GetY(),
						    Z*PointVertex[i].GetZ() );
	}
}
void ZDate::ZDraw(int Part)
{
	glVertexPointer(3, GL_FLOAT, 0, PointVertex);
	if(Normal)
	{
		glNormalPointer(GL_FLOAT,0,PointNormal);
	}
	if(TextureCoord)
	{
		glTexCoordPointer(2, GL_FLOAT, 0, PointTextureCoord);
	}
	if(FogCoord)
	{	
		glFogCoordPointerEXT(GL_FLOAT,0,PointFogCoord);
	}
//	glLockArraysEXT(0,Index);
	glDrawRangeElementsEXT(GL_TRIANGLES,0,Index-1,Index,GL_UNSIGNED_INT,PointIndex);
//	glUnlockArraysEXT();
//	glDrawRangeElementsEXT(GL_TRIANGLES,3,Index-1,Index-3,GL_UNSIGNED_INT,PointIndex+3);
//	glDrawArrays(GL_TRIANGLES, 0, Vertex);
}
char* ZDate::ZSaveHDD(char * FileName)
{
    ofstream File(FileName,ios::binary);
	//begin***************Czy uda�o si� stworzy� pilik z danymi********************
	if(!File) 
	{
		File.close();
		return FileName; 
	}
	//end*****************Czy uda�o si� stworzy� pilik z danymi********************
	//begin***************Sprawdzanie poprawnosci danych***************************
	float Check_Sum=0;
	int Check_Div=0;
	if(Vertex && PointVertex)
	{
		Check_Sum+=Vertex;
		Check_Div++;
	}
	else return "Error: Matrix Vertex is not exist!";
	if(Normal) 
	{	
		if(!PointNormal) "Error: Matrix Normal is not exist!";
		Check_Sum+=Normal;	
		Check_Div++;
	}
	if(TextureCoord) 
	{	
		if(!PointTextureCoord) "Error: Matrix TextureCoord is not exist!";
		Check_Sum+=TextureCoord;	
		Check_Div++;
	}
	if(FogCoord) 
	{	
		if(!PointFogCoord) "Error: Matrix FogCoord is not exist!";
		Check_Sum+=FogCoord;	
		Check_Div++;
	}
	if(	Vertex!=Check_Sum/Check_Div) return "Error: Bad matrix size!";
	//end*****************Sprawdzanie poprawnosci danych **************************
	//begin***************Tworzenie bufor�w zpisu**********************************
	unsigned int BufUnsignedInt=0;
	char *PointBufUnsignedInt= (char*)&BufUnsignedInt;
	int BufInt=0;
	char *PointBufInt=(char*)&BufInt;
	float BufFloat=0;
	char *PointBufFloat=(char*)&BufFloat;
	Vector2D BufVector2D;
	char *PointBufVector2D=(char*)&BufVector2D;
	Vector3D BufVector3D;
	char *PointBufVector3D=(char*)&BufVector3D;
	//end*****************Tworzenie bufor�w zpisu**********************************
	//begin***************Zapis do pliku*******************************************
	File.write(Type,sizeof(Type));
	File.write(Version,sizeof(Version));
	File.write(Description,sizeof(Description));
	
	if(strcmp(Version,"1.0")==0)
	{	
		BufUnsignedInt=Index;
		File.write(PointBufUnsignedInt,sizeof(BufUnsignedInt));
		BufInt=Vertex;
		File.write(PointBufInt,sizeof(BufInt));
		BufInt=Normal;
		File.write(PointBufInt,sizeof(BufInt));
		BufInt=TextureCoord;
		File.write(PointBufInt,sizeof(BufInt));
		BufInt=FogCoord;
		File.write(PointBufInt,sizeof(BufInt));
		for(unsigned int i=0; i<Index; i++)
		{
			BufUnsignedInt=PointIndex[i];
			File.write(PointBufUnsignedInt,sizeof(unsigned int));
		}
		for(unsigned int i=0; i<Vertex; i++)
		{
			if(Vertex)
			{
				BufVector3D=PointVertex[i];
				File.write(PointBufVector3D,sizeof(BufVector3D));			
			}
			if(Normal)
			{
				BufVector3D=PointNormal[i];
				File.write(PointBufVector3D,sizeof(BufVector3D));		
			}
			if(TextureCoord)
			{
				BufVector2D=PointTextureCoord[i];
				File.write(PointBufVector2D,sizeof(BufVector2D));			
			}
			if(FogCoord)
			{
				BufFloat=PointFogCoord[i];
				File.write(PointBufFloat,sizeof(BufFloat));
			}
		}
	//end*****************Zapis do pliku*******************************************
	    File.close();
		return 0;
	}
	if(strcmp(Version,"1.0a")==0)
	{
		//Wykonaj to...
	//end*****************Zapis do pliku*******************************************
	    File.close();
		return 0;
	}
	//end*****************Zapis do pliku*******************************************
    File.close();
	return "Error: Bad zdt file version!";
}
char* ZDate::ZLoadHDD(char * FileName)
{
    ifstream File(FileName,ios::binary);
	//begin***************Czy istnieje pilik z danymi******************************
	if(!File) 
	{
		File.close();
		return FileName; 
	}
	//end*****************Czy istnieje pilik z danymi******************************
	//begin***************Tworzenie bufor�w odczytu********************************
	unsigned int BufUnsignedInt=0;
	char *PointBufUnsignedInt= (char*)&BufUnsignedInt;
	int BufInt=0;
	char *PointBufInt=(char*)&BufInt;
	float BufFloat=0;
	char *PointBufFloat=(char*)&BufFloat;
	Vector2D BufVector2D;
	char *PointBufVector2D=(char*)&BufVector2D;
	Vector3D BufVector3D;
	char *PointBufVector3D=(char*)&BufVector3D;
	//end*****************Tworzenie bufor�w odczutu********************************
	//begin***************Odczyt z pliku*******************************************
	File.read(Type,sizeof(Type));
	File.read(Version,sizeof(Version));
	File.read(Description,sizeof(Description));
	if(strcmp(Type,"ZDate/zdt"))
	{
		File.close();
		return "Error: Bad file!";
	}
	if(!strcmp(Version,"1.0"))
	{
		File.read(PointBufUnsignedInt,sizeof(BufUnsignedInt));
		Index=BufUnsignedInt;
		File.read(PointBufInt,sizeof(BufInt));
		Vertex=BufInt;
		File.read(PointBufInt,sizeof(BufInt));
		Normal=BufInt;
		File.read(PointBufInt,sizeof(BufInt));
		TextureCoord=BufInt;
		File.read(PointBufInt,sizeof(BufInt));
		FogCoord=BufInt;
	//begin***************Sprawdzanie poprawnosci danych begin*********************
		float Check_Sum=0;
		int Check_Div=0;
		if(Index)
		{
			ZCreatePointIndex(Index);
		}
		else return "Error: Matrix Index is not exist!";
		if(Vertex)
		{
			ZCreatePointVertex(Vertex);
			Check_Sum+=Vertex;
			Check_Div++;
		}
		else return "Error: Matrix Vertex is not exist!";
		if(Normal) 
		{	
			ZCreatePointNormal(Normal);
			Check_Sum+=Normal;	
			Check_Div++;
		}
		if(TextureCoord) 
		{	
			ZCreatePointTextureCoord(TextureCoord);
			Check_Sum+=TextureCoord;	
			Check_Div++;
		}
		if(FogCoord) 
		{	
			ZCreatePointFogCoord(FogCoord);
			Check_Sum+=FogCoord;	
			Check_Div++;
		}
		if(	Vertex!=Check_Sum/Check_Div) return "Error: Bad matrix size!";
		//end*****************Sprawdzanie poprawnosci danych begin*********************
		for(unsigned int i=0; i<Index; i++)
		{
			File.read(PointBufUnsignedInt,sizeof(BufUnsignedInt));
			PointIndex[i]=BufUnsignedInt;
		}
		for(unsigned int i=0; i<Vertex; i++)
		{
			if(Vertex)
			{
				File.read(PointBufVector3D,sizeof(BufVector3D));
				PointVertex[i]=BufVector3D;
			}
			if(Normal)
			{
				File.read(PointBufVector3D,sizeof(BufVector3D));
				PointNormal[i]=BufVector3D;			
			}
			if(TextureCoord)
			{
				File.read(PointBufVector2D,sizeof(BufVector2D));
				PointTextureCoord[i]=BufVector2D;
			}
			if(FogCoord)
			{
				File.read(PointBufFloat,sizeof(BufFloat));
				PointFogCoord[i]=BufFloat;
			}
		}
	//end*****************Odczyt z pliku*******************************************
		File.close();
		return 0;
	}
	if(strcmp(Version,"1.1a")==0)
	{
		//Wykonaj to...
	//end*****************Odczyt z pliku*******************************************
		File.close();
		return 0;
	}
	//end*****************Odczyt z pliku*******************************************
	File.close();
	return "Error: Bad zdt file version!";
}
void ZDate::Print()
{
	cout<<"Typ:\t"<<Type<<endl
		<<"Wersia:\t"<<Version<<endl
		<<"Opis:\t"<<Description<<endl;

	cout<<endl<<"Index: ";
	for(unsigned int i=0; i<Index; i++)
	{
		cout<<PointIndex[i]<<" ";
	}
	cout<<endl<<endl;
	for(unsigned int i=0; i<Vertex; i++)
	{		
		cout<<"Point "<<i<<':'<<endl
			<<"Vertex:  "
			<<PointVertex[i].GetX()<<' '
			<<PointVertex[i].GetY()<<' '
			<<PointVertex[i].GetZ()<<endl;
		if(Normal)
		cout<<"Normal:  "
			<<PointNormal[i].GetX()<<' '
			<<PointNormal[i].GetY()<<' '
			<<PointNormal[i].GetZ()<<endl;
		if(TextureCoord)
		cout<<"Texture: "
			<<PointTextureCoord[i].GetX()<<' '
			<<PointTextureCoord[i].GetY()<<endl;
		if(FogCoord) 
		cout<<"Fog:     "
			<<PointFogCoord[i]<<endl;
		cout<<endl;
	}
}
