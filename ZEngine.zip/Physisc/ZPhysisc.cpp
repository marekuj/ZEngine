#include "ZPhysisc.h"

#include <fstream>
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::ios;

ZPhysisc::ZPhysisc(void)
{
}
ZPhysisc::ZPhysisc(const ZPhysisc &Zen)
{
	Cell=Zen.Cell;
	BackPosition=Zen.BackPosition;
}
ZPhysisc::~ZPhysisc(void)
{
	Cell.clear();
}
bool ZPhysisc::ZLoadFileTXT(ZPhysiscCell &Physisc,const char *FileName)
{
	ifstream FilePtr;
    char ReadBufor[200];

	FilePtr.open(FileName);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	//Read Heading
    FilePtr.getline(ReadBufor,200,'\n');
	if(strcmp(ReadBufor,"ZEngine Physisc."))
	{
		FilePtr.close();
		return 1;
	}
	//Read Empty Line
    FilePtr.getline(ReadBufor,200,'\n');
	//Read Physisc Parameter
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToFloat(ReadBufor,'[',']',Physisc.Radius))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToFloat(ReadBufor,'[',']',Physisc.Mass))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToFloat(ReadBufor,'[',']',Physisc.Friction))
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToVector3D(ReadBufor,'[',']',Physisc.Gravitation))
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToVector3D(ReadBufor,'[',']',Physisc.Position))
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToVector3D(ReadBufor,'[',']',Physisc.Velocity))
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToVector3D(ReadBufor,'[',']',Physisc.Acceleration))
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.close();
	return 0;
}
bool ZPhysisc::ZLoadFilePHY(ZPhysiscCell &Physisc,const char *FileName)
{
   ifstream FilePtr;

	char Type[10];
	char Version[10];
	char Description[100];

	FilePtr.open(FileName,ios::binary);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.read(Type,sizeof(Type));
	FilePtr.read(Version,sizeof(Version));
	FilePtr.read(Description,sizeof(Description));

	if(strcmp(Type,"phy"))
	{
		FilePtr.close();
		return 1;
	}
	if(!strcmp(Version,"1.0"))
	{
		FilePtr.read((char*)&Physisc,sizeof(ZPhysiscCell));	
		FilePtr.close();
		return 0;
	}
	FilePtr.close();
	return 1;
}
bool ZPhysisc::ZSaveFileTXT(ZPhysiscCell &Physisc,const char *FileName)
{
	ofstream FilePtr;

	FilePtr.open(FileName);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	FilePtr<<"ZEngine Physisc."<<endl<<endl;
	FilePtr<<"Radius       = ["<<Physisc.Radius<<']'<<endl;
	FilePtr<<"Mass         = ["<<Physisc.Mass<<']'<<endl;
	FilePtr<<"Friction     = ["<<Physisc.Friction<<']'<<endl;
	FilePtr<<"Gravitation  = ["<<Physisc.Gravitation.GetX()<<','<<Physisc.Gravitation.GetY()<<','<<Physisc.Gravitation.GetZ()<<']'<<endl;
	FilePtr<<"Position     = ["<<Physisc.Position.GetX()<<','<<Physisc.Position.GetY()<<','<<Physisc.Position.GetZ()<<']'<<endl;
	FilePtr<<"Velocity     = ["<<Physisc.Velocity.GetX()<<','<<Physisc.Velocity.GetY()<<','<<Physisc.Velocity.GetZ()<<']'<<endl;
	FilePtr<<"Acceleration = ["<<Physisc.Acceleration.GetX()<<','<<Physisc.Acceleration.GetY()<<','<<Physisc.Acceleration.GetZ()<<']'<<endl;
	
	FilePtr.close();
	return 0;
}
bool ZPhysisc::ZSaveFilePHY(ZPhysiscCell &Physisc,const char *FileName)
{
   ofstream FilePtr;

	char Type[10]="phy";
	char Version[10]="1.0";
	char Description[100]="ZEngine Physisc.";

	FilePtr.open(FileName,ios::binary);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.write(Type,sizeof(Type));
	FilePtr.write(Version,sizeof(Version));
	FilePtr.write(Description,sizeof(Description));

	FilePtr.write((char*)&Physisc,sizeof(ZPhysiscCell));	

	FilePtr.close();
	return 0;
}
const char* ZPhysisc::ZLoadPhysisc(const char *FileName)
{
	ZPhysiscCell Stuff;	
	char FileBuf[5];
	size_t FileLenght=strlen(FileName);
	FileBuf[0]=FileName[FileLenght-4];
	FileBuf[1]=FileName[FileLenght-3];
	FileBuf[2]=FileName[FileLenght-2];
	FileBuf[3]=FileName[FileLenght-1];
	FileBuf[4]='\0';
	
	if(!strcmp(FileBuf,".txt"))
	{
		if(ZLoadFileTXT(Stuff,FileName))
		{
			#ifdef Z_PHYSISC_LOG
			ZPrintLog(Z_FILE_NAME_LOG,Z_PHYSISC_LOG_ERROR,FileName);
			#endif
			return FileName;
		}
	}
	else if(!strcmp(FileBuf,".phy"))
	{
		if(ZLoadFilePHY(Stuff,FileName))
		{
			#ifdef Z_PHYSISC_LOG
			ZPrintLog(Z_FILE_NAME_LOG,Z_PHYSISC_LOG_ERROR,FileName);
			#endif
			return FileName;
		}
	}
	else
	{
		#ifdef Z_PHYSISC_LOG
		ZPrintLog(Z_FILE_NAME_LOG,Z_PHYSISC_LOG_ERROR,FileName);
		#endif
		return FileName;
	}
	Stuff.BackPosition=&BackPosition;
	Cell.push_back(Stuff);
	#ifdef Z_PHYSISC_LOG
	ZPrintLog(Z_FILE_NAME_LOG,Z_PHYSISC_LOG_OK,FileName);
	#endif
	return 0;
}
void ZPhysisc::ZCalculatePosition(float &DeltaTime)
{
	//Velocity  = Velocity+((Acceleration+Gravitation)*DeltaTime); 
	//VelocityC = Velocity;
	//Position  = Position+(Velocity*DeltaTime);
	//return Position;
//	return Cell[0].ZCalculatePosition(DeltaTime);
	for(unsigned int i=0; i<(unsigned int)Cell.size(); i++)
	{
		Cell[i].ZCalculatePosition(DeltaTime);
	}
}
bool ZPhysisc::ZCheckCollision(ZPhysisc &Zen)
{
	for(unsigned int i=0; i<(unsigned int)Cell.size(); i++)
	{
		for(unsigned int j=0; j<(unsigned int)Zen.Cell.size(); j++)
		{
			if(Cell[i].ZCheckCollision(Zen.Cell[j]))
			{
				return true;
			}
		}
	}
	return false;
//	return ( Mass && Zen.Mass && ((Zen.Position-Position).GetLength()<=(Zen.Radius+Radius)) && (this!=&Zen) );
//	return ( Zen.Mass && ((Zen.Position-Position).GetLength()<=(Zen.Radius+Radius)) && (this!=&Zen) );
//	return Cell[0].ZCheckCollision(Zen.Cell[0]);
}
void ZPhysisc::ZCollisionVelocity(ZPhysisc &Zen)
{
	for(unsigned int i=0; i<(unsigned int)Cell.size(); i++)
	{
		for(unsigned int j=0; j<(unsigned int)Zen.Cell.size(); j++)
		{
			if(Cell[i].ZCheckCollision(Zen.Cell[j]))
				Cell[i].ZCollisionVelocity(Zen.Cell[j]);
		}
	}
//	Velocity=(2*Zen.Mass*Zen.VelocityC + VelocityC*(Mass-Zen.Mass))/(Mass+Zen.Mass);
//		Zen.Velocity=(2*Mass*VelocityC + Zen.VelocityC*(Mass-Zen.Mass))/(Mass+Zen.Mass);
//	 Cell[0].ZCollisionVelocity(Zen.Cell[0]);
}
bool ZPhysisc::ZCheckPlane(ZPhysisc &Zen)
{
	for(unsigned int i=0; i<(unsigned int)Cell.size(); i++)
	{
		for(unsigned int j=0; j<(unsigned int)Zen.Cell.size(); j++)
		{
			if(Cell[i].ZCheckPlane(Zen.Cell[j]))
			{
				return true;
			}
		}
	}
	return false;
}
void ZPhysisc::ZCollisionPlane(ZPhysisc &Zen)
{
	for(unsigned int i=0; i<(unsigned int)Cell.size(); i++)
	{
		for(unsigned int j=0; j<(unsigned int)Zen.Cell.size(); j++)
		{
			if(Cell[i].ZCheckPlane(Zen.Cell[j]))
				Cell[i].ZCollisionPlane(Zen.Cell[j]);
		}
	}
}
void ZPhysisc::operator=(const ZPhysisc& Zen)
{
	Cell.clear();
	Cell=Zen.Cell;
	BackPosition=Zen.BackPosition;
}