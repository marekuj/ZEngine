#pragma once

#include <vector>
#include "../Type/ZType.h"

class ZPhysisc
{
public:
	std::vector<ZPhysiscCell> Cell;
	Vector3D BackPosition;
	ZPhysisc(void);
	ZPhysisc(const ZPhysisc &Zen);
	~ZPhysisc(void);

	bool ZLoadFileTXT(ZPhysiscCell &Physisc,const char *FileName);		//Pobranie danych z pliku "*.txt" do pamieci/ZPhysiscCell/ (0 - ok |1 - error)
	bool ZLoadFilePHY(ZPhysiscCell &Physisc,const char *FileName);		//Pobranie danych z pliku "*.phy" do pamieci/ZPhysiscCell/ (0 - ok |1 - error)

	bool ZSaveFileTXT(ZPhysiscCell &Physisc,const char *FileName);		//Zaisanie fizyki z pamie�i/ZPhysiscCell/ do pliku "*.txt" (0 - ok |1 - error)
	bool ZSaveFilePHY(ZPhysiscCell &Physisc,const char *FileName);		//Zaisanie fizyki z pamie�i/ZPhysiscCell/ do pliku "*.phy" (0 - ok |1 - error)

	const char* ZLoadPhysisc(const char *FileName);						//Wczytanie fizyki do pamieci (0 - ok |~0 - error)

	void ZCalculatePosition(float &DeltaTime); 			//wyznacza poorzenie obiektu;
	bool ZCheckCollision(ZPhysisc &Zen);				// by�a ->true | nie by�a ->false
	void ZCollisionVelocity(ZPhysisc &Zen);
	bool ZCheckPlane(ZPhysisc &Zen);				// by�a ->true | nie by�a ->false
	void ZCollisionPlane(ZPhysisc &Zen);
	inline void operator=(const ZPhysisc& Zen);
};