#pragma once
#include <windows.h>
#include <gl/gl.h>
#include "Extension/ZExtension.h"
//#include <gl/glaux.h>
//#include <gl/glut.h>

//#include <gl/wglext.h>

#pragma comment(lib,"opengl32.lib")
//#pragma comment(lib,"glu32.lib")
//#pragma comment(lib,"glaux.lib")

#include "Math/Vector3D.h"
#include "Math/Vector2D.h"
 
struct ZDate
{
private:
public:
	char Type[10];
	char Version[10];
	char Description[100];
	unsigned int Index;
	unsigned int Vertex;
	unsigned int Normal;
	unsigned int TextureCoord;
	unsigned int FogCoord;
	//Tu trzeba dorobi�: 1-dzielenie na kilka cz�ci, 2-wszytanie tekstur, 3-wszytanie w�asnosci materia�u  
	unsigned int *PointIndex;
	Vector3D *PointVertex;
	Vector3D *PointNormal;
	Vector2D *PointTextureCoord;
	float *PointFogCoord;
protected:
public:
	ZDate(); 
	~ZDate();
	void ZCreatePointIndex(unsigned int Size);
	void ZCreatePointVertex(unsigned int Size);
	void ZCreatePointNormal(unsigned int Size);
	void ZCreatePointTextureCoord(unsigned int Size);
	void ZCreatePointFogCoord(unsigned int Size);

	void ZSetScale(Vector3D &Scale);
	void ZSetScale(float X, float Y, float Z);
	
	void ZDraw(int Part=0);	
	char* ZSaveHDD(char * FileName);
	char* ZLoadHDD(char * FileName);
	
	void ZDate::Print();
};