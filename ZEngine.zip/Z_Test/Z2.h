#pragma once
#include "../Object/ZObject.h"
#include <windows.h>
#include <gl\gl.h>


class Z2 :	public ZObject
{
public:	
	Z2(ZTree *Parent=0);
	virtual	~Z2(void);
	virtual void ZOnLoad(void);
	virtual void ZOnDraw(void);
};
