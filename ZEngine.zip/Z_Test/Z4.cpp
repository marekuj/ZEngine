#include "Z4.h"

//extern PFNGLFOGCOORDFEXTPROC glFogCoordfEXT;							// Our glFogCoordfEXT Function

Z4::Z4(ZTree *Parent):ZObject(Parent)
{
}
Z4::~Z4(void)
{
}
void Z4::ZOnLoad()
{
//	ZErrorLoadMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ4.zcg",VertexId));
//	ZErrorLoadMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ4.zcg",FragmentId));
	ZErrorLoadMessageBox(Manager.ZLoadMaterial("Data/Material/orange.txt",MaterialId));

	ZErrorLoadMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ1.zcg",VertexId));
	ZErrorLoadMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ1.zcg",FragmentId));
	ZErrorMessageBox(Manager.ZLoadTexture2D("Data/Image/Base.bmp",TexturesId));
	ZErrorMessageBox(Manager.ZLoadTexture2D("Data/Image/a.bmp",TexturesId));
	ZErrorLoadMessageBox(Manager.ZLoadTextureCube("Data/Image/skybox_xp.bmp","Data/Image/skybox_xn.bmp",
												  "Data/Image/skybox_yp.bmp","Data/Image/skybox_yn.bmp",
												  "Data/Image/skybox_zp.bmp","Data/Image/skybox_zn.bmp",
												  TexturesId));
	ZErrorLoadMessageBox(Manager.ZLoadTextureCube("Data/Image/TextureCube3/xp.bmp","Data/Image/TextureCube3/xn.bmp",
												  "Data/Image/TextureCube3/yp.bmp","Data/Image/TextureCube3/yn.bmp",
												  "Data/Image/TextureCube3/zp.bmp","Data/Image/TextureCube3/zn.bmp",
												  TexturesId));
	Date.ZLoadHDD("Data/Object/Z4.zdt");
	Date.ZSetScale(4.0f,4.0f,4.0f);
	//to poni�ej na odczyt z pliku mo�na zastapi�.
	Physisc.Cell.push_back(ZPhysiscCell());
		Physisc.Cell[0].Velocity.Set(1,0,0);
		Physisc.Cell[0].Radius=4.0;
		Physisc.Cell[0].BackPosition=&Physisc.BackPosition;
	Physisc.Cell.push_back(ZPhysiscCell());
		Physisc.Cell[1].Velocity.Set(-1,0,0);
		Physisc.Cell[1].Radius=4.0;
		Physisc.Cell[1].BackPosition=&Physisc.BackPosition;
	Physisc.Cell.push_back(ZPhysiscCell());
		Physisc.Cell[2].Velocity.Set(0,1,0);
		Physisc.Cell[2].Radius=4.0;
		Physisc.Cell[2].BackPosition=&Physisc.BackPosition;
	Physisc.Cell.push_back(ZPhysiscCell());
		Physisc.Cell[3].Velocity.Set(0,-1,0);
		Physisc.Cell[3].Radius=4.0;
		Physisc.Cell[3].BackPosition=&Physisc.BackPosition;
	Physisc.Cell.push_back(ZPhysiscCell());
		Physisc.Cell[4].Velocity.Set(0,0,1);
		Physisc.Cell[4].Radius=4.0;
			//Physisc.Cell[4].Radius=4.0;
			//Vector3D A=Physisc.Cell[4].Velocity*Physisc.Cell[4].Radius;
			//Vector3D B=(A-Vector3D(0,0,-3));
			//Physisc.Cell[4].Radius=B.GetLength();
			//B;

		Physisc.Cell[4].BackPosition=&Physisc.BackPosition;
	Physisc.Cell.push_back(ZPhysiscCell());
		Physisc.Cell[5].Velocity.Set(0,0,-1);
		Physisc.Cell[5].Radius=4.0;
		Physisc.Cell[5].BackPosition=&Physisc.BackPosition;
}
bool Z4::ZOnCollision(ZObject *Zen)
{
	if(Physisc.ZCheckPlane(Zen->Physisc) )
	{
		Physisc.ZCollisionPlane(Zen->Physisc);
		return true;
	}
	return false;
}
void Z4::ZOnAnimate(float &DeltaTime)
{
	//Physisc.Cell[0].Radius=Physisc.BackPosition.GetX()+4.0;
	//Physisc.Cell[1].Radius=Physisc.BackPosition.GetX()+4.0;
	//
	//Physisc.Cell[2].Radius=Physisc.BackPosition.GetY()+4.0;
	//Physisc.Cell[3].Radius=Physisc.BackPosition.GetY()+4.0;

	//Physisc.Cell[4].Radius=Physisc.BackPosition.GetZ()+4.0;
	//Physisc.Cell[5].Radius=Physisc.BackPosition.GetZ()+4.0;
}
void Z4::ZOnDraw(void)
{
	static float CubeSize = 4.0f;
	static float TexCoord = 4.0f;
	Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
	//Date.ZDraw();
	//*
		glNormal3f(-1.0f,0.0f,0.0f);
		glBegin(GL_QUADS);													
	 		glFogCoordfEXT( 1.0f);	glTexCoord3f( TexCoord,-TexCoord, TexCoord);	glVertex3f( CubeSize,-CubeSize, CubeSize);
			glFogCoordfEXT( 1.0f);	glTexCoord3f( TexCoord, TexCoord, TexCoord);	glVertex3f( CubeSize, CubeSize, CubeSize);
			glFogCoordfEXT( 1.0f);	glTexCoord3f( TexCoord, TexCoord,-TexCoord);	glVertex3f( CubeSize, CubeSize, -CubeSize);
			glFogCoordfEXT( 1.0f);	glTexCoord3f( TexCoord,-TexCoord,-TexCoord);	glVertex3f( CubeSize, -CubeSize,-CubeSize);
		glEnd();
		glNormal3f(1.0f,0.0f,0.0f);
		glBegin(GL_QUADS);													
	 		glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord,-TexCoord,-TexCoord);	glVertex3f(-CubeSize,-CubeSize,-CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord, TexCoord,-TexCoord);	glVertex3f(-CubeSize, CubeSize,-CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord, TexCoord, TexCoord);	glVertex3f(-CubeSize, CubeSize, CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord,-TexCoord, TexCoord);	glVertex3f(-CubeSize,-CubeSize, CubeSize);
		glEnd();
		glNormal3f(0.0f,-1.0f,0.0f);
		glBegin(GL_QUADS);													
	 		glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord, TexCoord,-TexCoord);	glVertex3f(-CubeSize, CubeSize,-CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f( TexCoord, TexCoord,-TexCoord);	glVertex3f( CubeSize, CubeSize,-CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f( TexCoord, TexCoord, TexCoord);	glVertex3f( CubeSize, CubeSize, CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord, TexCoord, TexCoord);	glVertex3f(-CubeSize, CubeSize, CubeSize);
		glEnd();
		glNormal3f(0.0f,1.0f,0.0f);
		glBegin(GL_QUADS);													
	 		glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord,-TexCoord, TexCoord);	glVertex3f(-CubeSize,-CubeSize, CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f( TexCoord,-TexCoord, TexCoord);	glVertex3f( CubeSize,-CubeSize, CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f( TexCoord,-TexCoord,-TexCoord);	glVertex3f( CubeSize,-CubeSize,-CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord,-TexCoord,-TexCoord);	glVertex3f(-CubeSize,-CubeSize,-CubeSize);
		glEnd();
		glNormal3f(0.0f,0.0f,1.0f);
		glBegin(GL_QUADS);													
	 		glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord,-TexCoord,-TexCoord);	glVertex3f(-CubeSize,-CubeSize,-CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f( TexCoord,-TexCoord,-TexCoord);	glVertex3f( CubeSize,-CubeSize,-CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f( TexCoord, TexCoord,-TexCoord);	glVertex3f( CubeSize, CubeSize,-CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord, TexCoord,-TexCoord);	glVertex3f(-CubeSize, CubeSize,-CubeSize);
		glEnd();
		glNormal3f(0.0f,0.0f,-1.0f);
		glBegin(GL_QUADS);													
	 		glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord, TexCoord, TexCoord);	glVertex3f(-CubeSize, CubeSize, CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f( TexCoord, TexCoord, TexCoord);	glVertex3f( CubeSize, CubeSize, CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f( TexCoord,-TexCoord, TexCoord);	glVertex3f( CubeSize,-CubeSize, CubeSize);
			glFogCoordfEXT( 0.0f);	glTexCoord3f(-TexCoord,-TexCoord, TexCoord);	glVertex3f(-CubeSize,-CubeSize, CubeSize);
		glEnd();
//*/
	Manager.ZUnSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZUnSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
}