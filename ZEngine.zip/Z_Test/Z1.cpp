#include "Z1.h"
#include "cmath"

Z1::Z1(ZTree *Parent):ZObject(Parent)
{
	Quadric=0;
	Size=0;
	Radius=0;
	Slices=0;
	Stacks=0;
}
Z1::~Z1(void)
{
		if(Quadric) gluDeleteQuadric(Quadric);
}
void Z1::ZOnLoad(void)
{
	ZErrorLoadMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ4.zcg",VertexId));
	ZErrorLoadMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ4.zcg",FragmentId));
	ZErrorLoadMessageBox(Manager.ZLoadTexture2D("Data/Image/Image.tga",TexturesId));
	ZErrorLoadMessageBox(Manager.ZLoadMaterial("Data/Material/red.txt",MaterialId));
	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z1_SR.txt"));

	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z1_LPD.txt"));
	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z1_PPD.txt"));
	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z1_LPG.txt"));
	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z1_PPG.txt"));

	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z1_LTD.txt"));
	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z1_PTD.txt"));
	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z1_LTG.txt"));
	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z1_PTG.txt"));

	for(unsigned int i=0; i<(unsigned int)Physisc.Cell.size();i++)
	{
		Physisc.Cell[i].Position*=Size;
//		if(Physisc.Cell[i].Position.GetZ()>0) Physisc.Cell[i].Position.SetZ(0);
	}

	Quadric = gluNewQuadric();
//  gluQuadricDrawStyle( Quadric,GLU_LINE );
    gluQuadricDrawStyle( Quadric,GLU_FILL );
//  gluQuadricDrawStyle( q,GLU_SILHOUETTE );
//  gluQuadricDrawStyle( q,GLU_POINT );
//  gluQuadricTexture(Quadric,GL_TRUE);

	//ModelMatrix.SetTranslationPart(Physisc.Cell[0].Position);
/*
	Physisc.Cell[0].Mass = 1.0f;	
	Physisc.Cell[0].Radius=Radius;
//	Physisc.Velocity.Set(-0.3,0,0);
//	Physisc.Acceleration.Set(-0.3,0,0);
	Physisc.ZSaveFileTXT(Physisc.Cell[0],"Data/Physisc/Z1.txt");
//*/
}
bool Z1::ZOnCollision(ZObject *Zen)
{
	if(Physisc.ZCheckCollision( ((ZObject*)Zen)->Physisc))
	{
		Physisc.ZCollisionVelocity( ((ZObject*)Zen)->Physisc);
		return true;
	}
	return false;
}
void Z1::ZOnAnimate(float &DeltaTime)
{
	Physisc.ZCalculatePosition(DeltaTime);
//	Beta.SetTranslationPart(Physisc.Cell[0].Position);
}
void Z1::ZOnDraw(void)
{
	Alpha=ModelMatrix;
//*
		Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
		//Line
		glBegin(GL_LINE_STRIP);
			glVertex3fv(Physisc.Cell[0].Position);
			glVertex3fv(Physisc.Cell[4].Position);
			glVertex3fv(Physisc.Cell[8].Position);
			glVertex3fv(Physisc.Cell[0].Position);
			glVertex3fv(Physisc.Cell[6].Position);
			glVertex3fv(Physisc.Cell[8].Position);
			glVertex3fv(Physisc.Cell[7].Position);
			glVertex3fv(Physisc.Cell[0].Position);
			glVertex3fv(Physisc.Cell[5].Position);
			glVertex3fv(Physisc.Cell[7].Position);
			glVertex3fv(Physisc.Cell[3].Position);
			glVertex3fv(Physisc.Cell[0].Position);
			glVertex3fv(Physisc.Cell[1].Position);
			glVertex3fv(Physisc.Cell[3].Position);
			glVertex3fv(Physisc.Cell[4].Position);
			glVertex3fv(Physisc.Cell[2].Position);
			glVertex3fv(Physisc.Cell[0].Position);
			glVertex3fv(Physisc.Cell[6].Position);
			glVertex3fv(Physisc.Cell[2].Position);
			glVertex3fv(Physisc.Cell[1].Position);
			glVertex3fv(Physisc.Cell[5].Position);
			glVertex3fv(Physisc.Cell[6].Position);
		glEnd();
//*/
		//Ball 1 (�rodek �rodek �rodek)
		ModelMatrix.SetTranslationPart(Physisc.Cell[0].Position);
		Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
		gluSphere(Quadric,Radius,Slices,Stacks);
		//Ball 2  (lewo d� prz�d)
		ModelMatrix.SetTranslationPart(Physisc.Cell[1].Position);
		Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
		gluSphere(Quadric,Radius,Slices,Stacks);
		//Ball 3  (lewo d� ty�)
		ModelMatrix.SetTranslationPart(Physisc.Cell[5].Position);
		Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
		gluSphere(Quadric,Radius,Slices,Stacks);
		//Ball 4  (lewo g�ra prz�d)
		ModelMatrix.SetTranslationPart(Physisc.Cell[4].Position);
		Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
		gluSphere(Quadric,Radius,Slices,Stacks);
		//Ball 5  (lewo g�ra ty�)
		ModelMatrix.SetTranslationPart(Physisc.Cell[7].Position);
		Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
		gluSphere(Quadric,Radius,Slices,Stacks);
		//Ball 6  (prawo d� prz�d)
		ModelMatrix.SetTranslationPart(Physisc.Cell[2].Position);
		Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
		gluSphere(Quadric,Radius,Slices,Stacks);
		//Ball 7  (prawo d� ty�)
		ModelMatrix.SetTranslationPart(Physisc.Cell[6].Position);
		Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
		gluSphere(Quadric,Radius,Slices,Stacks);
		//Ball 8  (prawo g�ra prz�d)
		ModelMatrix.SetTranslationPart(Physisc.Cell[3].Position);
		Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
		gluSphere(Quadric,Radius,Slices,Stacks);
		//Ball 9  (prawo g�ra ty�)
		ModelMatrix.SetTranslationPart(Physisc.Cell[8].Position);
		Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
		gluSphere(Quadric,Radius,Slices,Stacks);
	Manager.ZUnSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZUnSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
	ModelMatrix=Alpha;
}
void Z1::ZSetSize(float NewSize)
{
	if(NewSize>0) Size=NewSize;
	else Size=0; 
}
void Z1::ZSetBall(float NewSize,float NewSlices,float NewStacks)
{
	if(NewSize>0) Radius=NewSize;
	else Radius=0; 
	if(NewSlices>0) Slices=NewSlices;
	else Slices=0; 
	if(NewStacks>0) Stacks=NewStacks;
	else Stacks=0; 
}