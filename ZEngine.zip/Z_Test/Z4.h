#pragma once
#include "../Object/ZObject.h"

class Z4 : public ZObject
{
private:
public:
	Z4(ZTree *Parent=0);
	virtual ~Z4(void);
	virtual void ZOnLoad(void);
	virtual bool ZOnCollision(ZObject *Zen);
	virtual void ZOnAnimate(float &DeltaTime);
	virtual void ZOnDraw(void);
};
