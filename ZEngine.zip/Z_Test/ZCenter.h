#pragma once
#include "../Object/ZObject.h"
//******************************************************************************//
//*																			   *//
//*																			   *//
//*		ZCenter - rysuje uk�ad osi XYZ										   *//
//*																			   *//
//*																			   *//
//******************************************************************************//
//*		Project: ZEngine - 3d OpenGL graphic engine.						   *//
//*		autor: Marek Kieruzel (wolf_45)  									   *//
//*		e-mail: wolf_45@o2.pl												   *//
//*		Copyright (c) 2006-2007.											   *//
//*		All rights reserved.			  									   *//
//******************************************************************************//
class ZCenter :	public ZObject
{
private:
	int IsTexture;
protected:
public:
	ZCenter(ZTree *Parent=0);
	virtual	~ZCenter(void);
	virtual void ZOnLoad(void);
	virtual void ZOnDraw(void);
//	virtual void ZSetMaterial(int NrMaterial);
};
