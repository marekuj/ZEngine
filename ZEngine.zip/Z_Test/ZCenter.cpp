#include "ZCenter.h"

ZCenter::ZCenter(ZTree *Parent):ZObject(Parent)
{
}
ZCenter::~ZCenter(void)
{
}
void ZCenter::ZOnLoad(void)
{
	
//	ZErrorLoadMessageBox(Manager.Material.ZLoadMaterial("Data/Material/red.txt",MaterialId));
//	ZErrorLoadMessageBox(Manager.Material.ZLoadMaterial("Data/Material/green.txt",MaterialId));
//	ZErrorLoadMessageBox(Manager.Material.ZLoadMaterial("Data/Material/blue.txt",MaterialId));
//	ZErrorLoadMessageBox(Manager.Material.ZLoadMaterial("Data/Material/black.txt",MaterialId));

	Manager.Material.ZLoadMaterial("Data/Material/red.txt",MaterialId);
	Manager.Material.ZLoadMaterial("Data/Material/green.txt",MaterialId);
	Manager.Material.ZLoadMaterial("Data/Material/blue.txt",MaterialId);
	Manager.Material.ZLoadMaterial("Data/Material/black.txt",MaterialId);
	IsTexture=1;

	if(Physisc.Cell.size()>0)
		ModelMatrix.SetTranslationPart(Physisc.Cell[0].Position);
}
void ZCenter::ZOnDraw()
{
	if(1)
	{
	Gamma=ModelMatrix;

	#ifdef Z_OPENGL_ENABLE_STATE
	glLoadMatrixf(ZGetModelViewMatrix());
	#else
	glLoadMatrixf(ZGetModelViewProjMatrix());
	#endif
	if(glIsEnabled(GL_TEXTURE_2D))
	{
		IsTexture=1;
		glDisable(GL_TEXTURE_2D);
	}
	else
	{
		IsTexture=0;
	}
	Manager.Material.ZBindMaterial(0,MaterialId);
	glutSolidCone(0.005,1,10,10);
		Alpha.SetRotationAxis(90,Vector3D(0,1,0));
		ModelMatrix*=Alpha;
	glLoadMatrixf(ZGetModelViewMatrix());
	Manager.Material.ZBindMaterial(1,MaterialId);
	glutSolidCone(0.005,1,10,10);
		Alpha.SetRotationAxis(-90,Vector3D(1,0,0));
		ModelMatrix*=Alpha;
	glLoadMatrixf(ZGetModelViewMatrix());
	Manager.Material.ZBindMaterial(2,MaterialId);
	glutSolidCone(0.005,1,10,10);
	Manager.Material.ZBindMaterial(3,MaterialId);
	glutSolidSphere(0.01,15,15);
	if(IsTexture) glEnable(GL_TEXTURE_2D);
	ModelMatrix=Gamma;
	}
}
//void ZCenter::ZSetMaterial(int NrMaterial)
//{
//	switch(NrMaterial)
//	{
//	case 0:
//		Material[0].ZSetDiffuse(1.0f,0.0f,0.0f,1.0f);
//		Material[0].ZSetFrontSpecular(1.0f,1.0f,1.0f,1.0f);
//		Material[0].ZSetShininess(16.0f);
//		break;
//	case 1:
//		Material[1].ZSetDiffuse(0.0f,1.0f,0.0f,1.0f);
//		Material[1].ZSetFrontSpecular(1.0f,1.0f,1.0f,1.0f);
//		Material[1].ZSetShininess(16.0f);
//		break;
//	case 2:
//		Material[2].ZSetDiffuse(1.0f,0.0f,1.0f,1.0f);
//		Material[2].ZSetFrontSpecular(1.0f,1.0f,1.0f,1.0f);
//		Material[2].ZSetShininess(16.0f);
//		break;
//	case 3:
//		Material[3].ZSetDiffuse(0.0f,0.0f,0.0f,1.0f);
//		Material[3].ZSetFrontSpecular(1.0f,1.0f,1.0f,1.0f);
//		Material[3].ZSetShininess(16.0f);
//		break;
//	}
//}