#pragma once
#include "../Object/ZObject.h"

class Z_L0 : public ZObject
{
private:
	float LScale;
	float Theta;
	Vector3D Position;
public:	
	Z_L0(ZTree *Parent=0);
	virtual	~Z_L0(void);
	virtual void ZOnLoad(void);
	virtual void ZOnAnimate(float &DeltaTime);
	virtual void ZOnDraw();
};