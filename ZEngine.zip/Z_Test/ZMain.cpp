#include "ZEngine.h"

#include <fstream>
using namespace std;

int  WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	ZInitEngine	ZSetting;
	ZSetting.Title = "WAPI + OpenGL + FSAA";
	ZSetting.Width		 = 800;
	ZSetting.Height		 = 600;
	ZSetting.ColorBits	 = 32;
	ZSetting.FullScreen  = false;
	ZSetting.VSync		 = true;
	ZSetting.SamplesAnis = 8;
	ZSetting.SamplesFSAA = 8;

	ZEngine* ZSpac=0;
	ZSpac = new ZEngine();
	if(ZSpac->ZCreateEngine(ZSetting))
		return 0;

	int LoopReturn=ZSpac->ZEnterMessageLoop();

	int Begin=0,End=0;
	Begin=ZSpac->Root->ZHowMany();
	delete ZSpac;
	End=ZSpac->Root->ZHowMany();

	ofstream File("0_HowMany.txt",ios::app);
	File<<"Begin: "<<Begin<<endl
		<<"End: "<<End<<endl;
	File.close();
	return LoopReturn;
}