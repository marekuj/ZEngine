#pragma once

#include "../BaseEngine/ZBaseEngine.h"

#include "../Fonts/ZBitmapFonts.h"

#include "Z_L0.h"
#include "Z_L1.h"

#include "ZCenter.h"
#include "Z1.h"
#include "Z2.h"
#include "Z3.h"
#include "Z4.h"
#include "Z5.h"

class ZEngine : public ZBaseEngine
{
public:
	ZEngine(void);
	~ZEngine(void);

	virtual void ZCreateObject(void);
	virtual void ZSetObject(void);
	virtual void ZUpdateObject(void);
	virtual void ZCheckInput(float &DeltaTime);
//	virtual void ZDestrojObject(void);
};