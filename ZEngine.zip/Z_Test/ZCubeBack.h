#pragma once
#include "../Object/ZObject.h"
//*****************************************************************************//
//*																			   *//
//*																			   *//
//*		ZCubeBack - rysuje t�o sceny w oparci o sze�cian.					   *//
//*																			   *//
//*																			   *//
//******************************************************************************//
//*		Project: ZEngine - 3d OpenGL graphic engine.						   *//
//*		autor: Marek Kieruzel (wolf_45)  									   *//
//*		e-mail: wolf_45@o2.pl												   *//
//*		Copyright (c) 2006-2007.											   *//
//*		All rights reserved.			  									   *//
//******************************************************************************//
class ZCubeBack : public ZObject
{
private:
	GLfloat CubeSize;
	int IsLighting;
protected:
public:
	ZCubeBack(ZTree *Parent=0);
	virtual	~ZCubeBack(void);
	virtual void ZGenerate();
	virtual void ZDraw();
	virtual void ZSetTexture( int NrTexture);

	const char* ZLoadTextureBackground(const char* Back,const char* Front,
		const char* Floor,const char* Roof,const char* Right,const char* Left);		//wszytuje wszystkie tekstuty
	void ZSetCubeSize(float CubeSize);												//ustawia wielk�� kostki
	float ZGetCubeSize();															//zwraca wielko�� kostki
};
