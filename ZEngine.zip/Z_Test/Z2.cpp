#include "Z2.h"

Z2::Z2(ZTree *Parent):ZObject(Parent)
{
}
Z2::~Z2(void)
{
}
void Z2::ZOnLoad(void)
{
//	ZErrorMessageBox(Manager.ZLoadTexture("Data/Image/relief_rockwall.bmp",TexturesId));
//	ZErrorMessageBox(Manager.ZLoadTexture("Data/Image/relief_rockwall.tga",TexturesId));
	ZErrorMessageBox(Manager.ZLoadTexture2D("Data/Image/earth2.bmp",TexturesId));
	ZErrorMessageBox(Manager.ZLoadTexture2D("Data/Image/earth2_normalmap.bmp",TexturesId));
	
	ZErrorMessageBox(Manager.ZLoadMaterial("Data/Material/gray.txt",MaterialId));
//	ZErrorMessageBox(Manager.ZLoadMaterial("Data/Material/test.txt",MaterialId));
	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z2.txt"));

//	Date.ZLoadHDD("Data/Object/Z1.zdt");
	// Do filmu
	ZErrorMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ5.zcg",VertexId));
	ZErrorMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ5.zcg",FragmentId));

	//ZErrorMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ6.zcg",VertexId));
	//ZErrorMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ6.zcg",FragmentId));

// Do filmu
	ZErrorMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ7.zcg",VertexId));
	ZErrorMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ7.zcg",FragmentId));
	//	ModelMatrix.SetTranslationPart(Vector3D(-2,0,0)); 

	ModelMatrix.SetTranslationPart(Physisc.Cell[0].Position);
}
void Z2::ZOnDraw(void)
{
	Vector3D Tangent;
	static int A=1;
	static int SizeY=2;
	Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
	//	Tangent.Set(1,0,0);
	//	Manager.Program.ZSetParameter3fv(1,VertexId,1,Tangent);
	glBegin(GL_TRIANGLES);
		glNormal3d(0,0,1);
		glTexCoord2d(0.0,0.0);		glVertex3d(0.0,A*1.0,-2.0);
		glTexCoord2d(1.0,0.0);		glVertex3d(A*SizeY,A*1.0,-2.0);
		glTexCoord2d(0.0,1.0);		glVertex3d(0.0,A*2.0,-2.0);

		glTexCoord2d(1.0,0.0);		glVertex3d(A*SizeY,A*1.0,-2.0);
		glTexCoord2d(1.0,1.0);		glVertex3d(A*SizeY,A*2.0,-2.0);
		glTexCoord2d(0.0,1.0);		glVertex3d(0.0,A*2.0,-2.0);
			//glNormal3d(0,0,1);
			//glTexCoord2d(0.0,0.0);		glVertex3d(0.0,0.0,-2.0);
			//glTexCoord2d(1.0,0.0);		glVertex3d(2.0,0.0,-2.0);
			//glTexCoord2d(0.0,1.0);		glVertex3d(0.0,1.0,-2.0);

			//glTexCoord2d(1.0,0.0);		glVertex3d(2.0,0.0,-2.0);
			//glTexCoord2d(1.0,1.0);		glVertex3d(2.0,1.0,-2.0);
			//glTexCoord2d(0.0,1.0);		glVertex3d(0.0,1.0,-2.0);
	glEnd();
	Manager.ZUnSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZUnSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
//	Date.ZDraw();
	Manager.ZSetAuto(1,VertexId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZSetAuto(1,FragmentId,0,MaterialId,0,TexturesId,LightId);
	//	Tangent.Set(1,0,0);
	//	Manager.Program.ZSetParameter3fv(1,VertexId,1,Tangent);
	glBegin(GL_TRIANGLES);
		glNormal3d(0,0,1);
		glTexCoord2d(0.0,0.0);		glVertex3d(0.0,0.0,-2.0);
		glTexCoord2d(1.0,0.0);		glVertex3d(A*SizeY,0.0,-2.0);
		glTexCoord2d(0.0,1.0);		glVertex3d(0.0,A*1.0,-2.0);

		glTexCoord2d(1.0,0.0);		glVertex3d(A*SizeY,0.0,-2.0);
		glTexCoord2d(1.0,1.0);		glVertex3d(A*SizeY,A*1.0,-2.0);
		glTexCoord2d(0.0,1.0);		glVertex3d(0.0,A*1.0,-2.0);
			//glNormal3d(0,1,0);
			//glTexCoord2d(0.0,0.0);		glVertex3d(0.0,0.0,-1.0);
			//glTexCoord2d(1.0,0.0);		glVertex3d(2.0,0.0,-1.0);
			//glTexCoord2d(0.0,1.0);		glVertex3d(0.0,0.0,-2.0);

			//glTexCoord2d(1.0,0.0);		glVertex3d(2.0,0.0,-1.0);
			//glTexCoord2d(1.0,1.0);		glVertex3d(2.0,0.0,-2.0);
			//glTexCoord2d(0.0,1.0);		glVertex3d(0.0,0.0,-2.0);
	glEnd();
	Manager.ZUnSetAuto(1,FragmentId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZUnSetAuto(1,VertexId,0,MaterialId,0,TexturesId,LightId);
}
