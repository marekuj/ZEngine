#include "Z_L1.h"
#include <cmath>

Z_L1::Z_L1(ZTree *Parent):ZObject(Parent)
{
}
Z_L1::~Z_L1(void)
{
}
void Z_L1::ZOnLoad(void)
{
	ZErrorLoadMessageBox(Manager.ZLoadLight("Data/Light/Light_1.txt",LightId));
	LScale=1.0f;
	Theta=0.0f;
}
void Z_L1::ZOnAnimate(float &DeltaTime)
{
	static float LocalTime=0;
	LocalTime+=DeltaTime;
	if(LocalTime>=0.02f)
	{
		LocalTime=0;
		Theta -= 0.04f;
		Position.Set(cos(Theta)*LScale,LScale,sin(Theta)*LScale);
		Manager.Light.ZGetCell(0,LightId).Position.Set(ZGetModelViewMatrix()*Position);
	}
}
void Z_L1::ZOnDraw(void)
{
	#ifdef Z_LIGHT_MANAGER_DRAW_LIGHT
		#ifdef Z_OPENGL_ENABLE_STATE
		glLoadMatrixf(ZGetModelViewMatrix());
		Manager.Light.ZDrawPosition(0,LightId,ZGetModelViewMatrix().GetInverse());
		#else
		glLoadMatrixf(ZGetModelViewProjMatrix());
		Manager.Light.ZDrawPosition(0,LightId,ZGetModelViewMatrix().GetInverse());
		#endif
	#endif
}