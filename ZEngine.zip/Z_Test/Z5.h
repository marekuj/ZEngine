#pragma once
#include "../Object/ZObject.h"

class Z5 :	public ZObject
{
private:
	GLUquadricObj *Quadric;
	Vector3D Position;
	Vector3D Direction;
	float RotX;
	float RotY;
public:
	Z5(ZTree *Parent=0);
	virtual	~Z5(void);

	virtual void ZOnLoad(void);
	virtual void ZOnAnimate(float &DeltaTime);
	virtual void ZDraw();

	void SetRotX(float AddX); 
	void SetRotY(float AddY); 
//	virtual void ZSetTexture(unsigned int NrTexture);
};
