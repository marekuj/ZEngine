#include "Z5.h"
#include "../MonkeyHead.h"

void DrawMonkeyHead(void)
{
	static GLfloat *texcoords = NULL;  /* Malloc'ed buffer, never freed. */
	static GLfloat Size = 0.4f; 
	/* Generate a set of 2D texture coordinate from the scaled (x,y)
	 vertex positions. */
	if (texcoords == NULL)
	{
		const int numVertices = sizeof(MonkeyHead_vertices) /
							(3*sizeof(MonkeyHead_vertices[0]));
		const float scaleFactor = 1.5;
		int i;
		for (i=0; i<MonkeyHead_num_of_vertices*3; i++)
		{
			MonkeyHead_vertices[i]=MonkeyHead_vertices[i]*Size;
		}
		texcoords = (GLfloat*) malloc(2 * numVertices * sizeof(GLfloat));
		for (i=0; i<numVertices; i++)
		{
			texcoords[i*2 + 0] = scaleFactor * MonkeyHead_vertices[i*3 + 0];
			texcoords[i*2 + 1] = scaleFactor * MonkeyHead_vertices[i*3 + 1];
		}
	}

	glDisableClientState(GL_FOG_COORDINATE_ARRAY);
	glVertexPointer(3, GL_FLOAT, 3*sizeof(GLfloat), MonkeyHead_vertices);
	glNormalPointer(GL_FLOAT, 3*sizeof(GLfloat), MonkeyHead_normals);
	glTexCoordPointer(2, GL_FLOAT, 2*sizeof(GLfloat), texcoords);

	glDrawElements(GL_TRIANGLES, 3*MonkeyHead_num_of_triangles,
					GL_UNSIGNED_SHORT, MonkeyHead_triangles);
	glEnableClientState(GL_FOG_COORDINATE_ARRAY);
}
Z5::Z5(ZTree *Parent):ZObject(Parent)
{
	Quadric=0;
}
Z5::~Z5(void)
{
	if(Quadric) gluDeleteQuadric(Quadric);
}
void Z5::ZOnLoad(void)
{
	Quadric = gluNewQuadric();

	gluQuadricDrawStyle(Quadric,GLU_FILL );
	gluQuadricTexture(Quadric,GL_TRUE);
//	ZErrorLoadMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ1.zcg",VertexId));
//	ZErrorLoadMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ1.zcg",FragmentId));

//	ZErrorMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ4.zcg",VertexId));
//	ZErrorMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ4.zcg",FragmentId));

//	ZErrorMessageBox(Manager.ZLoadVertex("Data/Shader/cgZM.zcg",VertexId));
//	ZErrorMessageBox(Manager.ZLoadFragment("Data/Shader/cgZM.zcg",FragmentId));

//	ZErrorMessageBox(Manager.ZLoadVertex("Data/Shader/cgZN.zcg",VertexId));
//	ZErrorMessageBox(Manager.ZLoadFragment("Data/Shader/cgZN.zcg",FragmentId));

//	ZErrorMessageBox(Manager.ZLoadVertex("Data/Shader/cgZO.zcg",VertexId));
//	ZErrorMessageBox(Manager.ZLoadFragment("Data/Shader/cgZO.zcg",FragmentId));

	ZErrorMessageBox(Manager.ZLoadVertex("Data/Shader/cgZP.zcg",VertexId));
	ZErrorMessageBox(Manager.ZLoadFragment("Data/Shader/cgZP.zcg",FragmentId));

//	Aizotropy light ~nie dzia�a doko�ca. 
//	ZErrorMessageBox(Manager.ZLoadVertex("Data/Shader/cgZR.zcg",VertexId));
//	ZErrorMessageBox(Manager.ZLoadFragment("Data/Shader/cgZR.zcg",FragmentId));

	ZErrorMessageBox(Manager.ZLoadTexture2D("Data/Image/c2_normal.bmp",TexturesId));
//	ZErrorMessageBox(Manager.ZLoadTexture2D("Data/Image/ogl_aniso.tga",TexturesId));
		//ZErrorLoadMessageBox(Manager.ZLoadTextureCube("Data/Image/skybox_xp.bmp","Data/Image/skybox_xn.bmp",
		//											  "Data/Image/skybox_yp.bmp","Data/Image/skybox_yn.bmp",
		//											  "Data/Image/skybox_zp.bmp","Data/Image/skybox_zn.bmp",
		//											  TexturesId));
	ZErrorLoadMessageBox(Manager.ZLoadTextureCube("Data/Image/TextureCube3/xp.bmp","Data/Image/TextureCube3/xn.bmp",
												  "Data/Image/TextureCube3/yp.bmp","Data/Image/TextureCube3/yn.bmp",
												  "Data/Image/TextureCube3/zp.bmp","Data/Image/TextureCube3/zn.bmp",
												  TexturesId));

	ZErrorLoadMessageBox(Manager.ZLoadMaterial("Data/Material/blue.txt",MaterialId));
	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z5.txt"));

	ZErrorMessageBox(Date.ZLoadHDD("Data/Object/Z2.zdt"));
	Date.ZSetScale(0.2f,0.2f,0.2f);

	ZErrorLoadMessageBox(Manager.ZLoadLight("Data/Light/Light_2.txt",LightId));

	RotX=0;
	RotY=0;
	Position=Manager.Light.ZGetCell(0,LightId).Position;
	Direction=Manager.Light.ZGetCell(0,LightId).Direction;
}
void Z5::ZOnAnimate(float &DeltaTime)
{
	static Vector3D Buf;
	static float LocalTime=0;
	LocalTime+=DeltaTime;
	if(LocalTime>=0.02f)
	{
		LocalTime=0;
		ModelMatrix.SetRotationEuler(RotX,RotY,0);
		ModelMatrix.SetTranslationPart(Physisc.Cell[0].Position);
		Buf = ModelMatrix.GetRotatedVector3D(Direction);
		Manager.Light.ZGetCell(0,LightId).Position.Set(ZGetModelViewMatrix()*Position);
		Manager.Light.ZGetCell(0,LightId).Direction.Set(Buf);
	}
}
void Z5::ZDraw()
{
	Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
//	Date.ZDraw();
	DrawMonkeyHead();
//	gluSphere(Quadric,0.25,20,20);

	Manager.ZUnSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZUnSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
}
void Z5::SetRotX(float AddX)
{
	RotX+=AddX;
	if(RotX>360) RotX-=360;
	if(RotX<-360) RotX+=360;
}
void Z5::SetRotY(float AddY)
{
	RotY+=AddY;
	if(RotY>360) RotY-=360;
	if(RotY<-360) RotY+=360;
}
//void Z5::ZSetTexture(unsigned int NrTexture)
//{
////	if(Manager.Texture.ZGetAnisotropy()>1)
////		glTexParameterf(GL_TEXTURE_2D,GL_TEXTURE_MAX_ANISOTROPY_EXT,Manager.Texture.ZGetAnisotropy());
////	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
////	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
//	////glPixelStorei( GL_UNPACK_ALIGNMENT, 1 );
//
//	////glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT_ARB );
// ////   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT_ARB );
//
//	////glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
// ////   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
//
//	////glTexEnvf( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_COMBINE_EXT );
//
// ////   glTexEnvf( GL_TEXTURE_ENV, GL_SOURCE0_RGB_EXT, GL_TEXTURE );
//	////glTexEnvf( GL_TEXTURE_ENV, GL_OPERAND0_RGB_EXT, GL_SRC_COLOR );
//
// ////   glTexEnvf( GL_TEXTURE_ENV, GL_SOURCE1_RGB_EXT, GL_TEXTURE );
//	////glTexEnvf( GL_TEXTURE_ENV, GL_OPERAND1_RGB_EXT, GL_SRC_ALPHA );
//
//	//// Modulate the texture brightness by 4X
//	//glTexEnvf( GL_TEXTURE_ENV, GL_COMBINE_RGB_EXT, GL_MODULATE );
// //   glTexEnvf( GL_TEXTURE_ENV, GL_RGB_SCALE_EXT, 4.0f );
//
////	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR_MIPMAP_LINEAR);
////	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, 16);
////**********************************************************************************
//}
