#include "ZCubeBack.h"

ZCubeBack::ZCubeBack(ZTree *Parent):ZObject(Parent)
{
	CubeSize=1;
	IsLighting=1;
}
ZCubeBack::~ZCubeBack(void)
{
}
void ZCubeBack::ZGenerate()
{
	CubeSize=1;
	IsLighting=1;
}
void ZCubeBack::ZDraw()
{
	#ifdef Z_OPENGL_ENABLE_STATE
	glLoadMatrixf(ZGetModelViewMatrix());
	#else
	glLoadMatrixf(ZGetModelViewProjMatrix());
	#endif
	if(glIsEnabled(GL_LIGHTING))
	{
		IsLighting=1;
		glDisable(GL_LIGHTING);
	}
	else
	{
		IsLighting=0;
	}
	// Front Wall
	Manager.Texture.ZBindTexture2D(0,TexturesId);
	glNormal3f(0.0f,0.0f,1.0f);
	glBegin(GL_QUADS);													
	 	glFogCoordfEXT( 1.0f);	glTexCoord2f(0.0f, 0.0f);	glVertex3f(-CubeSize,-CubeSize,-CubeSize);
		glFogCoordfEXT( 1.0f);	glTexCoord2f(1.0f, 0.0f);	glVertex3f( CubeSize,-CubeSize,-CubeSize);
		glFogCoordfEXT( 1.0f);	glTexCoord2f(1.0f, 1.0f);	glVertex3f( CubeSize, CubeSize,-CubeSize);
		glFogCoordfEXT( 1.0f);	glTexCoord2f(0.0f, 1.0f);	glVertex3f(-CubeSize, CubeSize,-CubeSize);
	glEnd();
	// Back Wall
	Manager.Texture.ZBindTexture2D(1,TexturesId);
	glNormal3f(0.0f,0.0f,-1.0f);
	glBegin(GL_QUADS);													
	 	glFogCoordfEXT( 0.0f);	glTexCoord2f(1.0f, 1.0f);	glVertex3f(-CubeSize, CubeSize,CubeSize);
		glFogCoordfEXT( 0.0f);	glTexCoord2f(0.0f, 1.0f);	glVertex3f( CubeSize, CubeSize,CubeSize);
		glFogCoordfEXT( 0.0f);	glTexCoord2f(0.0f, 0.0f);	glVertex3f( CubeSize,-CubeSize,CubeSize);
		glFogCoordfEXT( 0.0f);	glTexCoord2f(1.0f, 0.0f);	glVertex3f(-CubeSize,-CubeSize,CubeSize);
	glEnd();
	// Floor
	Manager.Texture.ZBindTexture2D(2,TexturesId);
	glNormal3f(0.0f,1.0f,0.0f);
	glBegin(GL_QUADS);													
	 	glFogCoordfEXT( 1.0f);	glTexCoord2f(1.0f, 0.0f);	glVertex3f(-CubeSize,-CubeSize, CubeSize);
		glFogCoordfEXT( 1.0f);	glTexCoord2f(0.0f, 0.0f);	glVertex3f( CubeSize,-CubeSize, CubeSize);
		glFogCoordfEXT( 0.0f);	glTexCoord2f(0.0f, 1.0f);	glVertex3f( CubeSize,-CubeSize, -CubeSize);
		glFogCoordfEXT( 0.0f);	glTexCoord2f(1.0f, 1.0f);	glVertex3f(-CubeSize,-CubeSize, -CubeSize);
	glEnd();
	// Roof
	Manager.Texture.ZBindTexture2D(3,TexturesId);
	glNormal3f(0.0f,-1.0f,0.0f);
	glBegin(GL_QUADS);	
		glFogCoordfEXT( 1.0f);	glTexCoord2f(1.0f, 1.0f);	glVertex3f(-CubeSize, CubeSize,-CubeSize);
		glFogCoordfEXT( 1.0f);	glTexCoord2f(0.0f, 1.0f);	glVertex3f( CubeSize, CubeSize,-CubeSize);
		glFogCoordfEXT( 0.0f);	glTexCoord2f(0.0f, 0.0f);	glVertex3f( CubeSize, CubeSize, CubeSize);
		glFogCoordfEXT( 0.0f);	glTexCoord2f(1.0f, 0.0f);	glVertex3f(-CubeSize, CubeSize, CubeSize);
	glEnd();
	// Right Wall
	Manager.Texture.ZBindTexture2D(4,TexturesId);
	glNormal3f(-1.0f,0.0f,0.0f);
	glBegin(GL_QUADS);													
		glFogCoordfEXT( 0.0f);	glTexCoord2f(1.0f, 0.0f);	glVertex3f( CubeSize,-CubeSize, CubeSize);
		glFogCoordfEXT( 0.0f);	glTexCoord2f(1.0f, 1.0f);	glVertex3f( CubeSize, CubeSize, CubeSize);
		glFogCoordfEXT( 1.0f);	glTexCoord2f(0.0f, 1.0f);	glVertex3f( CubeSize, CubeSize,-CubeSize);
		glFogCoordfEXT( 1.0f);	glTexCoord2f(0.0f, 0.0f);	glVertex3f( CubeSize,-CubeSize,-CubeSize);
	glEnd();
	// Left Wall
	Manager.Texture.ZBindTexture2D(5,TexturesId);
	glNormal3f(1.0f,0.0f,0.0f);
	glBegin(GL_QUADS);												
	 	glFogCoordfEXT( 0.0f);	glTexCoord2f(1.0f, 0.0f);	glVertex3f(-CubeSize,-CubeSize, CubeSize);
		glFogCoordfEXT( 0.0f);	glTexCoord2f(0.0f, 0.0f);	glVertex3f(-CubeSize,-CubeSize,-CubeSize);
		glFogCoordfEXT( 1.0f);	glTexCoord2f(0.0f, 1.0f);	glVertex3f(-CubeSize, CubeSize,-CubeSize);
		glFogCoordfEXT( 1.0f);	glTexCoord2f(1.0f, 1.0f);	glVertex3f(-CubeSize, CubeSize, CubeSize);
	glEnd();
	if(IsLighting) glEnable(GL_LIGHTING);
}
void ZCubeBack::ZSetTexture( int NrTexture)
{
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR_MIPMAP_LINEAR);
}

const char* ZCubeBack::ZLoadTextureBackground(const char* Back,const char* Front,const char* Floor,const char* Roof,const char* Right,const char* Left)
{
	if(Manager.Texture.ZLoadTexture2D(Back,TexturesId))
		return Manager.Texture.ZLoadTexture2D(Back,TexturesId);
	if(Manager.Texture.ZLoadTexture2D(Front,TexturesId))
		return Manager.Texture.ZLoadTexture2D(Front,TexturesId);
	if(Manager.Texture.ZLoadTexture2D(Floor,TexturesId))
		return Manager.Texture.ZLoadTexture2D(Floor,TexturesId);
	if(Manager.Texture.ZLoadTexture2D(Roof,TexturesId))
		return Manager.Texture.ZLoadTexture2D(Roof,TexturesId);
	if(Manager.Texture.ZLoadTexture2D(Right,TexturesId))
		return Manager.Texture.ZLoadTexture2D(Right,TexturesId);
	if(Manager.Texture.ZLoadTexture2D(Left,TexturesId))
		return Manager.Texture.ZLoadTexture2D(Left,TexturesId);
	return 0;
}

void ZCubeBack::ZSetCubeSize(float CubeSize)
{
	if(CubeSize>0) this->CubeSize=CubeSize;
	else this->CubeSize=1;
}
float ZCubeBack::ZGetCubeSize()
{
	return CubeSize;
}
