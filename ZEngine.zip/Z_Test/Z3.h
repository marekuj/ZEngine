#pragma once
#include "../Object/ZObject.h"
/*
class Z3 : public ZObject
{
private:
	GLUquadricObj *Quadric;

public:	
	Z3(ZTree *Parent=0);
	virtual	~Z3(void);
	virtual void ZOnLoad(void);
	virtual void ZOnDraw(void);
};
*/
class Z3 : public ZObject
{
private:
	GLUquadricObj *Quadric;
public:	
	Z3(ZTree *Parent=0);
	virtual	~Z3(void);
	virtual void ZOnLoad(void);
	virtual bool ZOnCollision(ZObject *Zen);
	virtual void ZOnAnimate(float &DeltaTime);
	virtual void ZOnDraw(void);

	Vector3D& ZGetAcc(void)
	{
		return Physisc.Cell[0].Acceleration;
	}
};