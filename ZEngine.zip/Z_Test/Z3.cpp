#include "Z3.h"
#include <cmath>
/*
Z3::Z3(ZTree *Parent):ZObject(Parent)
{
	Quadric=0;
}

Z3::~Z3(void)
{
	if(Quadric) gluDeleteQuadric(Quadric);
}
void Z3::ZOnLoad(void)
{
//	ZErrorLoadMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ3.zcg",VertexId));
//	ZErrorLoadMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ3.zcg",FragmentId));
	ZErrorLoadMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ4.zcg",VertexId));
	ZErrorLoadMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ4.zcg",FragmentId));
	ZErrorLoadMessageBox(Manager.ZLoadMaterial("Data/Material/blue.txt",MaterialId));

	Quadric = gluNewQuadric();
//	gluQuadricDrawStyle(Quadric,GLU_LINE );
    gluQuadricDrawStyle(Quadric,GLU_FILL );
//  gluQuadricDrawStyle( q,GLU_SILHOUETTE );
//  gluQuadricDrawStyle( q,GLU_POINT );
	gluQuadricTexture(Quadric,GL_TRUE);

	ModelMatrix.SetRotationAxis(90,Vector3D(1,0,0));
	ModelMatrix.SetTranslationPart(Vector3D(-1.5,1,0));
}
void Z3::ZOnDraw(void)
{
	Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		//gluSphere(Quadric,0.2,40,40 );
		gluCylinder(Quadric,0,0.2,0.5,30,30);
		//glutSolidTeapot(1);
	Manager.ZUnSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZUnSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
}
*/
Z3::Z3(ZTree *Parent):ZObject(Parent)
{
	Quadric=0;
}
Z3::~Z3(void)
{
	if(Quadric) gluDeleteQuadric(Quadric);
}
void Z3::ZOnLoad(void)
{
//	ZErrorLoadMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ3.zcg",VertexId));
//	ZErrorLoadMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ3.zcg",FragmentId));
	ZErrorLoadMessageBox(Manager.ZLoadVertex("Data/Shader/cgZ4.zcg",VertexId));
	ZErrorLoadMessageBox(Manager.ZLoadFragment("Data/Shader/cgZ4.zcg",FragmentId));
	ZErrorLoadMessageBox(Manager.ZLoadMaterial("Data/Material/blue.txt",MaterialId));
	ZErrorLoadMessageBox(Physisc.ZLoadPhysisc("Data/Physisc/Z3.txt"));

	Quadric = gluNewQuadric();
//	gluQuadricDrawStyle(Quadric,GLU_LINE );
    gluQuadricDrawStyle(Quadric,GLU_FILL );
//  gluQuadricDrawStyle( q,GLU_SILHOUETTE );
//  gluQuadricDrawStyle( q,GLU_POINT );
	gluQuadricTexture(Quadric,GL_TRUE);

	ModelMatrix.SetTranslationPart(Physisc.Cell[0].Position);
/*
//	ModelMatrix.SetRotationAxis(90,Vector3D(1,0,0));
	ModelMatrix.SetTranslationPart(Vector3D(-1.5,1,0));
//	Physisc.Position=Vector3D(-1.5,1,0);
//	Physisc.Position=Vector3D(-1.5,0,0);
	Physisc.Cell[0].Position=Vector3D(-1.5,0,0);
	Physisc.Cell[0].Mass = 1.0f;	
	Physisc.Cell[0].Radius=0.15f;
	//Physisc.ZLoadFilePHY(Physisc.Cell[0],"Data/Physisc/Test.phy");
//	ZPhysiscCell A;
//	Physisc.ZLoadFilePHY(A,"Data/Physisc/Test.phy");
//	A;
//*/
}
bool Z3::ZOnCollision(ZObject *Zen)	//zrobic takie standartowe w zobject?
{									//zrobic po staremu ?! raczej tak
	if(Physisc.ZCheckCollision(Zen->Physisc) )
	{
		Physisc.ZCollisionVelocity( Zen->Physisc);
//		Vector3D A=Physisc.Cell[0].ZGetWorldPosition();
//		A;
		return true;
	}
	return false;
}
void Z3::ZOnAnimate(float &DeltaTime)
{
	static float LScale=1.0f;
	static float Theta=0.0f;
	Theta -= 0.01f;
//	Physisc.Position.Set(cos(Theta)*LScale,LScale,sin(Theta)*LScale);
//	Position.Set(cos(Theta)*LScale,LScale,sin(Theta)*LScale);
	//Physisc.Acceleration.Set(cos(Theta)*LScale,LScale,sin(Theta)*LScale);
	
//	Physisc.Velocity = Physisc.Velocity+(Physisc.Acceleration*DeltaTime); 
//	Physisc.Position = Physisc.Position+(Physisc.Velocity*DeltaTime);
//	ModelMatrix.SetTranslationPart(Physisc.Position);

	Physisc.ZCalculatePosition(DeltaTime);
	ModelMatrix.SetTranslationPart(Physisc.Cell[0].Position);
	//if(Physisc.Position.GetX()+0.15>=0.0)
	//{
	//	Physisc.Position.SetX(-0.15f);
	//	Physisc.Velocity=-Physisc.Velocity;
	//}
}
void Z3::ZOnDraw(void)
{
	Manager.ZSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
		//gluSphere(Quadric,0.2,40,40 );
		gluSphere(Quadric,0.15,20,20);
		//glutSolidTeapot(1);
	Manager.ZUnSetAuto(0,FragmentId,0,MaterialId,0,TexturesId,LightId);
	Manager.ZUnSetAuto(0,VertexId,0,MaterialId,0,TexturesId,LightId);
}