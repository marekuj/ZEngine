#include "ZEngine.h"

ZCamera* ZCam0=0;
ZCamera* ZCam1=0;

ZCenter* ZObiektAbsoluteCenter=0;
ZCenter* ZObiektCenter=0;

Z1* ZObiekt1=0;
Z2* ZObiekt2=0;
Z3* ZObiekt3=0;
Z4* ZObiekt4=0;
Z5* ZObiekt5=0;

Z_L0 *ZObiekt_L0=0;
Z_L1 *ZObiekt_L1=0;

ZBitmapFonts* ZFont=0;

float Speed=0.0f;

ZEngine::ZEngine(void):ZBaseEngine()
{
}
ZEngine::~ZEngine(void)
{
}
void ZEngine::ZCreateObject(void)
{
	ZCam0 = new ZCamera(Root);
//	ZCam1 = new ZCamera(Root);

	ZSetCameraLook(ZCam0);
	ZSetCameraHud(ZCam1);
	ZSetRoot(ZCam0);

	ZObiektAbsoluteCenter = new ZCenter(ZCam0);
	//ZObiekt_L0 = new Z_L0(ZObiektAbsoluteCenter);

	ZObiektCenter = new ZCenter(ZObiektAbsoluteCenter);

	ZObiekt_L1 = new Z_L1(ZObiektCenter);

	ZObiekt1 = new Z1(ZObiektCenter);
	ZObiekt2 = new Z2(ZObiektCenter);
	ZObiekt3 = new Z3(ZObiektCenter);
//	ZObiekt3 = new Z3(ZObiektAbsoluteCenter);
	ZObiekt4 = new Z4(ZObiektCenter);
	ZObiekt5 = new Z5(ZObiektCenter);

	ZCam1 = new ZCamera(ZObiektAbsoluteCenter);
	ZSetCameraHud(ZCam1);
	ZFont = new ZBitmapFonts(ZCam1);
}
void ZEngine::ZSetObject(void)
{
//*************************************************************************
	OpenGL.ZSetDepthTest();
	OpenGL.ZSetClearColor(0.7f,0.2f,0.7f);
	OpenGL.ZSetAmbientLight(0.2f,0.2f,0.2f,1.0f);
	OpenGL.ZSetLightModelTwoSide(0);
	OpenGL.ZSetLightModelLocalViewer(1);	//dzia�a!!
	OpenGL.ZSetLightModelColorControl(1);
	OpenGL.ZSetTexture2d(1);
	OpenGL.ZSetCullFace(1);
	OpenGL.ZSetShadeModel(1);

	OpenGL.ZSetVertexArray(1);
	OpenGL.ZSetNormalArray(1);
	OpenGL.ZSetTextureArray(1);
	OpenGL.ZSetFogArray(1);

	OpenGL.ZSetLight0(1);
	OpenGL.ZSetLight1(1);
	OpenGL.ZSetLighting(1);
//*************************************************************************
	ZShowCursor(false);

	ZCam0->ZSetMove(5,5,5,0,0);
	ZCam1->ZSetInterface(1);

	ZErrorLoadMessageBox(ZObiektAbsoluteCenter->Physisc.ZLoadPhysisc("Data/Physisc/ZOAC.txt"));
	ZErrorLoadMessageBox(ZObiektCenter->Physisc.ZLoadPhysisc("Data/Physisc/ZOC.txt"));
//	ZObiektCenter->ModelMatrix.SetTranslationPart(Vector3D(0,0,-3));

	ZObiekt1->ZSetSize(0.4);
	ZObiekt1->ZSetBall(0.1,20,20);

	ZFont->ZSetHDC(Window.hDC);
	ZFont->ZSetColor(1.0f,1.0f,0.0f,1.0f);
	ZFont->ZSetFontPos(-1.3f,0.9f);
}
void ZEngine::ZUpdateObject(void)
{
//	ZFont->ZSetPrintText("FPS: %i Speed: %.2f",ZGetFPS(),Speed);
	//ZFont->ZSetPrintText("FPS: %i Speed: %.2f Acc: [%.2f %.2f %.2f]",ZGetFPS(),Speed,
	//ZObiekt3->ZGetAcc().GetX(),
	//ZObiekt3->ZGetAcc().GetY(),
	//ZObiekt3->ZGetAcc().GetZ());
	ZFont->ZSetPrintText("FPS: %i Speed: %.2f Acc: [%.2f %.2f %.2f]",ZGetFPS(),
	ZObiekt3->Physisc.Cell[0].Velocity.GetLength(),
	ZObiekt3->ZGetAcc().GetX(),
	ZObiekt3->ZGetAcc().GetY(),
	ZObiekt3->ZGetAcc().GetZ());
}
void  ZEngine::ZCheckInput(float &DeltaTime)
{
	if(ZGetKeys(VK_ESCAPE))
	{
		PostQuitMessage(0);
		ZSetKeys(VK_ESCAPE,0);
	}
	else if(ZGetKeys('W'))
	{
		CameraLook->ZChangePitch(-2.0f);
	}
	else if(ZGetKeys('S'))
	{
		CameraLook->ZChangePitch(2.0f);
	}
	if(ZGetKeys('A'))
	{
		CameraLook->ZChangeHeading(-2.0f);
	}
	else if(ZGetKeys('D'))
	{
		CameraLook->ZChangeHeading(2.0f);
	}
	if(ZGetKeys('R'))
	{
		CameraLook->ZChangeVelocity(0.01f);
		Speed+=0.10f;
		ZSetKeys('R',0);
	}
	else if(ZGetKeys('F'))
	{
		CameraLook->ZChangeVelocity(-0.01f);
		Speed-=0.10f;
		ZSetKeys('F',0);
	}

	if(ZGetKeys(VK_UP))
	{
		ZObiekt3->ZGetAcc().SetY(ZObiekt3->ZGetAcc().GetY()+0.1);
		ZSetKeys(VK_UP,0);
	}
	else if(ZGetKeys(VK_DOWN))
	{
		ZObiekt3->ZGetAcc().SetY(ZObiekt3->ZGetAcc().GetY()-0.1);
		ZSetKeys(VK_DOWN,0);
	}
	if(ZGetKeys(VK_LEFT))
	{
		ZObiekt3->ZGetAcc().SetX(ZObiekt3->ZGetAcc().GetX()-0.1);
		ZSetKeys(VK_LEFT,0);
	}
	else if(ZGetKeys(VK_RIGHT))
	{
		ZObiekt3->ZGetAcc().SetX(ZObiekt3->ZGetAcc().GetX()+0.1);
		ZSetKeys(VK_RIGHT,0);
	}

	if(ZGetKeys('J'))
	{
		ZObiekt5->SetRotY(2.0);
	}
	else if(ZGetKeys('L'))
	{
		ZObiekt5->SetRotY(-2.0);
	}
	if(ZGetKeys('I'))
	{
		ZObiekt5->SetRotX(2.0);
	}
	else if(ZGetKeys('K'))
	{
		ZObiekt5->SetRotX(-2.0);
	}
	if(ZGetKeys(VK_F9))
	{
		ZErrorMessageBox(ZPrintScreenBMP("Data/PrintScreen/PrtScr_"));
		ZSetKeys(VK_F9,0);
	}
	if(ZGetKeys(VK_F8))
	{
		ZErrorMessageBox(ZPrintScreenTGA("Data/PrintScreen/PrtScr_"));
		ZSetKeys(VK_F8,0);
	}
	CameraLook->ZCheckMouse();
}