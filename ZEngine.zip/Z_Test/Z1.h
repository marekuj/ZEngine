#pragma once
#include "../Object/ZObject.h"

class Z1 : public ZObject
{
private:
	GLUquadricObj *Quadric;
	float LScale;
	float Theta;
	float Size;
	float Radius;
	float Slices;
	float Stacks;
public:	
	Z1(ZTree *Parent=0);
	virtual	~Z1(void);
	virtual void ZOnLoad(void);
	virtual bool ZOnCollision(ZObject *Zen);
	virtual void ZOnAnimate(float &DeltaTime);
	virtual void ZOnDraw(void);

	void ZSetSize(float NewSize);
	void ZSetBall(float NewSize,float NewSlices,float NewStacks);
};
