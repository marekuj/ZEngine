#include "Z_L0.h"
#include "cmath"

Z_L0::Z_L0(ZTree *Parent):ZObject(Parent)
{
}
Z_L0::~Z_L0(void)
{
}
void Z_L0::ZOnLoad(void)
{
	Manager.Light.ZGetGlobalLight().Ambient.Set(0.2,0.2,0.2);
	ZErrorLoadMessageBox(Manager.ZLoadLight("Data/Light/Light_0.txt",LightId));
	LScale=1.0f;
	Theta=0.0f;
}
void Z_L0::ZOnAnimate(float &DeltaTime)
{
	static float LocalTime=0;
	LocalTime+=DeltaTime;
	if(LocalTime>=0.02f)
	{
		LocalTime=0;
		Theta += 0.02f;
		Position.Set(cos(Theta)*LScale,sin(Theta)*LScale,0);
		Manager.Light.ZGetCell(0,LightId).Position.Set(ZGetModelViewMatrix()*Position);
	}
}
void Z_L0::ZOnDraw()
{
	#ifdef Z_LIGHT_MANAGER_DRAW_LIGHT
		#ifdef Z_OPENGL_ENABLE_STATE
		glLoadMatrixf(ZGetModelViewMatrix());
		Manager.Light.ZDrawPosition(0,LightId,ZGetModelViewMatrix().GetInverse());
		#else
		glLoadMatrixf(ZGetModelViewProjMatrix());
		Manager.Light.ZDrawPosition(0,LightId,ZGetModelViewMatrix().GetInverse());
		#endif
	#endif
}