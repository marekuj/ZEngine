#pragma once

#include "../Math/Vector3D.h"

namespace ZPhys			//700 <-> 799
{
	const unsigned int Z_ERR = 700;
	const Vector3D Z_GLOBAL_ACCELERATION(Vector3D(0,0,0));
};
namespace ZTexu			//800 <-> 899
{
	const unsigned int Z_ERR = 800;
	const unsigned int Z_BMP = 801;
	const unsigned int Z_TGA = 802;

	const unsigned int Z_TEX_1D = 820;	// GL_TEXTURE_1D
	const unsigned int Z_TEX_2D = 821;	// GL_TEXTURE_2D
	const unsigned int Z_TEX_3D = 822;	// GL_TEXTURE_3D
	const unsigned int Z_TEX_CUBE_PX = 823;	// GL_TEXTURE_CUBE_MAP
	const unsigned int Z_TEX_CUBE_NX = 824;	// GL_TEXTURE_CUBE_MAP
	const unsigned int Z_TEX_CUBE_PY = 825;	// GL_TEXTURE_CUBE_MAP
	const unsigned int Z_TEX_CUBE_NY = 826;	// GL_TEXTURE_CUBE_MAP
	const unsigned int Z_TEX_CUBE_PZ = 827;	// GL_TEXTURE_CUBE_MAP
	const unsigned int Z_TEX_CUBE_NZ = 828;	// GL_TEXTURE_CUBE_MAP

	const unsigned int Z_IS_NOT_LOAD = 850;	//Z_IS_NOT_LOAD<=Z_VALUE_LOAD+3  //Tekstura nie jest wczytana do pamieci 
	const unsigned int Z_VALUE_LOAD = 853;									 //Pocz�tkowa warto�� okre�lana podczas aktualizacji tekstury
};
namespace ZLigh			//900 <-> 999
{
	const unsigned int Z_ERR = 900;
	const unsigned int Z_POSITION = 901;
	const unsigned int Z_POSITION_ATTENUATION = 902;
	const unsigned int Z_DIRECTION_SINGLESPOT = 903;
	const unsigned int Z_DIRECTION_SINGLESPOT_ATTENUATION = 904;
	const unsigned int Z_DIRECTION_DUALSPOT = 905;
	const unsigned int Z_DIRECTION_DUALSPOT_ATTENUATION = 906;
};
namespace ZProg			//1000<->1999
{
	const unsigned int Z_ERR = 1000;
	const unsigned int Z_1FV = 1001;
	const unsigned int Z_2FV = 1002;
	const unsigned int Z_3FV = 1003;
	const unsigned int Z_4FV = 1004;
	const unsigned int Z_1DV = 1005;
	const unsigned int Z_2DV = 1006;
	const unsigned int Z_3DV = 1007;
	const unsigned int Z_4DV = 1008;
	const unsigned int Z_A1F = 1009; 
	const unsigned int Z_A2F = 1010;
	const unsigned int Z_A3F = 1011;
	const unsigned int Z_A4F = 1012;
	const unsigned int Z_A1D = 1013; 
	const unsigned int Z_A2D = 1014;
	const unsigned int Z_A3D = 1015;
	const unsigned int Z_A4D = 1016;
	const unsigned int Z_MFR = 1017;
	const unsigned int Z_MFC = 1018;
	const unsigned int Z_MDR = 1019;
	const unsigned int Z_MDC = 1020;
	const unsigned int Z_SMX = 1021;
	const unsigned int Z_TEX = 1022;

	const unsigned int Z_TEX_2D_S = 1050;
	const unsigned int Z_TEX_2D_M = 1051;
	const unsigned int Z_TEX_CUBE_S = 1052;
	const unsigned int Z_TEX_CUBE_M = 1053;

	const unsigned int Z_EYE_V = 1060;
	const unsigned int Z_EYE_M = 1061;

	const unsigned int Z_M_P_ID   = 1101;
	const unsigned int Z_M_V_ID   = 1102;
	const unsigned int Z_M_M_ID   = 1103;
	const unsigned int Z_M_VM_ID  = 1104;
	const unsigned int Z_M_VPM_ID = 1105;

	const unsigned int Z_M_P_TR   = 1106;
	const unsigned int Z_M_V_TR   = 1107;
	const unsigned int Z_M_M_TR   = 1108;
	const unsigned int Z_M_VM_TR  = 1109;
	const unsigned int Z_M_VPM_TR = 1110;

	const unsigned int Z_M_P_IN   = 1111;
	const unsigned int Z_M_V_IN   = 1112;
	const unsigned int Z_M_M_IN   = 1113;
	const unsigned int Z_M_VM_IN  = 1114;
	const unsigned int Z_M_VPM_IN = 1115;

	const unsigned int Z_M_P_IT   = 1116;
	const unsigned int Z_M_V_IT   = 1117;
	const unsigned int Z_M_M_IT   = 1118;
	const unsigned int Z_M_VM_IT  = 1119;
	const unsigned int Z_M_VPM_IT = 1120;

	const unsigned int Z_MAT = 1201;
	const unsigned int Z_LIG = 1202;
	const unsigned int Z_GLOB_LIG = 1203;
};