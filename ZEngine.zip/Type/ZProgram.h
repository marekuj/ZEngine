#pragma once

#include <string>
#include <vector>
#include "ZConstant.h"
#include "ZLoadCgParameter.h"

struct ZProgram
{
    CGenum ProgramType;
	CGprofile Profile;
    std::string Entry;
    const char **Args;				//tego nie uzywam 
	std::vector<ZLoadCgParameter> Parameter;
	std::string Name;
	ZProgram()
	{
		Args=0; 
	}
	ZProgram(const ZProgram &Zen)
	{
		ProgramType=Zen.ProgramType;
		Profile=Zen.Profile;
		Entry=Zen.Entry;
		Args=0;	
		Parameter = Zen.Parameter;
		Name=Zen.Name;
	}
	~ZProgram()
	{
		Parameter.clear();
	}
	void ZCreateParameter(unsigned int Size)
	{
		Parameter.clear();
		Parameter.resize(Size);
	}
	void operator=(const ZProgram& Zen)
	{
		ProgramType=Zen.ProgramType;
		Profile=Zen.Profile;
		Entry=Zen.Entry;
		Args=0;	
		Parameter.clear();
		Parameter=Zen.Parameter;
		Name=Zen.Name;
	}
};