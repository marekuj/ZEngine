#pragma once

#include <string>
#include "ZConstant.h"

struct ZInitEngine
{
	std::string Title;
	int Width;
	int Height;
	int ColorBits;
	bool FullScreen;
	bool VSync;
	int SamplesAnis;
	int SamplesFSAA;
};