#pragma once

#include <string>
#include <vector>
#include "ZConstant.h"
#include "ZTextureCell.h"

struct ZBindTexture
{
	std::vector<ZTextureCell> Cell;
	float SamplesAnis;
	unsigned int Id;								//indeks teskstury ustawiony w IsBind
	ZBindTexture(void)
	{
		SamplesAnis=0;
		Id=0;
	}
	ZBindTexture(const ZBindTexture &Zen)
	{
		SamplesAnis=Zen.SamplesAnis;
		Cell=Zen.Cell; 
		Id=Zen.Id;
	}
	~ZBindTexture(void)
	{
		SamplesAnis=0;
		Cell.clear();
		Id=0;
	}
	bool IsBind(const char *FileName)
	{
		for(unsigned int i=0; i<(unsigned int)Cell.size(); i++)
		{
			if(!Cell[i].Name.compare(FileName))
			{
				Id=i;
				return 1;
			}
		}
		return 0;
	}
	void AddSize(const char *FileName)
	{
		Cell.push_back(ZTextureCell());
		Id=(unsigned int)Cell.size()-1;
		Cell[(unsigned int)Cell.size()-1].Name=FileName;
		
		Cell[(unsigned int)Cell.size()-1].TextureId=0;
		Cell[(unsigned int)Cell.size()-1].IsActive=ZTexu::Z_VALUE_LOAD;
	}
};