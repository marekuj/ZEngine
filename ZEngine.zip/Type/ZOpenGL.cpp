#include "ZOpenGL.h"
#include "../Extension/ZExtension.h"

ZOpenGL::ZOpenGL(void)
{
	ZAmbient[0]=0.2f;  ZAmbient[1]=0.2f;	ZAmbient[2]=0.2f;  ZAmbient[3]=1.0f;
	ZLightModelTwoSide=0;
	ZLightModelLocalViewer=0;
	ZLightModelColorControl=0;
	ZShadeModel=1;

	if(glIsEnabled(GL_FOG)) ZFog=1;
	else ZFog=0;
	if(glIsEnabled(GL_LIGHTING)) ZLighting=1;
	else ZLighting=0;
	if(glIsEnabled(GL_TEXTURE_1D)) ZTexture1d=1;
	else ZTexture1d=0;
	if(glIsEnabled(GL_TEXTURE_2D)) ZTexture2d=1;
	else ZTexture2d=0;
	if(glIsEnabled(GL_LINE_STIPPLE)) ZLineStipple=1;
	else ZLineStipple=0;
	if(glIsEnabled(GL_POLYGON_STIPPLE)) ZPolygonStipple=1;
	else ZPolygonStipple=0;
	if(glIsEnabled(GL_CULL_FACE)) ZCullFace=1;
	else ZCullFace=0;
	if(glIsEnabled(GL_ALPHA_TEST)) ZAlphaTest=1;
	else ZAlphaTest=0;
	if(glIsEnabled(GL_BLEND)) ZBlend=1;
	else ZBlend=0;
	if(glIsEnabled(GL_INDEX_LOGIC_OP)) ZIndexLogicOp=1;
	else ZIndexLogicOp=0;
	if(glIsEnabled(GL_COLOR_LOGIC_OP)) ZColorLogicOp=1;
	else ZColorLogicOp=0;
	if(glIsEnabled(GL_DITHER)) ZDither=1;
	else ZDither=0;
	if(glIsEnabled(GL_STENCIL_TEST)) ZStencilTest=1;
	else ZStencilTest=0;
	if(glIsEnabled(GL_DEPTH_TEST)) ZDepthTest=1;
	else ZDepthTest=0;
	if(glIsEnabled(GL_CLIP_PLANE0)) ZClipPlane0=1;
	else ZClipPlane0=0;
	if(glIsEnabled(GL_CLIP_PLANE1)) ZClipPlane1=1;
	else ZClipPlane1=0;
	if(glIsEnabled(GL_CLIP_PLANE2)) ZClipPlane2=1;
	else ZClipPlane2=0;
	if(glIsEnabled(GL_CLIP_PLANE3)) ZClipPlane3=1;
	else ZClipPlane3=0;
	if(glIsEnabled(GL_CLIP_PLANE4)) ZClipPlane4=1;
	else ZClipPlane4=0;
	if(glIsEnabled(GL_CLIP_PLANE5)) ZClipPlane5=1;
	else ZClipPlane5=0;
	if(glIsEnabled(GL_LIGHT0)) ZLight0=1;	 
	else ZLight0=0;	 
	if(glIsEnabled(GL_LIGHT1)) ZLight1=1;	 
	else ZLight1=0;	 
	if(glIsEnabled(GL_LIGHT2)) ZLight2=1;	 
	else ZLight2=0;	 
	if(glIsEnabled(GL_LIGHT3)) ZLight3=1;	 
	else ZLight3=0;	 
	if(glIsEnabled(GL_LIGHT4)) ZLight4=1;	 
	else ZLight4=0;	 
	if(glIsEnabled(GL_LIGHT5)) ZLight5=1;	 
	else ZLight5=0;	 
	if(glIsEnabled(GL_LIGHT6)) ZLight6=1;	 
	else ZLight6=0;	 
	if(glIsEnabled(GL_LIGHT7)) ZLight7=1;	 
	else ZLight7=0;
	if(glIsEnabled(GL_TEXTURE_GEN_S)) ZTextureGenS=1;
	else ZTextureGenS=0;
	if(glIsEnabled(GL_TEXTURE_GEN_T)) ZTextureGenT=1;
	else ZTextureGenT=0;
	if(glIsEnabled(GL_TEXTURE_GEN_R)) ZTextureGenR=1;
	else ZTextureGenR=0;
	if(glIsEnabled(GL_TEXTURE_GEN_Q)) ZTextureGenQ=1;
	else ZTextureGenQ=0;
	if(glIsEnabled(GL_MAP1_VERTEX_3)) ZMap1Vertex3=1;
	else ZMap1Vertex3=0;
	if(glIsEnabled(GL_MAP1_VERTEX_4)) ZMap1Vertex4=1;
	else ZMap1Vertex4=0;
	if(glIsEnabled(GL_MAP1_COLOR_4)) ZMap1Color4=1;
	else ZMap1Color4=0;
	if(glIsEnabled(GL_MAP1_INDEX)) ZMap1Index=1;
	else ZMap1Index=0;
	if(glIsEnabled(GL_MAP1_NORMAL)) ZMap1Normal=1;
	else ZMap1Normal=0;
	if(glIsEnabled(GL_MAP1_TEXTURE_COORD_1)) ZMap1TextureCoord1=1;
	else ZMap1TextureCoord1=0;
	if(glIsEnabled(GL_MAP1_TEXTURE_COORD_2)) ZMap1TextureCoord2=1;
	else ZMap1TextureCoord2=0;
	if(glIsEnabled(GL_MAP1_TEXTURE_COORD_3)) ZMap1TextureCoord3=1;
	else ZMap1TextureCoord3=0;
	if(glIsEnabled(GL_MAP1_TEXTURE_COORD_4)) ZMap1TextureCoord4=1;
	else ZMap1TextureCoord4=0;
	if(glIsEnabled(GL_MAP2_VERTEX_3 )) ZMap2Vertex3=1;
	else ZMap2Vertex3=0;
	if(glIsEnabled(GL_MAP2_VERTEX_4)) ZMap2Vertex4=1;
	else ZMap2Vertex4=0;
	if(glIsEnabled(GL_MAP2_COLOR_4)) ZMap2Color4=1;
	else ZMap2Color4=0;
	if(glIsEnabled(GL_MAP2_INDEX)) ZMap2Index=1;
	else ZMap2Index=0;
	if(glIsEnabled(GL_MAP2_NORMAL)) ZMap2Normal=1;
	else ZMap2Normal=0;
	if(glIsEnabled(GL_MAP2_TEXTURE_COORD_1)) ZMap2TextureCoord1=1;
	else ZMap2TextureCoord1=0;
	if(glIsEnabled(GL_MAP2_TEXTURE_COORD_2)) ZMap2TextureCoord2=1;
	else ZMap2TextureCoord2=0;
	if(glIsEnabled(GL_MAP2_TEXTURE_COORD_3)) ZMap2TextureCoord3=1;
	else ZMap2TextureCoord3=0;
	if(glIsEnabled(GL_MAP2_TEXTURE_COORD_4)) ZMap2TextureCoord4=1;
	else ZMap2TextureCoord4=0;
	if(glIsEnabled(GL_POINT_SMOOTH)) ZPointSmooth=1;
	else ZPointSmooth=0;
	if(glIsEnabled(GL_LINE_SMOOTH)) ZLineSmooth=1;
	else ZLineSmooth=0;
	if(glIsEnabled(GL_POLYGON_SMOOTH)) ZPolygonSmooth=1;
	else ZPolygonSmooth=0;
	if(glIsEnabled(GL_SCISSOR_TEST)) ZScissorTest=1;
	else ZScissorTest=0;
	if(glIsEnabled(GL_COLOR_MATERIAL)) ZColorMaterial=1;
	else ZColorMaterial=0;
	if(glIsEnabled(GL_NORMALIZE)) ZNormalize=1;
	else ZNormalize=0;
	if(glIsEnabled(GL_AUTO_NORMAL)) ZAutoNormal=1;
	else ZAutoNormal=0;
	if(glIsEnabled(GL_VERTEX_ARRAY)) ZVertexArray=1;
	else ZVertexArray=0;
	if(glIsEnabled(GL_NORMAL_ARRAY)) ZNormalArray=1;
	else ZNormalArray=0;
	if(glIsEnabled(GL_COLOR_ARRAY)) ZColorArray=1;
	else ZColorArray=0;
	if(glIsEnabled(GL_INDEX_ARRAY)) ZIndexArray=1;
	else ZIndexArray=0;
	if(glIsEnabled(GL_TEXTURE_COORD_ARRAY)) ZTextureCoordArray=1;
	else ZTextureCoordArray=0;
	if(glIsEnabled(GL_EDGE_FLAG_ARRAY)) ZEdgnFlagArray=1;
	else ZEdgnFlagArray=0;
	if(glIsEnabled(GL_POLYGON_OFFSET_POINT)) ZPolygonOffestPoint=1;
	else ZPolygonOffestPoint=0;
	if(glIsEnabled(GL_POLYGON_OFFSET_LINE)) ZPolygonOffestLine=1;
	else ZPolygonOffestLine=0;
	if(glIsEnabled(GL_POLYGON_OFFSET_FILL)) ZPolygonOffestFill=1;
	else ZPolygonOffestFill=0;
	if(glIsEnabled(GL_FOG_COORDINATE_ARRAY_EXT)) ZFogCoordinateArray=1;
	else ZFogCoordinateArray=0;
/*
	ZFog=0;
	ZLighting=0;
	ZTexture1d=0;
	ZTexture2d=0;
	ZLineStipple=0;
	ZPolygonStipple=0;
	ZCullFace=0;
	ZAlphaTest=0;
	ZBlend=0;
	ZIndexLogicOp=0;
	ZColorLogicOp=0;
	ZDither=0;
	ZStencilTest=0;
	ZDepthTest=0;
	ZClipPlane0=0;
	ZClipPlane1=0;
	ZClipPlane2=0;
	ZClipPlane3=0;
	ZClipPlane4=0;
	ZClipPlane5=0;
	ZLight0=0;	 
	ZLight1=0;	 
	ZLight2=0;	 
	ZLight3=0;	 
	ZLight4=0;	 
	ZLight5=0;	 
	ZLight6=0;	 
	ZLight7=0;	 
	ZTextureGenS=0;
	ZTextureGenT=0;
	ZTextureGenR=0;
	ZTextureGenQ=0;
	ZMap1Vertex3=0;
	ZMap1Vertex4=0;
	ZMap1Color4=0;
	ZMap1Index=0;
	ZMap1Normal=0;
	ZMap1TextureCoord1=0;
	ZMap1TextureCoord2=0;
	ZMap1TextureCoord3=0;
	ZMap1TextureCoord4=0;
	ZMap2Vertex3=0;
	ZMap2Vertex4=0;
	ZMap2Color4=0;
	ZMap2Index=0;
	ZMap2Normal=0;
	ZMap2TextureCoord1=0;
	ZMap2TextureCoord2=0;
	ZMap2TextureCoord3=0;
	ZMap2TextureCoord4=0;
	ZPointSmooth=0;
	ZLineSmooth=0;
	ZPolygonSmooth=0;
	ZScissorTest=0;
	ZColorMaterial=0;
	ZNormalize=0;
	ZAutoNormal=0;
	ZVertexArray=0;
	ZNormalArray=0;
	ZColorArray=0;
	ZIndexArray=0;
	ZTextureCoordArray=0;
	ZEdgnFlagArray=0;
	ZPolygonOffestPoint=0;
	ZPolygonOffestLine=0;
	ZPolygonOffestFill=0;
*/
}

ZOpenGL::~ZOpenGL(void)
{
}
void ZOpenGL::Refresh(void)
{
	glClearColor(ZClearColor[0],ZClearColor[1],ZClearColor[2],ZClearColor[3]);
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ZAmbient);
	//glHint
	glHint(GL_FOG_HINT, GL_NICEST);	
	glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);	
	glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);	
	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);	
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	
	//glEnable/glDisable
	if(ZLightModelTwoSide) glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, 1.0);
	else glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, 0.0); 
	if(ZLightModelLocalViewer) glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER, 1.0);
	else glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER, 0.0); 
	if(ZLightModelColorControl) glLightModelf(GL_LIGHT_MODEL_COLOR_CONTROL, GL_SEPARATE_SPECULAR_COLOR); 
	else glLightModelf(GL_LIGHT_MODEL_COLOR_CONTROL, GL_SINGLE_COLOR);
	if(ZShadeModel) glShadeModel(GL_SMOOTH);
	else glShadeModel(GL_FLAT);
	//Begin Enable
	if(ZFog) glEnable(GL_FOG);
	else glDisable(GL_FOG);
	if(ZLighting) glEnable(GL_LIGHTING);
	else glDisable(GL_LIGHTING);
	if(ZTexture1d) glEnable(GL_TEXTURE_1D);
	else glDisable(GL_TEXTURE_1D);
	if(ZTexture2d) glEnable(GL_TEXTURE_2D);
	else glDisable(GL_TEXTURE_2D);
	if(ZLineStipple) glEnable(GL_LINE_STIPPLE);
	else glDisable(GL_LINE_STIPPLE);
	if(ZPolygonStipple) glEnable(GL_POLYGON_STIPPLE);
	else glDisable(GL_POLYGON_STIPPLE);
	if(ZCullFace) glEnable(GL_CULL_FACE);
	else glDisable(GL_CULL_FACE);
	if(ZAlphaTest) glEnable(GL_ALPHA_TEST);
	else glDisable(GL_ALPHA_TEST);
	if(ZBlend) glEnable(GL_BLEND);
	else glDisable(GL_BLEND);
	if(ZIndexLogicOp) glEnable(GL_INDEX_LOGIC_OP);
	else glDisable(GL_INDEX_LOGIC_OP);
	if(ZColorLogicOp) glEnable(GL_INDEX_LOGIC_OP);
	else glDisable(GL_INDEX_LOGIC_OP);
	if(ZDither) glEnable(GL_DITHER);
	else glDisable(GL_DITHER);
	if(ZStencilTest) glEnable(GL_STENCIL_TEST);
	else glDisable(GL_STENCIL_TEST);
	if(ZDepthTest) glEnable(GL_DEPTH_TEST);
	else glDisable(GL_DEPTH_TEST);
	if(ZClipPlane0) glEnable(GL_CLIP_PLANE0);
	else glDisable(GL_CLIP_PLANE0);
	if(ZClipPlane1) glEnable(GL_CLIP_PLANE1);
	else glDisable(GL_CLIP_PLANE1);
	if(ZClipPlane2) glEnable(GL_CLIP_PLANE2);
	else glDisable(GL_CLIP_PLANE2);
	if(ZClipPlane3) glEnable(GL_CLIP_PLANE3);
	else glDisable(GL_CLIP_PLANE3);
	if(ZClipPlane4) glEnable(GL_CLIP_PLANE4);
	else glDisable(GL_CLIP_PLANE4);
	if(ZClipPlane5) glEnable(GL_CLIP_PLANE5);
	else glDisable(GL_CLIP_PLANE5);
	if(ZLight0) glEnable(GL_LIGHT0);
	else glDisable(GL_LIGHT0);
	if(ZLight1) glEnable(GL_LIGHT1);
	else glDisable(GL_LIGHT1);
	if(ZLight2) glEnable(GL_LIGHT2);
	else glDisable(GL_LIGHT2);
	if(ZLight3) glEnable(GL_LIGHT3);
	else glDisable(GL_LIGHT3);
	if(ZLight4) glEnable(GL_LIGHT4);
	else glDisable(GL_LIGHT4);
	if(ZLight5) glEnable(GL_LIGHT5);
	else glDisable(GL_LIGHT5);
	if(ZLight6) glEnable(GL_LIGHT6);
	else glDisable(GL_LIGHT6);
	if(ZLight7) glEnable(GL_LIGHT7);
	else glDisable(GL_LIGHT7);
	if(ZTextureGenS) glEnable(GL_TEXTURE_GEN_S);
	else glDisable(GL_TEXTURE_GEN_S);
	if(ZTextureGenT) glEnable(GL_TEXTURE_GEN_T);
	else glDisable(GL_TEXTURE_GEN_T);
	if(ZTextureGenR) glEnable(GL_TEXTURE_GEN_R);
	else glDisable(GL_TEXTURE_GEN_R);
	if(ZTextureGenQ) glEnable(GL_TEXTURE_GEN_Q);
	else glDisable(GL_TEXTURE_GEN_Q);
	if(ZMap1Vertex3) glEnable(GL_MAP1_VERTEX_3);
	else glDisable(GL_MAP1_VERTEX_3);
	if(ZMap1Vertex4) glEnable(GL_MAP1_VERTEX_4);
	else glDisable(GL_MAP1_VERTEX_4);
	if(ZMap1Color4) glEnable(GL_MAP1_COLOR_4);
	else glDisable(GL_MAP1_COLOR_4);
	if(ZMap1Index) glEnable(GL_MAP1_INDEX);
	else glDisable(GL_MAP1_INDEX);
	if(ZMap1Normal) glEnable(GL_MAP1_NORMAL);
	else glDisable(GL_MAP1_NORMAL);
	if(ZMap1TextureCoord1) glEnable(GL_MAP1_TEXTURE_COORD_1);
	else glDisable(GL_MAP1_TEXTURE_COORD_1);
	if(ZMap1TextureCoord2) glEnable(GL_MAP1_TEXTURE_COORD_2);
	else glDisable(GL_MAP1_TEXTURE_COORD_2);
	if(ZMap1TextureCoord3) glEnable(GL_MAP1_TEXTURE_COORD_3);
	else glDisable(GL_MAP1_TEXTURE_COORD_3);
	if(ZMap1TextureCoord4) glEnable(GL_MAP1_TEXTURE_COORD_4);
	else glDisable(GL_MAP1_TEXTURE_COORD_4);
	if(ZMap2Vertex3) glEnable(GL_MAP2_VERTEX_3);
	else glDisable(GL_MAP2_VERTEX_3);
	if(ZMap2Vertex4) glEnable(GL_MAP2_VERTEX_4);
	else glDisable(GL_MAP2_VERTEX_4);
	if(ZMap2Color4) glEnable(GL_MAP2_COLOR_4);
	else glDisable(GL_MAP2_COLOR_4);
	if(ZMap2Index) glEnable(GL_MAP2_INDEX);
	else glDisable(GL_MAP2_INDEX);
	if(ZMap2Normal) glEnable(GL_MAP2_NORMAL);
	else glDisable(GL_MAP2_NORMAL);
	if(ZMap2TextureCoord1) glEnable(GL_MAP2_TEXTURE_COORD_1);
	else glDisable(GL_MAP2_TEXTURE_COORD_1);
	if(ZMap2TextureCoord2) glEnable(GL_MAP2_TEXTURE_COORD_2);
	else glDisable(GL_MAP2_TEXTURE_COORD_2);
	if(ZMap2TextureCoord3) glEnable(GL_MAP2_TEXTURE_COORD_3);
	else glDisable(GL_MAP2_TEXTURE_COORD_3);
	if(ZMap2TextureCoord4) glEnable(GL_MAP2_TEXTURE_COORD_4);
	else glDisable(GL_MAP2_TEXTURE_COORD_4);
	if(ZPointSmooth) glEnable(GL_POINT_SMOOTH);
	else glDisable(GL_POINT_SMOOTH);
	if(ZLineSmooth) glEnable(GL_LINE_SMOOTH);
	else glDisable(GL_LINE_SMOOTH);
	if(ZPolygonSmooth) glEnable(GL_POLYGON_SMOOTH);
	else glDisable(GL_POLYGON_SMOOTH);
	if(ZScissorTest) glEnable(GL_SCISSOR_TEST);
	else glDisable(GL_SCISSOR_TEST);
	if(ZColorMaterial) glEnable(GL_COLOR_MATERIAL);
	else glDisable(GL_COLOR_MATERIAL);
	if(ZNormalize) glEnable(GL_NORMALIZE);
	else glDisable(GL_NORMALIZE);
	if(ZAutoNormal) glEnable(GL_AUTO_NORMAL);
	else glDisable(GL_AUTO_NORMAL);
	if(ZVertexArray) glEnable(GL_VERTEX_ARRAY);
	else glDisable(GL_VERTEX_ARRAY);
	if(ZNormalArray) glEnable(GL_NORMAL_ARRAY);
	else glDisable(GL_NORMAL_ARRAY);
	if(ZColorArray) glEnable(GL_COLOR_ARRAY);
	else glDisable(GL_COLOR_ARRAY);
	if(ZIndexArray) glEnable(GL_INDEX_ARRAY);
	else glDisable(GL_INDEX_ARRAY);
	if(ZTextureCoordArray) glEnable(GL_TEXTURE_COORD_ARRAY);
	else glDisable(GL_TEXTURE_COORD_ARRAY);
	if(ZEdgnFlagArray) glEnable(GL_EDGE_FLAG_ARRAY);
	else glDisable(GL_EDGE_FLAG_ARRAY);
	if(ZPolygonOffestPoint) glEnable(GL_POLYGON_OFFSET_POINT);
	else glDisable(GL_POLYGON_OFFSET_POINT);
	if(ZPolygonOffestLine) glEnable(GL_POLYGON_OFFSET_LINE);
	else glDisable(GL_POLYGON_OFFSET_LINE);
	if(ZPolygonOffestFill) glEnable(GL_POLYGON_OFFSET_FILL);
	else glDisable(GL_POLYGON_OFFSET_FILL);
	if(ZFogCoordinateArray) glEnableClientState(GL_FOG_COORDINATE_ARRAY_EXT);
	else glDisableClientState(GL_FOG_COORDINATE_ARRAY_EXT);
	//End Enable
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
void ZOpenGL::ZSetClearColor(GLclampf Red,GLclampf Green,GLclampf Blue,GLclampf Alpha)
{
	ZClearColor[0]=Red;	
	ZClearColor[1]=Green;
	ZClearColor[2]=Blue;
	ZClearColor[3]=Alpha;
	glClearColor(ZClearColor[0],ZClearColor[1],ZClearColor[2],ZClearColor[3]);
}
void ZOpenGL::ZSetClearColor(GLclampf *ClearColor)
{
	ZClearColor[0]=ClearColor[0];	
	ZClearColor[1]=ClearColor[1];
	ZClearColor[2]=ClearColor[2];
	ZClearColor[3]=ClearColor[3];
	glClearColor(ZClearColor[0],ZClearColor[1],ZClearColor[2],ZClearColor[3]);
}
void ZOpenGL::ZSetAmbientLight(GLfloat Red,GLfloat Green,GLfloat Blue, GLfloat Alpha)
{
	ZAmbient[0]=Red;
	ZAmbient[1]=Green;
	ZAmbient[2]=Blue;
	ZAmbient[3]=Alpha;
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT,ZAmbient);
}
void ZOpenGL::ZSetAmbientLight(GLfloat *Ambient)
{
	this->ZAmbient[0]=ZAmbient[0];
	this->ZAmbient[1]=ZAmbient[1];
	this->ZAmbient[2]=ZAmbient[2];
	this->ZAmbient[3]=ZAmbient[3];
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT,Ambient);
}

void ZOpenGL::ZSetLightModelTwoSide(bool T)
{
	ZLightModelTwoSide=T;
	if(T) glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, 1.0);
	else glLightModelf(GL_LIGHT_MODEL_TWO_SIDE, 0.0); 
}
void ZOpenGL::ZSetLightModelLocalViewer(bool T)
{
	ZLightModelLocalViewer=T;
	if(T) glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER, 1.0);
	else glLightModelf(GL_LIGHT_MODEL_LOCAL_VIEWER, 0.0); 
}
void ZOpenGL::ZSetLightModelColorControl(bool T)
{
	ZLightModelColorControl=T;
	if(ZLightModelColorControl) glLightModelf(GL_LIGHT_MODEL_COLOR_CONTROL, GL_SEPARATE_SPECULAR_COLOR); 
	else glLightModelf(GL_LIGHT_MODEL_COLOR_CONTROL, GL_SINGLE_COLOR);
}
void ZOpenGL::ZSetShadeModel(bool T)
{
	ZShadeModel=T;
	if(ZShadeModel) glShadeModel(GL_SMOOTH);
	else glShadeModel(GL_FLAT);
}
void ZOpenGL::ZSetFog(bool T)
{
	ZFog=T;
	if(T) glEnable(GL_FOG);
	else glDisable(GL_FOG);
}
void ZOpenGL::ZSetLighting(bool T)
{
	ZLighting=T;
	if(T) glEnable(GL_LIGHTING);
	else glDisable(GL_LIGHTING);
}
void ZOpenGL::ZSetTexture1d(bool T)
{
	ZTexture1d=T;
	if(T) glEnable(GL_TEXTURE_1D);
	else glDisable(GL_TEXTURE_1D);
}
void ZOpenGL::ZSetTexture2d(bool T)
{
	ZTexture2d=T;
	if(T) glEnable(GL_TEXTURE_2D);
	else glDisable(GL_TEXTURE_2D);
}
void ZOpenGL::ZSetLineStipple(bool T)
{
	ZLineStipple=T;
	if(T) glEnable(GL_LINE_STIPPLE);
	else glDisable(GL_LINE_STIPPLE);
}
void ZOpenGL::ZSetPolygonStipple(bool T)
{
	ZPolygonStipple=T;
	if(T) glEnable(GL_POLYGON_STIPPLE);
	else glDisable(GL_POLYGON_STIPPLE);
}
void ZOpenGL::ZSetCullFace(bool T)
{
	ZCullFace=T;
	if(T) glEnable(GL_CULL_FACE);
	else glDisable(GL_CULL_FACE);
}
void ZOpenGL::ZSetAlphaTest(bool T)
{
	ZAlphaTest=T;
	if(T) glEnable(GL_ALPHA_TEST);
	else glDisable(GL_ALPHA_TEST);
}
void ZOpenGL::ZSetBlend(bool T)
{
	ZBlend=T;
	if(T) glEnable(GL_BLEND);
	else glDisable(GL_BLEND);
}
void ZOpenGL::ZSetIndexLogicOp(bool T)
{
	ZIndexLogicOp=T;
	if(T) glEnable(GL_INDEX_LOGIC_OP);
	else glDisable(GL_INDEX_LOGIC_OP);
}	
void ZOpenGL::ZSetColorLogicOp(bool T)
{
	ZColorLogicOp=T;
	if(T) glEnable(GL_INDEX_LOGIC_OP);
	else glDisable(GL_INDEX_LOGIC_OP);
}
void ZOpenGL::ZSetDither(bool T)
{
	ZDither=T;
	if(T) glEnable(GL_DITHER);
	else glDisable(GL_DITHER);
}
void ZOpenGL::ZSetStencilTest(bool T)
{
	ZStencilTest=T;
	if(T) glEnable(GL_STENCIL_TEST);
	else glDisable(GL_STENCIL_TEST);
}
void ZOpenGL::ZSetDepthTest(bool T)
{
	ZDepthTest=T;
	if(T) glEnable(GL_DEPTH_TEST);
	else glDisable(GL_DEPTH_TEST);
}
void ZOpenGL::ZSetClipPlane0(bool T)
{
	ZClipPlane0=T;
	if(T) glEnable(GL_CLIP_PLANE0);
	else glDisable(GL_CLIP_PLANE0);
}
void ZOpenGL::ZSetClipPlane1(bool T)
{
	ZClipPlane1=T;
	if(T) glEnable(GL_CLIP_PLANE1);
	else glDisable(GL_CLIP_PLANE1);
}
void ZOpenGL::ZSetClipPlane2(bool T)
{
	ZClipPlane2=T;
	if(T) glEnable(GL_CLIP_PLANE2);
	else glDisable(GL_CLIP_PLANE2);
}
void ZOpenGL::ZSetClipPlane3(bool T)
{
	ZClipPlane3=T;
	if(T) glEnable(GL_CLIP_PLANE3);
	else glDisable(GL_CLIP_PLANE3);
}
void ZOpenGL::ZSetClipPlane4(bool T)
{
	ZClipPlane0=T;
	if(T) glEnable(GL_CLIP_PLANE4);
	else glDisable(GL_CLIP_PLANE4);
}
void ZOpenGL::ZSetClipPlane5(bool T)
{
	ZClipPlane5=T;
	if(T) glEnable(GL_CLIP_PLANE5);
	else glDisable(GL_CLIP_PLANE5);
}
void ZOpenGL::ZSetLight0(bool T)
{
	ZLight0=T;
	if(T) glEnable(GL_LIGHT0);
	else glDisable(GL_LIGHT0);
}
void ZOpenGL::ZSetLight1(bool T)
{
	ZLight1=T;
	if(T) glEnable(GL_LIGHT1);
	else glDisable(GL_LIGHT1);
}
void ZOpenGL::ZSetLight2(bool T)
{
	ZLight2=T;
	if(T) glEnable(GL_LIGHT2);
	else glDisable(GL_LIGHT2);
}
void ZOpenGL::ZSetLight3(bool T)
{
	ZLight3=T;
	if(T) glEnable(GL_LIGHT3);
	else glDisable(GL_LIGHT3);
}
void ZOpenGL::ZSetLight4(bool T)
{
	ZLight4=T;
	if(T) glEnable(GL_LIGHT4);
	else glDisable(GL_LIGHT4);
}
void ZOpenGL::ZSetLight5(bool T)
{
	ZLight5=T;
	if(T) glEnable(GL_LIGHT5);
	else glDisable(GL_LIGHT5);
}
void ZOpenGL::ZSetLight6(bool T)
{
	ZLight6=T;
	if(T) glEnable(GL_LIGHT6);
	else glDisable(GL_LIGHT6);
}
void ZOpenGL::ZSetLight7(bool T)
{
	ZLight7=T;
	if(T) glEnable(GL_LIGHT7);
	else glDisable(GL_LIGHT7);
}
void ZOpenGL::ZSetTextureGenS(bool T)
{
	ZTextureGenS=T;
	if(T) glEnable(GL_TEXTURE_GEN_S);
	else glDisable(GL_TEXTURE_GEN_S);
}
void ZOpenGL::ZSetTextureGenT(bool T)
{
	ZTextureGenT=T;
	if(T) glEnable(GL_TEXTURE_GEN_T);
	else glDisable(GL_TEXTURE_GEN_T);
}
void ZOpenGL::ZSetTextureGenR(bool T)
{
	ZTextureGenR=T;
	if(T) glEnable(GL_TEXTURE_GEN_R);
	else glDisable(GL_TEXTURE_GEN_R);
}
void ZOpenGL::ZSetTextureGenQ(bool T)
{
	ZTextureGenQ=T;
	if(T) glEnable(GL_TEXTURE_GEN_Q);
	else glDisable(GL_TEXTURE_GEN_Q);
}
void ZOpenGL::ZSetMap1Vertex3(bool T)
{
	ZMap1Vertex3=T;
	if(T) glEnable(GL_MAP1_VERTEX_3);
	else glDisable(GL_MAP1_VERTEX_3);
}
void ZOpenGL::ZSetMap1Vertex4(bool T)
{
	ZMap1Vertex4=T;
	if(T) glEnable(GL_MAP1_VERTEX_4);
	else glDisable(GL_MAP1_VERTEX_4);
}
void ZOpenGL::ZSetMap1Color4(bool T)
{
	ZMap1Color4=T;
	if(T) glEnable(GL_MAP1_COLOR_4);
	else glDisable(GL_MAP1_COLOR_4);
}
void ZOpenGL::ZSetMap1Index(bool T)
{
	ZMap1Index=T;
	if(T) glEnable(GL_MAP1_INDEX);
	else glDisable(GL_MAP1_INDEX);
}
void ZOpenGL::ZSetMap1Normal(bool T)
{
	ZMap1Normal=T;
	if(T) glEnable(GL_MAP1_NORMAL);
	else glDisable(GL_MAP1_NORMAL);
}
void ZOpenGL::ZSetZMap1TextureCoord1(bool T)
{
	ZMap1TextureCoord1=T;
	if(T) glEnable(GL_MAP1_TEXTURE_COORD_1);
	else glDisable(GL_MAP1_TEXTURE_COORD_1);
}
void ZOpenGL::ZSetZMap1TextureCoord2(bool T)
{	
	ZMap1TextureCoord2=T;
	if(T) glEnable(GL_MAP1_TEXTURE_COORD_2);
	else glDisable(GL_MAP1_TEXTURE_COORD_2);
}
void ZOpenGL::ZSetZMap1TextureCoord3(bool T)
{
	ZMap1TextureCoord3=T;
	if(T) glEnable(GL_MAP1_TEXTURE_COORD_3);
	else glDisable(GL_MAP1_TEXTURE_COORD_3);
}
void ZOpenGL::ZSetZMap1TextureCoord4(bool T)
{
	ZMap1TextureCoord4=T;
	if(T) glEnable(GL_MAP1_TEXTURE_COORD_4);
	else glDisable(GL_MAP1_TEXTURE_COORD_4);
}
void ZOpenGL::ZSetMap2Vertex3(bool T)
{
	ZMap2Vertex3=T;
	if(T) glEnable(GL_MAP2_VERTEX_3);
	else glDisable(GL_MAP2_VERTEX_3);
}
void ZOpenGL::ZSetMap2Vertex4(bool T)
{
	ZMap2Vertex4=T;
	if(T) glEnable(GL_MAP2_VERTEX_4);
	else glDisable(GL_MAP2_VERTEX_4);
}
void ZOpenGL::ZSetMap2Color4(bool T)
{
	ZMap2Color4=T;
	if(T) glEnable(GL_MAP2_COLOR_4);
	else glDisable(GL_MAP2_COLOR_4);
}
void ZOpenGL::ZSetMap2Index(bool T)
{
	ZMap2Index=T;
	if(T) glEnable(GL_MAP2_INDEX);
	else glDisable(GL_MAP2_INDEX);
}
void ZOpenGL::ZSetMap2Normal(bool T)
{
	ZMap2Normal=T;
	if(T) glEnable(GL_MAP2_NORMAL);
	else glDisable(GL_MAP2_NORMAL);
}
void ZOpenGL::ZSetZMap2TextureCoord1(bool T)
{
	ZMap2TextureCoord1=T;
	if(T) glEnable(GL_MAP2_TEXTURE_COORD_1);
	else glDisable(GL_MAP2_TEXTURE_COORD_1);
}
void ZOpenGL::ZSetZMap2TextureCoord2(bool T)
{
	ZMap2TextureCoord2=T;
	if(T) glEnable(GL_MAP2_TEXTURE_COORD_2);
	else glDisable(GL_MAP2_TEXTURE_COORD_2);
}
void ZOpenGL::ZSetZMap2TextureCoord3(bool T)
{
	ZMap2TextureCoord3=T;
	if(T) glEnable(GL_MAP2_TEXTURE_COORD_3);
	else glDisable(GL_MAP2_TEXTURE_COORD_3);
}
void ZOpenGL::ZSetZMap2TextureCoord4(bool T)
{
	ZMap2TextureCoord4=T;
	if(T) glEnable(GL_MAP2_TEXTURE_COORD_4);
	else glDisable(GL_MAP2_TEXTURE_COORD_4);
}
void ZOpenGL::ZSetPointSmooth(bool T)
{
	ZPointSmooth=T;
	if(T) glEnable(GL_POINT_SMOOTH);
	else glDisable(GL_POINT_SMOOTH);
}
void ZOpenGL::ZSetLineSmooth(bool T)
{
	ZLineSmooth=T;
	if(T) glEnable(GL_LINE_SMOOTH);
	else glDisable(GL_LINE_SMOOTH);
}

void ZOpenGL::ZSetPolygonSmooth(bool T)
{
	ZPolygonSmooth=T;
	if(T) glEnable(GL_POLYGON_SMOOTH);
	else glDisable(GL_POLYGON_SMOOTH);
}
void ZOpenGL::ZSetScissorTest(bool T)
{
	ZScissorTest=T;
	if(T) glEnable(GL_SCISSOR_TEST);
	else glDisable(GL_SCISSOR_TEST);
}
void ZOpenGL::ZSetColorMaterial(bool T)
{
	ZColorMaterial=T;
	if(T) glEnable(GL_COLOR_MATERIAL);
	else glDisable(GL_COLOR_MATERIAL);
}
void ZOpenGL::ZSetNormalize(bool T)
{
	ZNormalize=T;
	if(T) glEnable(GL_NORMALIZE);
	else glDisable(GL_NORMALIZE);
}
void ZOpenGL::ZSetAutoNormal(bool T)
{
	ZAutoNormal=T;
	if(T) glEnable(GL_AUTO_NORMAL);
	else glDisable(GL_AUTO_NORMAL);
}
void ZOpenGL::ZSetVertexArray(bool T)
{
	ZVertexArray=T;
	if(T) glEnable(GL_VERTEX_ARRAY);
	else glDisable(GL_VERTEX_ARRAY);
}
void ZOpenGL::ZSetNormalArray(bool T)
{
	ZNormalArray=T;
	if(T) glEnable(GL_NORMAL_ARRAY);
	else glDisable(GL_NORMAL_ARRAY);
}
void ZOpenGL::ZSetColorArray(bool T)
{
	ZColorArray=T;
	if(T) glEnable(GL_COLOR_ARRAY);
	else glDisable(GL_COLOR_ARRAY);
}
void ZOpenGL::ZSetIndexArray(bool T)
{
	ZIndexArray=T;
	if(T) glEnable(GL_INDEX_ARRAY);
	else glDisable(GL_INDEX_ARRAY);
}
void ZOpenGL::ZSetTextureArray(bool T)
{
	ZTextureCoordArray=T;
	if(T) glEnable(GL_TEXTURE_COORD_ARRAY);
	else glDisable(GL_TEXTURE_COORD_ARRAY);
}
void ZOpenGL::ZSetEdgnFlagArray(bool T)
{
	ZEdgnFlagArray=T;
	if(T) glEnable(GL_EDGE_FLAG_ARRAY);
	else glDisable(GL_EDGE_FLAG_ARRAY);
}
void ZOpenGL::ZSetPolygonOffestPoint(bool T)
{
	ZPolygonOffestPoint=T;
	if(T) glEnable(GL_POLYGON_OFFSET_POINT);
	else glDisable(GL_POLYGON_OFFSET_POINT);
}
void ZOpenGL::ZSetPolygonOffestLine(bool T)
{
	ZPolygonOffestLine=T;
	if(T) glEnable(GL_POLYGON_OFFSET_LINE);
	else glDisable(GL_POLYGON_OFFSET_LINE);
}
void ZOpenGL::ZSetPolygonOffestFill(bool T)
{
	ZPolygonOffestFill=T;
	if(T) glEnable(GL_POLYGON_OFFSET_FILL);
	else glDisable(GL_POLYGON_OFFSET_FILL);
}
void ZOpenGL::ZSetFogArray(bool T)
{
	ZFogCoordinateArray=T;
	if(T) glEnableClientState(GL_FOG_COORDINATE_ARRAY);
	else  glDisableClientState(GL_FOG_COORDINATE_ARRAY);
}