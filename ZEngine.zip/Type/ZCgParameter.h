#pragma once

#include <cg/cg.h>

struct ZCgParameter
{
	CGparameter Value;
	unsigned int Type;
};