#pragma once

#include <cg/cg.h>

struct ZCgLightParameter
{
	CGparameter Type;
	CGparameter Position;
	CGparameter Color;
	CGparameter KC;
	CGparameter KL;
	CGparameter KQ;
	CGparameter Direction;
	CGparameter CosInnerCone;
	CGparameter CosOuterCone;
};