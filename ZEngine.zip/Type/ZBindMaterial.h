#pragma once

#include <string>
#include <vector>
#include "ZConstant.h"
#include "ZMaterialCell.h"

struct ZBindMaterial
{
	std::vector<ZMaterialCell> Cell;
	unsigned int Id;								//indeks materia�u ustawiony w IsBind
	ZBindMaterial(void)
	{
		Id=0;
	}
	ZBindMaterial(const ZBindMaterial &Zen)
	{
		Cell=Zen.Cell; 
		Id=Zen.Id;
	}
	~ZBindMaterial(void)
	{
		Cell.clear();
		Id=0;
	} 
	bool IsBind(const char *FileName)
	{
		for(unsigned int i=0; i<(unsigned int)Cell.size(); i++)
		{
			if(!Cell[i].Name.compare(FileName))
			{
				Id=i;
				return 1;
			}
		}
		return 0;
	}
	void AddSize(const char *FileName)
	{
		Cell.push_back(ZMaterialCell());
		Id=(unsigned int)Cell.size()-1;
		Cell[(unsigned int)Cell.size()-1].Name=FileName;
	}
	void operator=(const ZBindMaterial& Zen)
	{
		Cell.clear();
		Id=Zen.Id;
		Cell=Zen.Cell;
	}
};