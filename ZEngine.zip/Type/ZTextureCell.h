#pragma once

#include <string>
#include "ZConstant.h"

struct ZTextureCell
{
	unsigned int TextureId;
	unsigned int ZType;
	unsigned int IsActive;
	std::string Name;
	ZTextureCell()
	{
		TextureId=0;
		IsActive=0;
		ZType=0;
	}
	ZTextureCell(const ZTextureCell &Zen)
	{
		TextureId=Zen.TextureId;
		ZType=Zen.ZType;
		IsActive=Zen.IsActive;
		Name=Zen.Name;
	}
	~ZTextureCell()
	{
	}
	void operator=(const ZTextureCell &Zen)
	{
		TextureId=Zen.TextureId;
		ZType=Zen.ZType;
		IsActive=Zen.IsActive;
		Name=Zen.Name;
	}
};