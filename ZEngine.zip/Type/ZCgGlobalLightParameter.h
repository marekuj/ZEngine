#pragma once

#include <cg/cg.h>

struct ZCgGlobalLightParameter
{
	CGparameter Ambient;
	CGparameter Size;
};