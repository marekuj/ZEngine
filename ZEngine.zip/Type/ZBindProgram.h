#pragma once

#include <vector>
#include "ZConstant.h"
#include "ZProgramCell.h"

struct ZBindProgram
{
	std::vector<ZProgramCell> Cell;
	unsigned int Id;								//indeks programu ustawionego w IsBind
	ZBindProgram()
	{	
		Id=0;
	}
	ZBindProgram(const ZBindProgram &Zen)
	{
		Cell=Zen.Cell; 
		Id=Zen.Id;
	}
	~ZBindProgram()
	{
		Cell.clear();
		Id=0;
	}
	bool IsBind(const char *FileName)
	{
		for(unsigned int i=0; i<(unsigned int)Cell.size(); i++)
		{
			if(!Cell[i].Name.compare(FileName))
			{
				Id=i;
				return 1;
			}
		}
		return 0;
	}
	void AddSize(const char *FileName)
	{
		Cell.push_back(ZProgramCell());
		Id=(unsigned int)Cell.size()-1;
		Cell[(unsigned int)Cell.size()-1].Name=FileName;
	}
	void operator=(const ZBindProgram& Zen)
	{
		Cell.clear();
		Id=Zen.Id;
		Cell=Zen.Cell;
	}
};