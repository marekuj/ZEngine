#pragma once

#include "ZConstant.h"
#include "../Math/Vector3D.h"

struct ZMaterial
{
	Vector3D Diffuse;
	Vector3D Specular;
	Vector3D Ambient;
	Vector3D Emission;
	float Shininess;
	ZMaterial(void)
	{
		Shininess=0;
	}
	ZMaterial(const ZMaterial &Zen)
	{
		Ambient=Zen.Ambient;
		Diffuse=Zen.Diffuse;
		Specular=Zen.Specular;
		Emission=Zen.Emission;
		Shininess=Zen.Shininess;
	}
	~ZMaterial(void)
	{
	}
	void operator=(const ZMaterial &Zen)
	{
		Ambient=Zen.Ambient;
		Diffuse=Zen.Diffuse;
		Specular=Zen.Specular;
		Emission=Zen.Emission;
		Shininess=Zen.Shininess;
	}
};