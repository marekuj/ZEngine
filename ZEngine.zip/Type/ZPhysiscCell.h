#pragma once

#include "ZConstant.h"
#include "../Math/Vector3D.h"

struct ZPhysiscCell
{	float Time;
	Vector3D VelocityC;			//pr�dko�� przed kolizj�
	Vector3D *BackPosition;		//po�orzenie rodzic�w

	float Radius;				//Promie� sfery ogranicze�	lub D z r�wnania  p�aszczyzny
	float Mass;					//masa obiektu
	float Friction;				//Wsp�czynnik tarcia
	Vector3D Gravitation;		//Grawitacja
	Vector3D Position;			//pozycja obiektu
	Vector3D Velocity;			//pr�dko�� lub normalna(A,B,C) z r�wnania p�aszczyzny
	Vector3D Acceleration;		//przy�pieszenie

	ZPhysiscCell(void)
	{
		BackPosition=0;
		Friction=0;
		Radius=0;
		Mass=0;
		Time=0;
	}
	ZPhysiscCell(const ZPhysiscCell &Zen)
	{Time=Zen.Time;
		VelocityC=Zen.VelocityC;
		BackPosition=Zen.BackPosition;

		Radius=Zen.Radius;
		Mass=Zen.Mass;
		Friction=Zen.Friction;
		Gravitation=Zen.Gravitation;
		Position=Zen.Position;
		Velocity=Zen.Velocity;
		Acceleration=Zen.Acceleration;
	}
	~ZPhysiscCell(void)
	{
	}
	void ZCalculatePosition(float &DeltaTime) 		//wyznacza poorzenie obiektu;
	{
		Time=DeltaTime;
		if(Velocity.GetLength()>0)
			Velocity = Velocity+((Acceleration+Gravitation+ZPhys::Z_GLOBAL_ACCELERATION-(Velocity*Friction))*DeltaTime); 
		else
			Velocity = Velocity+((Acceleration+Gravitation+ZPhys::Z_GLOBAL_ACCELERATION)*DeltaTime); 
		VelocityC = Velocity;
		Position  = Position+(Velocity*DeltaTime);
	}
	bool ZCheckCollision(ZPhysiscCell &Zen)					// by�a ->true | nie by�a ->false
	{
//		return ( Zen.Mass && ((Zen.Position-Position).GetLength()<=(Zen.Radius+Radius)) && (this!=&Zen) );
		return ( Zen.Mass && ((Zen.ZGetWorldPosition()-ZGetWorldPosition()).GetLength()<=(Zen.Radius+Radius)) && (this!=&Zen) );
	}
	void ZCollisionVelocity(ZPhysiscCell &Zen)
	{
		Position=Position-(VelocityC*(Time));
		Zen.Position=Zen.Position-(Zen.VelocityC*(Zen.Time));
		Velocity=(2*Zen.Mass*Zen.VelocityC + VelocityC*(Mass-Zen.Mass))/(Mass+Zen.Mass);
		Zen.Velocity=(2*Mass*VelocityC + Zen.VelocityC*(Mass-Zen.Mass))/(Mass+Zen.Mass);
	}
	bool ZCheckPlane(ZPhysiscCell &Zen)
	{
		return ( Zen.Mass && ((DotProduct(Velocity,(Zen.ZGetWorldPosition()-ZGetWorldPosition()))+Radius-Zen.Radius)<0) );//<=
	}
	void ZCollisionPlane(ZPhysiscCell &Zen)
	{
		//Wyznacza mowy vector predko�c
	//	if(Zen.Velocity.GetLength()>0)	
	//	{
//			Zen.Position  = Zen.Position+(-Zen.Velocity*Zen.Time);
			Zen.Velocity=Zen.Velocity.GetReflection(Velocity);
				//Zen.Velocity=Zen.VelocityC.GetReflection(Velocity);
			//Zen.Velocity = Zen.Velocity-(Zen.Velocity*0.15f);		//utrata energii
	//	}

		//Zapobiega przeniakniu obiektu za plaszczyzn�
		Zen.Position-=((Zen.ZGetWorldPosition()-ZGetWorldPosition())-RayIntersection(Zen));
	}
	float ZDistancePlane(ZPhysiscCell &Zen)
	{
		//Zwraca odleg�o�� punktu od p�aszczyzny
		return DotProduct(Velocity,(Zen.ZGetWorldPosition()-ZGetWorldPosition()))+Radius-Zen.Radius;
	}
	float ZPointPlane(ZPhysiscCell &Zen)
	{
		//Sprawdza czy opiekt nale�y do p�aszczyzny
		return (DotProduct(Velocity,(Zen.ZGetWorldPosition()-ZGetWorldPosition()))+Radius-Zen.Radius) == 0;
	}
	Vector3D RayIntersection(ZPhysiscCell &Zen)		//zwraca pozycj�(na p�aszczy�nie) zderzenia obiektu z p�aszczyaz� 
	{														//Je�eli chcemy wkrywa� kolizje to przekazujemy wynik do funkcji
		//Vector3D RayPos=Zen.ZGetWorldPosition()-ZGetWorldPosition();
		//Vector3D RayDir=Zen.Velocity;
		const float Bufor=DotProduct(Velocity,Zen.Velocity);
		if(!Bufor)
			//return RayPos;
			return Zen.ZGetWorldPosition()-ZGetWorldPosition();
		//return RayPos-RayDir*(ZDistancePlane(Zen)/Bufor);
		return (Zen.ZGetWorldPosition()-ZGetWorldPosition())
				-Zen.Velocity*(ZDistancePlane(Zen)/Bufor);
	}
	Vector3D ZGetWorldPosition(void)
	{
		return (*BackPosition)+Position;
	}
	void operator=(const ZPhysiscCell& Zen)
	{Time=Zen.Time;
		VelocityC=Zen.VelocityC;
		BackPosition=Zen.BackPosition;

		Radius=Zen.Radius;
		Mass=Zen.Mass;
		Gravitation=Zen.Gravitation;
		Position=Zen.Position;
		Velocity=Zen.Velocity;
		Acceleration=Zen.Acceleration;
	}
};