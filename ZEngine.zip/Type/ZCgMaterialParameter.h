#pragma once

#include <cg/cg.h>

struct ZCgMaterialParameter
{
	CGparameter Ambient;
	CGparameter Diffuse;
	CGparameter Specular;
	CGparameter Emission;
	CGparameter Shininess;
};