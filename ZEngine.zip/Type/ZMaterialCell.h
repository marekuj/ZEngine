#pragma once

#include <string>
#include "ZConstant.h"
#include "ZMaterial.h"

struct ZMaterialCell : public ZMaterial
{
	std::string Name;
	ZMaterialCell(void)
	{
		Shininess=0;
	}
	ZMaterialCell(const ZMaterialCell &Zen)
	{
		Ambient=Zen.Ambient;
		Diffuse=Zen.Diffuse;
		Specular=Zen.Specular;
		Emission=Zen.Emission;
		Shininess=Zen.Shininess;
		Name=Zen.Name;
	}
	~ZMaterialCell(void)
	{
	}
	//inline ZMaterial* ToVoidMaterial()
	//{
	//	//return (ZMaterial*)this;
	//	return this;
	//}
	//inline ZMaterial ToMaterial()
	//{
	//	//return *(ZMaterial*)this;
	//	return *this;
	//}
	void operator=(const ZMaterialCell& Zen)
	{
		Ambient=Zen.Ambient;
		Diffuse=Zen.Diffuse;
		Specular=Zen.Specular;
		Emission=Zen.Emission;
		Shininess=Zen.Shininess;
		Name=Zen.Name;
	}
	void operator=(const ZMaterial& Zen)
	{
		Ambient=Zen.Ambient;
		Diffuse=Zen.Diffuse;
		Specular=Zen.Specular;
		Emission=Zen.Emission;
		Shininess=Zen.Shininess;
	}
};