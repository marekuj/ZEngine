#pragma once

#include <cg/cg.h>

struct ZLoadCgParameter
{
	std::string Name;
	unsigned int Type;
};