#pragma once

#include <string>
#include <vector>
#include "ZConstant.h"
#include "ZCgMaterialParameter.h"
#include "ZCgGlobalLightParameter.h"
#include "ZCgLightParameter.h"
#include "ZCgParameter.h"
#include "ZLoadCgParameter.h"
#include "ZProgram.h"

struct ZProgramCell
{
	CGprogram ProgramId;
	CGprofile Profile;
	std::vector<ZCgParameter> Parameter;
	std::vector<ZCgLightParameter> LightParameter;
	std::vector<ZCgMaterialParameter> MaterialParameter;
	ZCgGlobalLightParameter GlobalLightParameter;
	std::string LightNameParameter;
	std::string Name;
	ZProgramCell(void)
	{
	}
	ZProgramCell(const ZProgramCell &Zen)
	{
		ProgramId=Zen.ProgramId;
		Profile=Zen.Profile;		
		//Copy Parameter/TypeParameter
		Parameter=Zen.Parameter;
		//Copy LightParameter
		LightParameter=Zen.LightParameter;
		//Copy MaterialParameter
		MaterialParameter=Zen.MaterialParameter;
		//Copy LightNameParameter
		LightNameParameter=Zen.LightNameParameter;
		//Copy FileName
		Name=Zen.Name;
		//Copy GlobalLightParameter
		GlobalLightParameter=Zen.GlobalLightParameter;
	}
	~ZProgramCell(void)
	{
		Parameter.clear();
		LightParameter.clear();
		MaterialParameter.clear();
	}
	void AddParameter(unsigned int AddSize)
	{
		Parameter.resize(Parameter.size()+AddSize);
	}
	void AddLightParameter(unsigned int AddSize)
	{
		LightParameter.resize(LightParameter.size()+AddSize);
	}
	void AddMaterialParameter(unsigned int AddSize)
	{
		MaterialParameter.resize(MaterialParameter.size()+AddSize);
	}
	void operator=(const ZProgramCell& Zen)
	{
		ProgramId=Zen.ProgramId;
		Profile=Zen.Profile;		
		//Copy Parameter/TypeParameter
		Parameter.clear();
		Parameter=Zen.Parameter;
		//Copy LightParameter
		LightParameter.clear();
		LightParameter=Zen.LightParameter;
		//Copy MaterialParameter
		MaterialParameter.clear();
		MaterialParameter=Zen.MaterialParameter;
		//Copy LightNameParameter
		LightNameParameter=Zen.LightNameParameter;
		//Copy FileName
		Name=Zen.Name;
		//Copy GlobalLightParameter
		GlobalLightParameter=Zen.GlobalLightParameter;
	}
};