#pragma once

#include "ZConstant.h"
#include "../Tree/ZTree.h"
#include "../Math/Vector3D.h"

struct ZLight		//zmieni� nazwe na 'ZLight' 
{
	bool Enable;
	ZTree *Creator;
	float Type;
	Vector3D Position;
	Vector3D Color;
	float KC;
	float KL;
	float KQ;
	Vector3D Direction;
	float CosInnerCone;
	float CosOuterCone;
	ZLight(void)
	{
		Enable=0;
		Creator=0;
		Type=0;
		KC=0;
		KL=0;
		KQ=0;
		CosInnerCone=0;
		CosOuterCone=0;
	}
	ZLight(const ZLight &Zen)
	{
		Enable=Zen.Enable;
		Creator=Zen.Creator;
		Type=Zen.Type;
		Position=Zen.Position;
		Color=Zen.Color;
		KC=Zen.KC;
		KL=Zen.KL;
		KQ=Zen.KQ;
		Direction=Zen.Direction;
		CosInnerCone=Zen.CosInnerCone;
		CosOuterCone=Zen.CosOuterCone;
	}
	~ZLight(void)
	{
		Enable=0;
		Creator=0;
		Type=0;
		KC=0;
		KL=0;
		KQ=0;
		CosInnerCone=0;
		CosOuterCone=0;
	}
	void operator=(const ZLight& Zen)
	{
		Enable=Zen.Enable;
		Creator=Zen.Creator;
		Type=Zen.Type;
		Position=Zen.Position;
		Color=Zen.Color;
		KC=Zen.KC;
		KL=Zen.KL;
		KQ=Zen.KQ;
		Direction=Zen.Direction;
		CosInnerCone=Zen.CosInnerCone;
		CosOuterCone=Zen.CosOuterCone;
	}
};