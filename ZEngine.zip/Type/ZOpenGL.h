#pragma once
#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")

class ZOpenGL
{
private:
	bool ZFog;
	bool ZLighting;
	bool ZTexture1d;
	bool ZTexture2d;
	bool ZLineStipple;
	bool ZPolygonStipple;
	bool ZCullFace;
	bool ZAlphaTest;
	bool ZBlend;
	bool ZIndexLogicOp;
	bool ZColorLogicOp;
	bool ZDither;
	bool ZStencilTest;
	bool ZDepthTest;
	bool ZClipPlane0;
	bool ZClipPlane1;
	bool ZClipPlane2;
	bool ZClipPlane3;
	bool ZClipPlane4;
	bool ZClipPlane5;
	bool ZLight0;	 
	bool ZLight1;	 
	bool ZLight2;	 
	bool ZLight3;	 
	bool ZLight4;	 
	bool ZLight5;	 
	bool ZLight6;	 
	bool ZLight7;	
	bool ZTextureGenS;
	bool ZTextureGenT;
	bool ZTextureGenR;
	bool ZTextureGenQ;
	bool ZMap1Vertex3;
	bool ZMap1Vertex4;
	bool ZMap1Color4;
	bool ZMap1Index;
	bool ZMap1Normal;
	bool ZMap1TextureCoord1;
	bool ZMap1TextureCoord2;
	bool ZMap1TextureCoord3;
	bool ZMap1TextureCoord4;
	bool ZMap2Vertex3;
	bool ZMap2Vertex4;
	bool ZMap2Color4;
	bool ZMap2Index;
	bool ZMap2Normal;
	bool ZMap2TextureCoord1;
	bool ZMap2TextureCoord2;
	bool ZMap2TextureCoord3;
	bool ZMap2TextureCoord4;
	bool ZPointSmooth;
	bool ZLineSmooth;
	bool ZPolygonSmooth;
	bool ZScissorTest;
	bool ZColorMaterial;
	bool ZNormalize;
	bool ZAutoNormal;
	bool ZVertexArray;
	bool ZNormalArray;
	bool ZColorArray;
	bool ZIndexArray;
	bool ZTextureCoordArray;
	bool ZEdgnFlagArray;
	bool ZPolygonOffestPoint;
	bool ZPolygonOffestLine;
	bool ZPolygonOffestFill;

	bool ZLightModelTwoSide;
	bool ZLightModelLocalViewer;
	bool ZLightModelColorControl;
	bool ZFogCoordinateArray;
	bool ZShadeModel;

	GLclampf ZClearColor[4];
	GLfloat ZAmbient[4];						//domy�lne swiatlo otaczajace

protected:
public:
	ZOpenGL(void);            
	virtual ~ZOpenGL(void);
	
	void Refresh(void);

	void ZSetClearColor(GLclampf Red=0,GLclampf Green=0,GLclampf Blue=0,GLclampf Alpha=1);
	void ZSetClearColor(GLclampf *ClearColor);
	void ZSetAmbientLight(GLfloat Red,GLfloat Green,GLfloat Blue, GLfloat Alpha);	//domy�lne swiatlo otaczajace
	void ZSetAmbientLight(GLfloat *Ambient);										//domy�lne swiatlo otaczajace
	void ZSetLightModelTwoSide(bool T=1);
	void ZSetLightModelLocalViewer(bool T=1);
	void ZSetLightModelColorControl(bool T=1);

	void ZSetShadeModel(bool T=1);	//T=0 -> GL_FLAT, T=1 -> GL_GL_SMOOTH;

	//Begin Enable/Disable
	void ZSetFog(bool T=1);
	void ZSetLighting(bool T=1);
	void ZSetTexture1d(bool T=1);
	void ZSetTexture2d(bool T=1);
	void ZSetLineStipple(bool T=1);
	void ZSetPolygonStipple(bool T=1);
	void ZSetCullFace(bool T=1);
	void ZSetAlphaTest(bool T=1);
	void ZSetBlend(bool T=1);
	void ZSetIndexLogicOp(bool T=1);
	void ZSetColorLogicOp(bool T=1);
	void ZSetDither(bool T=1);
	void ZSetStencilTest(bool T=1);
	void ZSetDepthTest(bool T=1);
	void ZSetClipPlane0(bool T=1);
	void ZSetClipPlane1(bool T=1);
	void ZSetClipPlane2(bool T=1);
	void ZSetClipPlane3(bool T=1);
	void ZSetClipPlane4(bool T=1);
	void ZSetClipPlane5(bool T=1);
	void ZSetLight0(bool T=1);
	void ZSetLight1(bool T=1);
	void ZSetLight2(bool T=1);
	void ZSetLight3(bool T=1);
	void ZSetLight4(bool T=1);
	void ZSetLight5(bool T=1);
	void ZSetLight6(bool T=1);
	void ZSetLight7(bool T=1);
	void ZSetTextureGenS(bool T=1);
	void ZSetTextureGenT(bool T=1);
	void ZSetTextureGenR(bool T=1);
	void ZSetTextureGenQ(bool T=1);
	void ZSetMap1Vertex3(bool T=1);
	void ZSetMap1Vertex4(bool T=1);
	void ZSetMap1Color4(bool T=1);
	void ZSetMap1Index(bool T=1);
	void ZSetMap1Normal(bool T=1);
	void ZSetZMap1TextureCoord1(bool T=1);
	void ZSetZMap1TextureCoord2(bool T=1);
	void ZSetZMap1TextureCoord3(bool T=1);
	void ZSetZMap1TextureCoord4(bool T=1);
	void ZSetMap2Vertex3(bool T=1);
	void ZSetMap2Vertex4(bool T=1);
	void ZSetMap2Color4(bool T=1);
	void ZSetMap2Index(bool T=1);
	void ZSetMap2Normal(bool T=1);
	void ZSetZMap2TextureCoord1(bool T=1);
	void ZSetZMap2TextureCoord2(bool T=1);
	void ZSetZMap2TextureCoord3(bool T=1);
	void ZSetZMap2TextureCoord4(bool T=1);
	void ZSetPointSmooth(bool T=1);
	void ZSetLineSmooth(bool T=1);
	void ZSetPolygonSmooth(bool T=1);
	void ZSetScissorTest(bool T=1);
	void ZSetColorMaterial(bool T=1);
	void ZSetNormalize(bool T=1);
	void ZSetAutoNormal(bool T=1);
	void ZSetVertexArray(bool T=1);
	void ZSetNormalArray(bool T=1);
	void ZSetColorArray(bool T=1);
	void ZSetIndexArray(bool T=1);
	void ZSetTextureArray(bool T=1);
	void ZSetEdgnFlagArray(bool T=1);
	void ZSetPolygonOffestPoint(bool T=1);
	void ZSetPolygonOffestLine(bool T=1);
	void ZSetPolygonOffestFill(bool T=1);
	void ZSetFogArray(bool T=1);
	//i tak dalej;
	//end Enable/Disable
};