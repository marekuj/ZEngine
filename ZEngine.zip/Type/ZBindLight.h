#pragma once

#include <string>
#include <vector>
#include "ZConstant.h"
#include "ZLightCell.h"

struct ZBindLight
{
	ZGlobalLight GlobalLight;
	std::vector<ZLightCell> Cell;
	unsigned int Id;
	ZBindLight(void)
	{
		GlobalLight.Size=0;
		Id=0;
	}
	ZBindLight(const ZBindLight &Zen)
	{
		GlobalLight=Zen.GlobalLight;
		Cell=Zen.Cell; 
		Id=Zen.Id;
	}
	~ZBindLight(void)
	{
		Cell.clear();
		Id=0;
		GlobalLight.Size=0;
	}
	bool IsFree()
	{
		for(unsigned int i=0; i<(unsigned int)Cell.size(); i++)
		{
			if(Cell[i].Creator==0 && Cell[i].Enable==0)
			{
				Id=i;
				return 1;
			}
		}
		return 0;
	}
	void AddSize()
	{
		if(!IsFree())
		{
			Cell.push_back(ZLightCell());
			Id=(unsigned int)Cell.size()-1;
		}
	}
	void operator=(const ZBindLight& Zen)
	{
		GlobalLight=Zen.GlobalLight;
		Cell.clear();
		Id=Zen.Id;
		Cell=Zen.Cell;
	}
};