#pragma once

#include <vector>
#include "ZConstant.h"
#include "../Tree/ZTree.h"

struct ZCursor
{
	std::vector<unsigned int> Id;
	ZTree *Creator;
	ZCursor(void)
	{
		Creator=0;
	}
	ZCursor(const ZCursor &Zen)
	{
		Id=Zen.Id; 
		Creator=Zen.Creator;
	}
	~ZCursor(void)
	{
		Id.clear();
		Creator=0;
	}
	inline void AddSize(void)
	{
		unsigned int Bufor=0; 
		Id.push_back(Bufor);
	}
	inline void operator=(const ZCursor& Zen)
	{
		Creator=Zen.Creator;
		Id.clear();
		Id=Zen.Id;
	}
};