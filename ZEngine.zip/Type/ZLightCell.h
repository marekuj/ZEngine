#pragma once

#include "ZConstant.h"
#include "ZLight.h"

struct ZLightCell : public ZLight
{
	ZLightCell(void):ZLight()
	{
	}
	ZLightCell(const ZLight &Zen):ZLight(Zen)
	{
	}
	~ZLightCell(void)
	{
		ZLight::~ZLight();
	}
	void operator=(const ZLightCell& Zen)
	{
		Enable=Zen.Enable;
		Type=Zen.Type;
		Creator=Zen.Creator;
		Position=Zen.Position;
		Color=Zen.Color;
		KC=Zen.KC;
		KL=Zen.KL;
		KQ=Zen.KQ;
		Direction=Zen.Direction;
		CosInnerCone=Zen.CosInnerCone;
		CosOuterCone=Zen.CosOuterCone;
	}
};