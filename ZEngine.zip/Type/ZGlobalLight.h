#pragma once

#include "ZConstant.h"
#include "../Math/Vector3D.h"

struct ZGlobalLight
{
	Vector3D Ambient;		//�wiat�o otoczenia globalne
	int Size;				//ilo�� �wiate�
};
