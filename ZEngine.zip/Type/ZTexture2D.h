#pragma once

#include <memory.h>
#include "ZConstant.h"

struct ZTexture2D
{
	long SizeWidth;
	long SizeHeight;
	unsigned long SizeImage;
	unsigned char *ImageDate;
	int Components;
	unsigned int Format;
	unsigned int Type;
	unsigned int ZType;
	ZTexture2D(void)
	{
		SizeWidth=0;
		SizeHeight=0;
		SizeImage=0;
		ImageDate=0;
		Components=0;
		Format=0;
		Type=0;
		ZType=0;
	}
	ZTexture2D(const ZTexture2D &Zen)
	{
		SizeWidth=Zen.SizeWidth;
		SizeHeight=Zen.SizeHeight;
		SizeImage=Zen.SizeImage;
		Components=Zen.Components;
		Format=Zen.Format;
		Type=Zen.Type;
		ZType=Zen.ZType;
		ZCreateImageDate(SizeImage);
		memcpy(ImageDate,Zen.ImageDate,SizeImage*sizeof(unsigned char));
	}
	~ZTexture2D(void)
	{
		if(ImageDate) delete[] ImageDate;
		ImageDate=0;
	}
	void ZCreateImageDate(unsigned long Size)
	{
		SizeImage=Size;
		if(ImageDate) delete[] ImageDate;
		ImageDate=0;
		ImageDate = new unsigned char[Size]; 
		memset(ImageDate, 0, Size*sizeof(unsigned char));
	}
	void operator=(const ZTexture2D &Zen)
	{
		SizeWidth=Zen.SizeWidth;
		SizeHeight=Zen.SizeHeight;
		SizeImage=Zen.SizeImage;
		Components=Zen.Components;
		Format=Zen.Format;
		Type=Zen.Type;
		ZType=Zen.ZType;
		ZCreateImageDate(SizeImage);
		memcpy(ImageDate,Zen.ImageDate,SizeImage*sizeof(unsigned char));
	}
};