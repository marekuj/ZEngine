#include "ZOutlineFonts.h"

ZOutlineFonts::ZOutlineFonts(ZTree *Parent):ZTree(Parent)
{
	ComponentName = "ZOutlineFonts";

	text[0]='O'; text[1]='u'; text[2]='t'; text[3]='l'; text[4]='i'; text[5]='n'; text[6]='e';
	text[7]='F'; text[8]='o'; text[9]='n'; text[10]='t'; text[11]='s'; text[12]='\0';
	ap=0;			
	length=0;
	Color[0]=1;	Color[1]=1;	Color[2]=1;	Color[3]=1;
	hDC=0;
	Height=-12;					
	Width=0;	
	Escapement=0;		        
	Orientation=0;		 
	Weight=FW_BOLD;
	Italic=0;
	Underline=0;
	StrikeOut=0;
	CharSet=ANSI_CHARSET;
	OutputPrecision=OUT_TT_PRECIS;
	ClipPrecision=CLIP_DEFAULT_PRECIS;
	Quality=ANTIALIASED_QUALITY;
	PitchAndFamily=FF_DONTCARE|DEFAULT_PITCH;
	lpszFace="Courier New";

	deviation=0.0f;	
	extrusion=0.2f;
	format=WGL_FONT_POLYGONS;

	for (unsigned int loop=0;loop<(strlen(text));loop++)	// Loop To Find Text Length
	{
		length+=gmf[text[loop]].gmfCellIncX;				// Increase Length By Each Characters Width
	}
}

ZOutlineFonts::~ZOutlineFonts(void)
{
	glDeleteLists(base, 256);
}
void ZOutlineFonts::ZSetHDC(HDC hDC)
{
	base = glGenLists(256);								// Storage For 256 Characters
	this->hDC=hDC;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
			CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);							// Selects The Font We Created
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetPrintText(const char *fmt, ...)				
{
	if (fmt == NULL)									// If There's No Text
		return;											// Do Nothing

	va_start(ap, fmt);									// Parses The String For Variables
	    vsprintf(text, fmt, ap);						// And Converts Symbols To Actual Numbers
	va_end(ap);	

	length=0;
	for (unsigned int loop=0;loop<(strlen(text));loop++)	// Loop To Find Text Length
	{
		length+=gmf[text[loop]].gmfCellIncX;				// Increase Length By Each Characters Width
	}
}
void ZOutlineFonts::ZDraw()
{
	glPushMatrix();
		glTranslatef(-length/2,0.0f,0.0f);					// Center Our Text On The Screen
		glColor4fv(Color);
		glPushAttrib(GL_LIST_BIT);							// Pushes The Display List Bits
		glListBase(base);									// Sets The Base Character to 0
		glCallLists((GLsizei)strlen(text), GL_UNSIGNED_BYTE, text);	// Draws The Display List Text
		glPopAttrib();										// Pops The Display List Bits
	glPopMatrix();
}
void ZOutlineFonts::ZSetColor(GLfloat Red,GLfloat Green,GLfloat Blue, GLfloat Alpha)
{
	Color[0]=Red;
	Color[1]=Green;
	Color[2]=Blue;
	Color[3]=Alpha;
}
void ZOutlineFonts::ZSetColor(GLfloat *Color)
{
	this->Color[0]=Color[0];
	this->Color[1]=Color[1];
	this->Color[2]=Color[2];
	this->Color[3]=Color[3];
}

void ZOutlineFonts::ZSetHeight(int Height)
{
	this->Height=Height;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetWidth(int Width)
{
	this->Width=Width;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetEscapement(int Escapement)
{
	this->Escapement=Escapement;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetOrientation(int Orientation)
{
	this->Orientation=Orientation;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetWeight(int Weight)
{
	this->Weight=Weight;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetItalic(DWORD Italic)
{
	this->Italic=Italic;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetUnderline(DWORD Underline)
{
	this->Underline=Underline;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetStrikeOut(DWORD StrikeOut)
{
	this->StrikeOut=StrikeOut;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetCharSet(DWORD CharSet)
{
	this->CharSet=CharSet;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetOutputPrecision(DWORD OutputPrecision)
{
	this->OutputPrecision=OutputPrecision; 
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetClipPrecision(DWORD ClipPrecision)
{
	this->ClipPrecision=ClipPrecision;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetQuality(DWORD Quality)
{
	this->Quality=Quality;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetPitchAndFamily(DWORD PitchAndFamily)
{
	this->PitchAndFamily=PitchAndFamily;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetFontFace(LPCTSTR lpszFace)
{
	this->lpszFace=lpszFace;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
		CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	SelectObject(hDC, font);
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
	DeleteObject(font);	
}
void ZOutlineFonts::ZSetDeviation(FLOAT  deviation)
{
	this->deviation=deviation;
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
}
void ZOutlineFonts::ZSetExtrusion(FLOAT  extrusion)
{
	this->extrusion=extrusion;
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
}
void ZOutlineFonts::ZSetFormat(int  format)
{
	this->format=format;
	wglUseFontOutlines(	hDC,0,255,base,deviation,extrusion,format,gmf);
}
