#include "ZBitmapFonts.h"

ZBitmapFonts::ZBitmapFonts(ZTree *Parent):ZObject(Parent)
{
	ComponentName="ZBitmapFonts";
	x=0;
	y=0;
	text[0]='B'; text[1]='i'; text[2]='t'; text[3]='m'; text[4]='a'; text[5]='p';
	text[6]='F'; text[7]='o'; text[8]='n'; text[9]='t'; text[10]='s'; text[11]='\0';
	ap=0;			
	Color[0]=1;	Color[1]=1;	Color[2]=1;	Color[3]=1;
	hDC=0;
	Height=-20;					
	Width=0;	
	Escapement=0;		        
	Orientation=0;		 
	Weight=FW_BOLD;
	Italic=0;
	Underline=0;
	StrikeOut=0;
	CharSet=ANSI_CHARSET;
	OutputPrecision=OUT_TT_PRECIS;
	ClipPrecision=CLIP_DEFAULT_PRECIS;
	Quality=ANTIALIASED_QUALITY;
	PitchAndFamily=FF_DONTCARE|DEFAULT_PITCH;
	lpszFace="Courier New";
	//lpszFace="Comic Sans MS";
}
ZBitmapFonts::~ZBitmapFonts(void)
{
	glDeleteLists(base, 96);
}
void ZBitmapFonts::ZDraw()
{
	glColor4fv(Color);
	glRasterPos2f(x,y);
	
	glPushAttrib(GL_LIST_BIT);							// Pushes The Display List Bits
	glListBase(base - 32);								// Sets The Base Character to 32
	glCallLists((GLsizei)strlen(text), GL_UNSIGNED_BYTE, text);	// Draws The Display List Text
	glPopAttrib();										// Pops The Display List Bits
}
void ZBitmapFonts::ZSetHDC(HDC hDC)
{
	base = glGenLists(96);
	this->hDC=hDC;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font);           // Selects The Font We Want
	wglUseFontBitmaps(hDC, 32, 96, base);				// Builds 96 Characters Starting At Character 32
	SelectObject(hDC, oldfont);							// Selects The Font We Want
	DeleteObject(font);									// Delete The Font
	DeleteObject(oldfont);								// Delete The Font
}
void ZBitmapFonts::ZSetPrintText(const char *fmt, ...)
{
	if (fmt == NULL)									// If There's No Text
		return;											// Do Nothing

	va_start(ap, fmt);									// Parses The String For Variables
	    vsprintf(text, fmt, ap);						// And Converts Symbols To Actual Numbers
	va_end(ap);											// Results Are Stored In Text
}
void ZBitmapFonts::ZSetColor(GLfloat Red,GLfloat Green,GLfloat Blue, GLfloat Alpha)
{
	Color[0]=Red;
	Color[1]=Green;
	Color[2]=Blue;
	Color[3]=Alpha;
}
void ZBitmapFonts::ZSetColor(GLfloat *Color)
{
	this->Color[0]=Color[0];
	this->Color[1]=Color[1];
	this->Color[2]=Color[2];
	this->Color[3]=Color[3];
}
void ZBitmapFonts::ZSetFontPos(GLfloat x,GLfloat y)
{
	this->x=x;
	this->y=y;
}
void ZBitmapFonts::ZSetHeight(int Height)
{
	this->Height=Height;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetWidth(int Width)
{
	this->Width=Width;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetEscapement(int Escapement)
{
	this->Escapement=Escapement;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetOrientation(int Orientation)
{
	this->Orientation=Orientation;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetWeight(int Weight)
{
	this->Weight=Weight;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetItalic(DWORD Italic)
{
	this->Italic=Italic;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetUnderline(DWORD Underline)
{
	this->Underline=Underline;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetStrikeOut(DWORD StrikeOut)
{
	this->StrikeOut=StrikeOut;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetCharSet(DWORD CharSet)
{
	this->CharSet=CharSet;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetOutputPrecision(DWORD OutputPrecision)
{
	this->OutputPrecision=OutputPrecision; 
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetClipPrecision(DWORD ClipPrecision)
{
	this->ClipPrecision=ClipPrecision;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetQuality(DWORD Quality)
{
	this->Quality=Quality;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetPitchAndFamily(DWORD PitchAndFamily)
{
	this->PitchAndFamily=PitchAndFamily;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
void ZBitmapFonts::ZSetFontFace(LPCTSTR lpszFace)
{
	this->lpszFace=lpszFace;
	font = CreateFont(Height,Width,Escapement,Orientation,Weight,Italic,Underline,StrikeOut,
				CharSet,OutputPrecision,ClipPrecision,Quality,PitchAndFamily,lpszFace);
	oldfont = (HFONT)SelectObject(hDC, font); 
	wglUseFontBitmaps(hDC, 32, 96, base);	
	DeleteObject(font);						
	DeleteObject(oldfont);					
}
