#pragma once
#include "../Object/ZObject.h"
#include <windows.h>
#include <stdio.h>
#include <gl\gl.h>


class ZBitmapFonts : public ZObject
{
private:
	HDC hDC;
	HFONT	font;
	HFONT	oldfont;
	GLuint	base;
	GLfloat x;
	GLfloat y;

	char		text[256];		// Holds Our String
	va_list		ap;				// Pointer To List Of Arguments

	GLfloat Color[4];			//Sk�adowe koloru
	int Height;					// height of font
	int Width;					// average character width
	int Escapement;		        // angle of escapement
	int Orientation;		    // base-line orientation angle
	int Weight;					// font weight
	DWORD Italic;			    // italic attribute option
	DWORD Underline;			// underline attribute option
	DWORD StrikeOut;	        // strikeout attribute option
	DWORD CharSet;			    // character set identifier
	DWORD OutputPrecision;		// output precision
	DWORD ClipPrecision;	    // clipping precision
	DWORD Quality;				// output quality
	DWORD PitchAndFamily;		// pitch and family
	LPCTSTR lpszFace;           // typeface name

protected:
public:
	ZBitmapFonts(ZTree *Parent=0);
	virtual ~ZBitmapFonts(void);

	void ZSetHDC(HDC hDC);
	virtual void ZDraw();
	void ZSetColor(GLfloat Red,GLfloat Green,GLfloat Blue, GLfloat Alpha);	//Ustaw Kolor
	void ZSetColor(GLfloat *Color);											//Ustaw Kolor
	void ZSetFontPos(GLfloat x,GLfloat y);
	void ZSetPrintText(const char *fmt, ...);				

	void ZSetHeight(int Height);					// height of font
	void ZSetWidth(int Width);						// average character width
	void ZSetEscapement(int Escapement);	        // angle of escapement
	void ZSetOrientation(int Orientation);		    // base-line orientation angle
	void ZSetWeight(int Weight);					// font weight
	void ZSetItalic(DWORD Italic);				    // italic attribute option
	void ZSetUnderline(DWORD Underline);			// underline attribute option
	void ZSetStrikeOut(DWORD StrikeOut);	        // strikeout attribute option
	void ZSetCharSet(DWORD CharSet);			    // character set identifier
	void ZSetOutputPrecision(DWORD OutputPrecision);// output precision
	void ZSetClipPrecision(DWORD ClipPrecision);	// clipping precision
	void ZSetQuality(DWORD Quality);				// output quality
	void ZSetPitchAndFamily(DWORD PitchAndFamily);	// pitch and family
	void ZSetFontFace(LPCTSTR lpszFace);            // typeface name
};
