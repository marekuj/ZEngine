#include "ZTextureFonts.h"

#include <fstream>
using namespace std;

ZTextureFonts::ZTextureFonts(ZTree *Parent):ZTree(Parent)
{
	ComponentName = "ZTextureFonts";

	x=0;
	y=0;
	Color[0]=1;	Color[1]=1;	Color[2]=1;	Color[3]=1;
	Text[0]='T'; Text[1]='e'; Text[2]='x'; Text[3]='t'; Text[4]='u';  Text[5]='r'; Text[6]='e';
	Text[7]='F'; Text[8]='o'; Text[9]='n'; Text[10]='t'; Text[11]='s'; Text[12]='\0';
	Size=0.01f;
	base=0;
	Set=0;
}

ZTextureFonts::~ZTextureFonts(void)
{
	glDeleteLists(base,256);
}
AUX_RGBImageRec* ZTextureFonts::ZLoadBMP(char* FileName)
{
	ifstream tFile(FileName);
	if(!tFile) return 0;
	tFile.close();
	return auxDIBImageLoad(FileName);
}

char* ZTextureFonts::ZLoadTexture(char *FileName)
{
	if(glIsTexture(texture)) glDeleteTextures(1,&texture); 
	char* buf=FileName;
	AUX_RGBImageRec *Image=0;

	if (Image=ZLoadBMP(FileName))
	{
		buf=0;
		glGenTextures(1, &texture); 
		glBindTexture(GL_TEXTURE_2D, texture);

		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D,0,3,Image->sizeX,
		Image->sizeY,0,GL_RGB,GL_UNSIGNED_BYTE,Image->data );
	}
	if (Image)
	{
		if (Image->data)
		{
			free(Image->data);
		}
		free(Image);
	}

	float	cx;											// Holds Our X Character Coord
	float	cy;											// Holds Our Y Character Coord
	
	if(glIsList(base)) glDeleteLists(base,256);
	base=glGenLists(256);								// Creating 256 Display Lists
	glBindTexture(GL_TEXTURE_2D, texture);				// Select Our Font Texture
	for (int loop=0; loop<256; loop++)						// Loop Through All 256 Lists
	{
		cx=float(loop%16)/16.0f;						// X Position Of Current Character
		cy=float(loop/16)/16.0f;						// Y Position Of Current Character

		glNewList(base+loop,GL_COMPILE);				// Start Building A List
			glBegin(GL_QUADS);							// Use A Quad For Each Character
				glTexCoord2f(cx,1-cy-0.0625f);			// Texture Coord (Bottom Left)
				glVertex2i(0,0);						// Vertex Coord (Bottom Left)
				glTexCoord2f(cx+0.0625f,1-cy-0.0625f);	// Texture Coord (Bottom Right)
				glVertex2i(16,0);						// Vertex Coord (Bottom Right)
				glTexCoord2f(cx+0.0625f,1-cy);			// Texture Coord (Top Right)
				glVertex2i(16,16);						// Vertex Coord (Top Right)
				glTexCoord2f(cx,1-cy);					// Texture Coord (Top Left)
				glVertex2i(0,16);						// Vertex Coord (Top Left)
			glEnd();									// Done Building Our Quad (Character)
			glTranslated(10,0,0);						// Move To The Right Of The Character
		glEndList();									// Done Building The Display List
	}
	return buf;
}
void ZTextureFonts::ZDraw()
{
	glColor4fv(Color);
	glBindTexture(GL_TEXTURE_2D, texture);				
  
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glPushMatrix();										
	glLoadIdentity();									
	glEnable(GL_BLEND);
	glEnable(GL_TEXTURE_2D);							
	glDisable(GL_DEPTH_TEST);							
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);
	glTranslated(x,y,0);								
	glScalef(Size,Size,Size);
	glListBase(base-32+(128*Set));						
	glCallLists((GLsizei)strlen(Text),GL_UNSIGNED_BYTE,Text);	
	glPopMatrix();										
	glPopAttrib();
}
void ZTextureFonts::ZSetColor(GLfloat Red,GLfloat Green,GLfloat Blue, GLfloat Alpha)
{
	Color[0]=Red;
	Color[1]=Green;
	Color[2]=Blue;
	Color[3]=Alpha;
}
void ZTextureFonts::ZSetColor(GLfloat *Color)										
{
	this->Color[0]=Color[0];
	this->Color[1]=Color[1];
	this->Color[2]=Color[2];
	this->Color[3]=Color[3];
}
void ZTextureFonts::ZSetFontPos(GLfloat x,GLfloat y)
{
	this->x=x;
	this->y=y;
}
void ZTextureFonts::ZSetPrintText(char *text)
{
	strcpy_s(this->Text,sizeof(this->Text), text);
//	strcpy_s(this->Text,strlen(text),text);
}
void ZTextureFonts::ZSetSize(GLfloat Size)
{
	this->Size=Size;
}
void ZTextureFonts::ZSetType(bool T)
{
	Set=T;
}
