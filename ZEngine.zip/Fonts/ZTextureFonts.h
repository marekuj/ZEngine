#pragma once
#include "../Tree/ZTree.h"
#include <windows.h>
#include <gl\gl.h>
#include <gl\glaux.h>
#pragma comment (lib,"glaux.lib")
#pragma comment (lib, "legacy_stdio_definitions.lib")
#include <cmath>



class ZTextureFonts :	public ZTree
{
private:
	GLuint	texture;
	AUX_RGBImageRec *ZLoadBMP(char* FileName);

	GLuint	base;
	GLfloat Color[4];			//Sk�adowe koloru
	GLfloat x;
	GLfloat y;
	char Text[256];
	GLfloat Size;
	int Set;

protected:

public:
	ZTextureFonts(ZTree *Parent=0);
	virtual ~ZTextureFonts(void);

	char* ZLoadTexture(char * FileName);
	virtual void ZDraw();
	void ZSetColor(GLfloat Red,GLfloat Green,GLfloat Blue, GLfloat Alpha);	//Ustaw Kolor
	void ZSetColor(GLfloat *Color);											//Ustaw Kolor
	void ZSetFontPos(GLfloat x,GLfloat y);
	void ZSetPrintText(char *text);	

	void ZSetSize(GLfloat Size);
	void ZSetType(bool T=1);
};
