#include "ZTextureManager.h"

#include <fstream>
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::ios;
using std::swap;

ZTextureManager::ZTextureManager(void)
{
}
ZTextureManager::~ZTextureManager(void)
{
	for(unsigned int i=0; i<(unsigned int)Texture.Cell.size(); i++)
	{
		glDeleteTextures(1,&Texture.Cell[i].TextureId);
	}
//	glDeleteTextures(Texture.Size,Texture.TextureId);
}
bool ZTextureManager::ZIsBind(const char *FileName)
{
	return Texture.IsBind(FileName);
}
unsigned int ZTextureManager::ZGetSize()
{
	return (unsigned int)Texture.Cell.size();
}
ZTextureCell& ZTextureManager::ZGetCell(unsigned int Position)
{
	return Texture.Cell[Position];
}
ZTextureCell& ZTextureManager::ZGetCell(unsigned int TextureId,ZCursor &Zen)
{
	return Texture.Cell[Zen.Id[TextureId]];
}
unsigned int ZTextureManager::ZGetPosition(unsigned int TextureId,ZCursor &Zen)
{
	return Zen.Id[TextureId];
}
//AUX_RGBImageRec* ZTextureManager::ZLoadBMP(const char* FileName)
//{
//	ifstream tFile(FileName);
//	if(!tFile) return 0;
//	tFile.close();
//	return auxDIBImageLoad(FileName);
//}
bool ZTextureManager::ZLoadFileBMP(ZTexture2D &Image,const char* FileName)
{
	const unsigned short BITMAP_ID=0x4D42; 
	ifstream FilePtr;
	BITMAPINFOHEADER BitMapInfoHeader;
	BITMAPFILEHEADER BitMapFileHeader;

	Image.Type=GL_UNSIGNED_BYTE;
	Image.ZType=ZTexu::Z_BMP;

	FilePtr.open(FileName,ios::binary | ios::in);
	if(!FilePtr) return 1;
	
	FilePtr.read((char*)&BitMapFileHeader,sizeof(BITMAPFILEHEADER));
	if(BitMapFileHeader.bfType!=BITMAP_ID)
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.read((char*)&BitMapInfoHeader,sizeof(BITMAPINFOHEADER));

	if(BitMapInfoHeader.biSizeImage) Image.SizeImage=BitMapInfoHeader.biSizeImage;
	else Image.SizeImage=BitMapFileHeader.bfSize-BitMapFileHeader.bfOffBits;
	Image.SizeWidth=BitMapInfoHeader.biWidth;
	Image.SizeHeight=BitMapInfoHeader.biHeight;
	if(BitMapInfoHeader.biBitCount==24)
	{
		Image.Components=GL_RGB;
		Image.Format=GL_RGB;
	}
	else
	{
		FilePtr.close();
		return 1;
	}

	if(BitMapInfoHeader.biCompression!=BI_RGB)
	{
		FilePtr.close();
		return 1;
	}
	
	FilePtr.seekg(BitMapFileHeader.bfOffBits,ios::beg);
	
	Image.ZCreateImageDate(Image.SizeImage);
	if(!Image.ImageDate)
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.read((char*)Image.ImageDate,Image.SizeImage);
	
	if(!Image.ImageDate)
	{
		FilePtr.close();
		return 1;
	}

	for(unsigned long i=0; i<Image.SizeImage-3; i+=3)
	{
		swap(Image.ImageDate[i],Image.ImageDate[i+2]);
	}
	FilePtr.close();
	return 0;
}
bool ZTextureManager::ZLoadFileTGA(ZTexture2D &Image,const char* FileName)
{
	ifstream FilePtr;
	unsigned char UcharBad;
	short int SintBad;

	unsigned char ImageTypeCode;
	short int ImageWidth;
	short int ImageHeight;
	unsigned char BitCount;

	Image.Type=GL_UNSIGNED_BYTE;
	Image.ZType=ZTexu::Z_TGA;

	FilePtr.open(FileName,ios::binary | ios::in);
	if(!FilePtr) 
	{
		FilePtr.close();	
		return 1;
	}

	FilePtr.read((char*)&UcharBad,sizeof(UcharBad));
	FilePtr.read((char*)&UcharBad,sizeof(UcharBad));
	
	FilePtr.read((char*)&ImageTypeCode,sizeof(ImageTypeCode));

	if((ImageTypeCode!=2)&&(ImageTypeCode!=3))
	{
		FilePtr.close();
		return 1;
	}

	FilePtr.read((char*)&SintBad,sizeof(SintBad));
	FilePtr.read((char*)&SintBad,sizeof(SintBad));
	FilePtr.read((char*)&UcharBad,sizeof(UcharBad));
	FilePtr.read((char*)&SintBad,sizeof(SintBad));
	FilePtr.read((char*)&SintBad,sizeof(SintBad));

	FilePtr.read((char*)&ImageWidth,sizeof(ImageWidth));
	FilePtr.read((char*)&ImageHeight,sizeof(ImageHeight));
	FilePtr.read((char*)&BitCount,sizeof(BitCount));
	
	FilePtr.read((char*)&UcharBad,sizeof(UcharBad));
	
	BitCount/=8;
	if(BitCount==3)
	{
		Image.Components=GL_RGB;
		Image.Format=GL_RGB;
	}
	else if(BitCount==4)
	{
		Image.Components=GL_RGBA;
		Image.Format=GL_RGBA;
	}
	else
	{
		FilePtr.close();
		return 1;
	}
	Image.SizeImage=ImageWidth*ImageHeight*BitCount;
	
	Image.SizeHeight=ImageHeight;
	Image.SizeWidth=ImageWidth;
	Image.ZCreateImageDate(Image.SizeImage);
	if(!Image.ImageDate)
	{
		FilePtr.close();
		return 1;
	}	
	FilePtr.read((char*)Image.ImageDate,Image.SizeImage);		
	for(unsigned long i=0; i<Image.SizeImage-3; i+=BitCount)
	{
		swap(Image.ImageDate[i],Image.ImageDate[i+2]);
	}
	FilePtr.close();
	return 0;
}
bool ZTextureManager::ZSaveFileBMP(ZTexture2D &Image,const char* FileName)
{
	const unsigned short BITMAP_ID=0x4D42; 
	ofstream FilePtr;
	BITMAPFILEHEADER BitMapFileHeader;
	BITMAPINFOHEADER BitMapInfoHeader;

	Image.SizeImage=Image.SizeWidth*Image.SizeHeight*3;

	FilePtr.open(FileName,ios::binary | ios::out);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	BitMapFileHeader.bfSize=sizeof(BITMAPFILEHEADER);
	BitMapFileHeader.bfType=BITMAP_ID;
	BitMapFileHeader.bfReserved1=0;
	BitMapFileHeader.bfReserved2=0;
	BitMapFileHeader.bfOffBits=sizeof(BITMAPINFOHEADER)+sizeof(BITMAPFILEHEADER);

	BitMapInfoHeader.biSize=sizeof(BITMAPINFOHEADER);
	BitMapInfoHeader.biPlanes=1;
	BitMapInfoHeader.biBitCount=24;
	BitMapInfoHeader.biCompression=BI_RGB;
	BitMapInfoHeader.biSizeImage=Image.SizeImage;
	BitMapInfoHeader.biXPelsPerMeter=0;
	BitMapInfoHeader.biYPelsPerMeter=0;
	BitMapInfoHeader.biClrUsed=0;
	BitMapInfoHeader.biClrImportant=0;
	BitMapInfoHeader.biWidth=Image.SizeWidth;
	BitMapInfoHeader.biHeight=Image.SizeHeight;

	for(unsigned long i=0; i<Image.SizeImage-3; i+=3)
	{
		swap(Image.ImageDate[i],Image.ImageDate[i+2]);
	}

	FilePtr.write((char*)&BitMapFileHeader,sizeof(BITMAPFILEHEADER));
	FilePtr.write((char*)&BitMapInfoHeader,sizeof(BITMAPINFOHEADER));
	FilePtr.write((char*)Image.ImageDate,Image.SizeImage);
	FilePtr.close();
	return 0;
}
bool ZTextureManager::ZSaveFileTGA(ZTexture2D &Image,const char* FileName)
{
	ofstream FilePtr;
	unsigned char UcharBad;
	short int SintBad;

	unsigned char ImageTypeCode;
	short int ImageWidth;
	short int ImageHeight;
	unsigned char BitCount;
	int ColorMode;

	FilePtr.open(FileName,ios::binary | ios::out);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}

	UcharBad=0;
	SintBad=0;

	ImageTypeCode=2;
	ImageWidth=(short int)Image.SizeWidth;
	ImageHeight=(short int)Image.SizeHeight;

	if(Image.Format==GL_RGB)
	{
		ColorMode=3;
		BitCount=24;
	}
	else if(Image.Format==GL_RGBA)
	{
		ColorMode=4;
		BitCount=32;
	}
	else
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.write((char*)&UcharBad,sizeof(UcharBad));
	FilePtr.write((char*)&UcharBad,sizeof(UcharBad));

	FilePtr.write((char*)&ImageTypeCode,sizeof(ImageTypeCode));

	FilePtr.write((char*)&SintBad,sizeof(SintBad));
	FilePtr.write((char*)&SintBad,sizeof(SintBad));
	FilePtr.write((char*)&UcharBad,sizeof(UcharBad));
	FilePtr.write((char*)&SintBad,sizeof(SintBad));
	FilePtr.write((char*)&SintBad,sizeof(SintBad));

	FilePtr.write((char*)&ImageWidth,sizeof(ImageWidth));
	FilePtr.write((char*)&ImageHeight,sizeof(ImageHeight));
	FilePtr.write((char*)&BitCount,sizeof(BitCount));
	
	FilePtr.write((char*)&UcharBad,sizeof(UcharBad));
	BitCount/=8;
	for(unsigned long i=0; i<Image.SizeImage-BitCount; i+=BitCount)
	{
		swap(Image.ImageDate[i],Image.ImageDate[i+2]);
	}

	FilePtr.write((char*)Image.ImageDate,Image.SizeImage);		

	FilePtr.close();
	return 0;
}
const char* ZTextureManager::ZLoadTexture(const char *FileName,ZCursor &Zen,unsigned int TextureType)
{
	ZTexture2D Image;
	char FileBuf[5];
	size_t FileLenght=strlen(FileName);
	FileBuf[0]=FileName[FileLenght-4];
	FileBuf[1]=FileName[FileLenght-3];
	FileBuf[2]=FileName[FileLenght-2];
	FileBuf[3]=FileName[FileLenght-1];
	FileBuf[4]='\0';
	
	if(!strcmp(FileBuf,".bmp"))
	{
		if(ZLoadFileBMP(Image,FileName))
		{
			#ifdef Z_TEXTURE_MANAGER_LOG
			ZPrintLog(Z_FILE_NAME_LOG,Z_TEXTURE_MANAGER_LOG_ERROR,FileName);
			#endif
			return FileName;
		}
	}
	else if(!strcmp(FileBuf,".tga"))
	{
		if(ZLoadFileTGA(Image,FileName))
		{
			#ifdef Z_TEXTURE_MANAGER_LOG
			ZPrintLog(Z_FILE_NAME_LOG,Z_TEXTURE_MANAGER_LOG_ERROR,FileName);
			#endif
			return FileName;
		}
	}
	else
	{
		#ifdef Z_TEXTURE_MANAGER_LOG
		ZPrintLog(Z_FILE_NAME_LOG,Z_TEXTURE_MANAGER_LOG_ERROR,FileName);
		#endif
		return FileName;
	}
		//ofstream File("M.txt");
		////strlen(FileName)
		//File<< strlen("Base.bmp")<<endl;
		//File<< FileName[FileLenght-4]<<endl;
		//File<< FileName[FileLenght-3]<<endl;
		//File<< FileName[FileLenght-2]<<endl;
		//File<< FileName[FileLenght-1]<<endl;
		//File<< FileBuf<<endl;
		//File<< strcmp(FileBuf,".bmp")<<endl;
		//File<< strcmp(FileBuf,"bmp")<<endl;
		//File<< strcmp(FileBuf,".bap")<<endl;
		//File<< strcmp(FileBuf,".tga")<<endl;
		//File.close();
	if(!Texture.IsBind(FileName))
	{
		#ifdef Z_TEXTURE_MANAGER_LOG
		ZPrintLog(Z_FILE_NAME_LOG,Z_TEXTURE_MANAGER_LOG_OK,FileName);
		#endif
		Texture.AddSize(FileName);
		Texture.Cell[Texture.Id].ZType=Image.ZType;

		glGenTextures(1, &Texture.Cell[Texture.Id].TextureId); 
		if(TextureType == ZTexu::Z_TEX_1D)
		{
			glBindTexture(GL_TEXTURE_1D, Texture.Cell[Texture.Id].TextureId);
			Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
			gluBuild2DMipmaps(GL_TEXTURE_1D, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
		}
		else if(TextureType == ZTexu::Z_TEX_2D)
		{
			glBindTexture(GL_TEXTURE_2D, Texture.Cell[Texture.Id].TextureId);
			Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
			gluBuild2DMipmaps(GL_TEXTURE_2D, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
		}
		else if(TextureType == ZTexu::Z_TEX_3D)
		{
			glBindTexture(GL_TEXTURE_3D, Texture.Cell[Texture.Id].TextureId);
			Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
			gluBuild2DMipmaps(GL_TEXTURE_3D, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
		}
		else if(TextureType == ZTexu::Z_TEX_CUBE_PX)
		{
			glBindTexture(GL_TEXTURE_CUBE_MAP, Texture.Cell[Texture.Id].TextureId);
			Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
			gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_POSITIVE_X, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
		}
		else if(TextureType == ZTexu::Z_TEX_CUBE_NX)
		{
			Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
			gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_NEGATIVE_X, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
		}
		else if(TextureType == ZTexu::Z_TEX_CUBE_PY)
		{
			Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
			gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_POSITIVE_Y, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
		}
		else if(TextureType == ZTexu::Z_TEX_CUBE_NY)
		{
			Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
			gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
		}
		else if(TextureType == ZTexu::Z_TEX_CUBE_PZ)
		{
			Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
			gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_POSITIVE_Z, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
		}
		else if(TextureType == ZTexu::Z_TEX_CUBE_NZ)
		{
			Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
			gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
		}
		else
		{
			return "Value is not TextureType.";
		}
	}
	#ifdef Z_TEXTURE_MANAGER_LOG
	else
	{
		ZPrintLog(Z_FILE_NAME_LOG,Z_TEXTURE_MANAGER_LOG_BIND,FileName);
	}
	#endif
	Zen.AddSize();
	Zen.Id[(unsigned int)Zen.Id.size()-1]=Texture.Id;
	#ifdef Z_TEXTURE_MANAGER_PRINT_STATE
	ZPrintState(Z_FILE_NAME_LOG);
	#endif
	return 0;
}
const char* ZTextureManager::ZLoadTexture2D(const char *FileName,ZCursor &Zen)
{
	return ZLoadTexture(FileName,Zen,ZTexu::Z_TEX_2D);
}
const char* ZTextureManager::ZLoadTextureCube(const char *FileName_PX,const char *FileName_NX,
											  const char *FileName_PY,const char *FileName_NY,
											  const char *FileName_PZ,const char *FileName_NZ,
											  ZCursor &Zen)
{
	const char *FileName[6]={FileName_PX,FileName_NX,
							 FileName_PY,FileName_NY,
							 FileName_PZ,FileName_NZ};
	for(int i=0; i<6; i++)
	{
		if(ZLoadTexture(FileName[i],Zen,ZTexu::Z_TEX_CUBE_PX+i))
			return FileName[i];
	}
	return 0;
}
bool ZTextureManager::ZLoadUnBindTexture(unsigned int TextureId,ZCursor &Zen,
										 const char* FileName,unsigned int TextureType)
{
	static ZTexture2D Image;
	Texture.Id=Zen.Id[TextureId];
	if(Texture.Cell[Texture.Id].ZType==ZTexu::Z_BMP)
	{
		if(ZLoadFileBMP(Image,FileName)) return 1;
	}
	else if(Texture.Cell[Texture.Id].ZType==ZTexu::Z_TGA)
	{
		if(ZLoadFileTGA(Image,FileName)) return 1;
	}
	else if(Texture.Cell[Texture.Id].ZType==ZTexu::Z_ERR)
	{
		return 1;
	}

	glGenTextures(1, &Texture.Cell[Zen.Id[TextureId]].TextureId); 
	if(TextureType == ZTexu::Z_TEX_1D)
	{
		glBindTexture(GL_TEXTURE_1D, Texture.Cell[Texture.Id].TextureId);
		Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
		gluBuild2DMipmaps(GL_TEXTURE_1D, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
	}
	else if(TextureType == ZTexu::Z_TEX_2D)
	{
		glBindTexture(GL_TEXTURE_2D, Texture.Cell[Texture.Id].TextureId);
		Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
		gluBuild2DMipmaps(GL_TEXTURE_2D, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
	}
	else if(TextureType == ZTexu::Z_TEX_3D)
	{
		glBindTexture(GL_TEXTURE_3D, Texture.Cell[Texture.Id].TextureId);
		Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
		gluBuild2DMipmaps(GL_TEXTURE_3D, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
	}
	else if(TextureType == ZTexu::Z_TEX_CUBE_PX)
	{
		glBindTexture(GL_TEXTURE_CUBE_MAP, Texture.Cell[Texture.Id].TextureId);
		Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
		gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_POSITIVE_X, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
	}
	else if(TextureType == ZTexu::Z_TEX_CUBE_NX)
	{
		Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
		gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_NEGATIVE_X, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
	}
	else if(TextureType == ZTexu::Z_TEX_CUBE_PY)
	{
		Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
		gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_POSITIVE_Y, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
	}
	else if(TextureType == ZTexu::Z_TEX_CUBE_NY)
	{
		Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
		gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_NEGATIVE_Y, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
	}
	else if(TextureType == ZTexu::Z_TEX_CUBE_PZ)
	{
		Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
		gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_POSITIVE_Z, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
	}
	else if(TextureType == ZTexu::Z_TEX_CUBE_NZ)
	{
		Zen.Creator->ZSetTexture((unsigned int)Zen.Id.size());
		gluBuild2DMipmaps(GL_TEXTURE_CUBE_MAP_NEGATIVE_Z, Image.Components,Image.SizeWidth,Image.SizeHeight,Image.Format, Image.Type, Image.ImageDate);
	}
	else
	{
		return 1;
	}
	return 0;

}
bool ZTextureManager::ZLoadUnBindTexture2D(unsigned int TextureId,ZCursor &Zen,
										   const char* FileName)
{
	return ZLoadUnBindTexture(TextureId,Zen,FileName,ZTexu::Z_TEX_2D);
}
bool ZTextureManager::ZLoadUnBindTextureCube(unsigned int TextureId,ZCursor &Zen,
		     							     const char *FileName_PX,const char *FileName_NX,
											 const char *FileName_PY,const char *FileName_NY,
											 const char *FileName_PZ,const char *FileName_NZ)
{
	const char *FileName[6]={FileName_PX,FileName_NX,
							 FileName_PY,FileName_NY,
							 FileName_PZ,FileName_NZ};
	for(int i=0; i<6; i++)
	{
		if(ZLoadUnBindTexture(TextureId,Zen,FileName[i],ZTexu::Z_TEX_CUBE_PX+i))
			return 1;
	}
	return 0;
}
bool ZTextureManager::ZBindTexture2D(unsigned int TextureId,ZCursor &Zen)
{
	if((unsigned int)Texture.Cell.size()>TextureId)	
	{
		Texture.Id=Zen.Id[TextureId];
		if(Texture.Cell[Texture.Id].IsActive==ZTexu::Z_IS_NOT_LOAD)
		{	//ponowne bindowanie....
			if(ZLoadUnBindTexture2D(TextureId,Zen,Texture.Cell[Texture.Id].Name.c_str()))
				return 0;
		}
		Texture.Cell[Texture.Id].IsActive=ZTexu::Z_VALUE_LOAD;
		glBindTexture(GL_TEXTURE_2D,Texture.Cell[Texture.Id].TextureId);
		return 1;
	}
	return 0;
}
bool ZTextureManager::ZBindMultiTexture2D(unsigned int TextureId,ZCursor &Zen)
{
	if((unsigned int)Texture.Cell.size()>TextureId)	
	{
		Texture.Id=Zen.Id[TextureId];
		if(Texture.Cell[Texture.Id].IsActive==ZTexu::Z_IS_NOT_LOAD)
		{	//ponowne bindowanie....
			if(ZLoadUnBindTexture2D(TextureId,Zen,Texture.Cell[Texture.Id].Name.c_str()))
				return 0;
		}
		glClientActiveTextureARB(GL_TEXTURE0+TextureId);
		Texture.Cell[Texture.Id].IsActive=ZTexu::Z_VALUE_LOAD;
		glActiveTextureARB(GL_TEXTURE0+TextureId);
		glBindTexture(GL_TEXTURE_2D,Texture.Cell[Texture.Id].TextureId);
		glEnable(GL_TEXTURE_2D);
		return 1;
	}
	return 0;
}
bool ZTextureManager::ZBindTextureCube(unsigned int TextureId,ZCursor &Zen)
{
	if((unsigned int)Texture.Cell.size()>TextureId)	
	{
		Texture.Id=Zen.Id[TextureId];
		if(Texture.Cell[Texture.Id].IsActive==ZTexu::Z_IS_NOT_LOAD)
		{	//ponowne bindowanie....
			if(ZLoadUnBindTextureCube(TextureId,Zen,Texture.Cell[Texture.Id].Name.c_str(),Texture.Cell[Texture.Id+1].Name.c_str(),
									  Texture.Cell[Texture.Id+2].Name.c_str(),Texture.Cell[Texture.Id+3].Name.c_str(),
									  Texture.Cell[Texture.Id+4].Name.c_str(),Texture.Cell[Texture.Id+5].Name.c_str()))
				return 0;
		}
		Texture.Cell[Texture.Id].IsActive=ZTexu::Z_VALUE_LOAD;
		Texture.Cell[Texture.Id+1].IsActive=ZTexu::Z_VALUE_LOAD;
		Texture.Cell[Texture.Id+2].IsActive=ZTexu::Z_VALUE_LOAD;
		Texture.Cell[Texture.Id+3].IsActive=ZTexu::Z_VALUE_LOAD;
		Texture.Cell[Texture.Id+4].IsActive=ZTexu::Z_VALUE_LOAD;
		Texture.Cell[Texture.Id+5].IsActive=ZTexu::Z_VALUE_LOAD;
		glBindTexture(GL_TEXTURE_CUBE_MAP,Texture.Cell[Texture.Id].TextureId);
		return 1;
	}
	return 0;
}
bool ZTextureManager::ZBindMultiTextureCube(unsigned int TextureId,ZCursor &Zen)
{
	if((unsigned int)Texture.Cell.size()>TextureId)	
	{
		Texture.Id=Zen.Id[TextureId];
		if(Texture.Cell[Texture.Id].IsActive==ZTexu::Z_IS_NOT_LOAD)
		{	//ponowne bindowanie....
			if(ZLoadUnBindTextureCube(TextureId,Zen,Texture.Cell[Texture.Id].Name.c_str(),Texture.Cell[Texture.Id+1].Name.c_str(),
									  Texture.Cell[Texture.Id+2].Name.c_str(),Texture.Cell[Texture.Id+3].Name.c_str(),
									  Texture.Cell[Texture.Id+4].Name.c_str(),Texture.Cell[Texture.Id+5].Name.c_str()))
				return 0;
		}
		glClientActiveTextureARB(GL_TEXTURE0+TextureId);
		Texture.Cell[Texture.Id].IsActive=ZTexu::Z_VALUE_LOAD;
		Texture.Cell[Texture.Id+1].IsActive=ZTexu::Z_VALUE_LOAD;
		Texture.Cell[Texture.Id+2].IsActive=ZTexu::Z_VALUE_LOAD;
		Texture.Cell[Texture.Id+3].IsActive=ZTexu::Z_VALUE_LOAD;
		Texture.Cell[Texture.Id+4].IsActive=ZTexu::Z_VALUE_LOAD;
		Texture.Cell[Texture.Id+5].IsActive=ZTexu::Z_VALUE_LOAD;
		glActiveTextureARB(GL_TEXTURE0_ARB+TextureId);
		glBindTexture(GL_TEXTURE_CUBE_MAP,Texture.Cell[Texture.Id].TextureId);
		glEnable(GL_TEXTURE_CUBE_MAP);
		return 1;
	}
	return 0;
}
bool ZTextureManager::ZUnBindMultiTexture2D(unsigned int TextureId)
{
	if((unsigned int)Texture.Cell.size()>TextureId)	
	{
		glClientActiveTextureARB(GL_TEXTURE0+TextureId);
		glDisable(GL_TEXTURE_2D);
		if(!TextureId)
		{
			glActiveTextureARB(GL_TEXTURE0);
			glClientActiveTextureARB(GL_TEXTURE0);
			glEnable(GL_TEXTURE_2D);
		}
		return 1;
	}
	return 0;
}
bool ZTextureManager::ZUnBindMultiTextureCube(unsigned int TextureId)
{
	if((unsigned int)Texture.Cell.size()>TextureId)	
	{
		glClientActiveTextureARB(GL_TEXTURE0+TextureId);
		glDisable(GL_TEXTURE_CUBE_MAP);
		if(TextureId==5) 
		{
			glActiveTextureARB(GL_TEXTURE0);
			glClientActiveTextureARB(GL_TEXTURE0);
			glEnable(GL_TEXTURE_2D);
		}
		return 1;
	}
	return 0;
}
void ZTextureManager::ZCleanTexture(float &DeltaTime)
{
	static float LocalTime=0;
	LocalTime+=DeltaTime;
	if(LocalTime>=Z_CLEAN_TEXTURE_TIMER)
	{
		LocalTime=0;
		for(unsigned int i=0; i<(unsigned int)Texture.Cell.size(); i++)
		{
			if(Texture.Cell[i].IsActive!=ZTexu::Z_IS_NOT_LOAD)
			{
				Texture.Cell[i].IsActive--;
				if(Texture.Cell[i].IsActive==ZTexu::Z_IS_NOT_LOAD+1)
				{
					glDeleteTextures(1,&Texture.Cell[i].TextureId);
					Texture.Cell[i].TextureId=0;
					Texture.Cell[i].IsActive=ZTexu::Z_IS_NOT_LOAD;
				}
			}
		}
	}
}
void ZTextureManager::ZSetAnisotropy(float SamplesAnis)
{
	float Bufor=0;
	glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT,&Bufor);
	if(Bufor<SamplesAnis)
		SamplesAnis=Bufor;
	Texture.SamplesAnis=SamplesAnis;
}
float ZTextureManager::ZGetAnisotropy(void)
{
	return Texture.SamplesAnis;
}
unsigned int ZTextureManager::ZGetTexture(unsigned int TextureId,ZCursor &Zen)
{
	if((unsigned int)Texture.Cell.size()>TextureId)
		return Texture.Cell[Zen.Id[TextureId]].TextureId;
	return 0;
}
void ZTextureManager::ZPrintState(const char* FileName)
{
	ofstream File;
	File.open(FileName,ios::app);
	File<<"->ZTextureManager State:"<<endl
		<<"->\tSize: "<<Texture.Cell.size()<<endl
		<<"->\tTexture Id: "<<Texture.Id<<endl;
	File.close();
}