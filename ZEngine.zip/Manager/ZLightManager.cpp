#include "ZLightManager.h"

#include <fstream>
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::ios;

ZLightManager::ZLightManager(void)
{
}
ZLightManager::~ZLightManager(void)
{
}
bool ZLightManager::ZIsFree()
{
	return Light.IsFree();
}
unsigned int ZLightManager::ZGetSize()
{
	return (unsigned int)Light.Cell.size();
}
ZLightCell& ZLightManager::ZGetCell(unsigned int Position)
{
	return Light.Cell[Position];
}
ZLightCell& ZLightManager::ZGetCell(unsigned int LightId,ZCursor &Zen)
{
	return Light.Cell[Zen.Id[LightId]];
}
unsigned int ZLightManager::ZGetPosition(unsigned int LightId,ZCursor &Zen)
{
	return Zen.Id[LightId];
}
ZGlobalLight& ZLightManager::ZGetGlobalLight()
{
	return Light.GlobalLight;
}
bool ZLightManager::ZLoadFileTXT(ZLight &Light,const char *FileName)
{
	ifstream FilePtr;
    char ReadBufor[200];

	FilePtr.open(FileName);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	//Read Heading
    FilePtr.getline(ReadBufor,200,'\n');
	if(strcmp(ReadBufor,"ZEngine Light."))
	{
		FilePtr.close();
		return 1;
	}
	//Read Empty Line
    FilePtr.getline(ReadBufor,200,'\n');
	//Read Light Parameter
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToTypeLight(ReadBufor,'[',']',Light.Type))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToVector3D(ReadBufor,'[',']',Light.Position))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToVector3D(ReadBufor,'[',']',Light.Color))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToFloat(ReadBufor,'[',']',Light.KC))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToFloat(ReadBufor,'[',']',Light.KL))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToFloat(ReadBufor,'[',']',Light.KQ))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToVector3D(ReadBufor,'[',']',Light.Direction))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToFloat(ReadBufor,'[',']',Light.CosInnerCone))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToFloat(ReadBufor,'[',']',Light.CosOuterCone))
	{
		FilePtr.close();
		return 1;
	}
	Light.Enable=1;
	Light.Creator=0;

	FilePtr.close();
	return 0;
}
bool ZLightManager::ZLoadFileLIG(ZLight &Light,const char *FileName)
{
    ifstream FilePtr;

	char Type[10];
	char Version[10];
	char Description[100];

	FilePtr.open(FileName,ios::binary);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.read(Type,sizeof(Type));
	FilePtr.read(Version,sizeof(Version));
	FilePtr.read(Description,sizeof(Description));

	if(strcmp(Type,"lig"))
	{
		FilePtr.close();
		return 1;
	}
	if(!strcmp(Version,"1.0"))
	{
		FilePtr.read((char*)&Light,sizeof(Light));	
		FilePtr.close();
		return 0;
	}
	Light.Enable=1;
	Light.Creator=0;
	FilePtr.close();
	return 1;
}
bool ZLightManager::ZSaveFileTXT(ZLight &Light,const char *FileName)
{
	ofstream FilePtr;

	FilePtr.open(FileName);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	FilePtr<<"ZEngine Light."<<endl<<endl;
	FilePtr<<"Type         = ["<<Light.Type<<']'<<endl;
	FilePtr<<"Position     = ["<<Light.Position.GetX()<<','<<Light.Position.GetY()<<','<<Light.Position.GetZ()<<']'<<endl;
	FilePtr<<"Color        = ["<<Light.Color.GetX()<<','<<Light.Color.GetY()<<','<<Light.Color.GetZ()<<']'<<endl;
	FilePtr<<"KC           = ["<<Light.KC<<']'<<endl;
	FilePtr<<"KL           = ["<<Light.KL<<']'<<endl;
	FilePtr<<"KQ           = ["<<Light.KQ<<']'<<endl;
	FilePtr<<"Direction    = ["<<Light.Direction.GetX()<<','<<Light.Direction.GetY()<<','<<Light.Direction.GetZ()<<']'<<endl;
	FilePtr<<"CosInnerCone = ["<<Light.CosInnerCone<<']'<<endl;
	FilePtr<<"CosOuterCone = ["<<Light.CosOuterCone<<']'<<endl;
	FilePtr.close();
	return 0;
}
bool ZLightManager::ZSaveFileLIG(ZLight &Light,const char *FileName)
{
    ofstream FilePtr;

	char Type[10]="lig";
	char Version[10]="1.0";
	char Description[100]="ZEngine Light.";

	FilePtr.open(FileName,ios::binary);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.write(Type,sizeof(Type));
	FilePtr.write(Version,sizeof(Version));
	FilePtr.write(Description,sizeof(Description));

	FilePtr.write((char*)&Light,sizeof(Light));	

	FilePtr.close();
	return 0;
}
const char* ZLightManager::ZLoadLight(const char *FileName,ZCursor &Zen)
{
	ZLight Stuff;	
	char FileBuf[5];
	size_t FileLenght=strlen(FileName);
	FileBuf[0]=FileName[FileLenght-4];
	FileBuf[1]=FileName[FileLenght-3];
	FileBuf[2]=FileName[FileLenght-2];
	FileBuf[3]=FileName[FileLenght-1];
	FileBuf[4]='\0';
	
	if(!strcmp(FileBuf,".txt"))
	{
		if(ZLoadFileTXT(Stuff,FileName))
		{
			#ifdef Z_LIGHT_MANAGER_LOG
			ZPrintLog(Z_FILE_NAME_LOG,Z_LIGHT_MANAGER_LOG_ERROR,FileName);
			#endif
			return FileName;
		}
	}
	else if(!strcmp(FileBuf,".lig"))
	{
		if(ZLoadFileLIG(Stuff,FileName))
		{
			#ifdef Z_LIGHT_MANAGER_LOG
			ZPrintLog(Z_FILE_NAME_LOG,Z_LIGHT_MANAGER_LOG_ERROR,FileName);
			#endif
			return FileName;
		}
	}
	else
	{
		#ifdef Z_LIGHT_MANAGER_LOG
		ZPrintLog(Z_FILE_NAME_LOG,Z_LIGHT_MANAGER_LOG_ERROR,FileName);
		#endif
		return FileName;
	}
	if(!Light.IsFree())
	{
		Light.AddSize();
	}
	#ifdef Z_LIGHT_MANAGER_LOG
	ZPrintLog(Z_FILE_NAME_LOG,Z_LIGHT_MANAGER_LOG_OK,FileName);
	#endif
	Stuff.Creator=Zen.Creator;
	Light.Cell[Light.Id]=Stuff;
	Zen.AddSize();
	Zen.Id[(unsigned int)Zen.Id.size()-1]=Light.Id;
	#ifdef Z_LIGHT_MANAGER_PRINT_STATE
	ZPrintState(Z_FILE_NAME_LOG);
	#endif

	return 0;
}
bool ZLightManager::ZGetLight(unsigned int LightId,ZCursor &Zen,ZLight &Return)
{
	if(Light.Cell.size()>LightId)
	{
		Return=Light.Cell[Zen.Id[LightId]];
		return 0;
	}
	return 1;
}
void ZLightManager::ZSetOpengGL(Matrix4x4 &InverMatrix)
{
	static Vector4D Param;
	unsigned int End=(unsigned int)(Light.Cell.size()>8)?8:(unsigned int)Light.Cell.size();
	for(unsigned int i=0; i<End; i++)
	{		
		Param=Light.Cell[i].Color;
		glLightfv(GL_LIGHT0+i,GL_DIFFUSE,Param);
		Param.LoadOne();
		glLightfv(GL_LIGHT0+i,GL_SPECULAR,Param);
	
		switch((int)Light.Cell[i].Type)
		{
		case ZLigh::Z_POSITION:
			Param=InverMatrix*Light.Cell[i].Position;
			Param.SetW(0);
			glLightfv(GL_LIGHT0+i,GL_POSITION,Param);
			break;
		case ZLigh::Z_POSITION_ATTENUATION:
			Param=InverMatrix*Light.Cell[i].Position;
			Param.SetW(0);
			glLightfv(GL_LIGHT0+i,GL_POSITION,Param);
			
			glLightf(GL_LIGHT0+i,GL_CONSTANT_ATTENUATION,Light.Cell[i].KC);
			glLightf(GL_LIGHT0+i,GL_LINEAR_ATTENUATION,Light.Cell[i].KL);
			glLightf(GL_LIGHT0+i,GL_QUADRATIC_ATTENUATION,Light.Cell[i].KL);
			break;
		case ZLigh::Z_DIRECTION_SINGLESPOT:
			Param=InverMatrix*Light.Cell[i].Position;
			glLightfv(GL_LIGHT0+i,GL_POSITION,Param);
			
			Param=Light.Cell[i].Direction;
			glLightfv(GL_LIGHT0+i,GL_SPOT_DIRECTION,Param);

			glLightf(GL_LIGHT0+i,GL_SPOT_CUTOFF,Light.Cell[i].CosOuterCone);
			break;
		case ZLigh::Z_DIRECTION_SINGLESPOT_ATTENUATION:
			Param=InverMatrix*Light.Cell[i].Position;
			glLightfv(GL_LIGHT0+i,GL_POSITION,Param);
			
			Param=Light.Cell[i].Direction;
			glLightfv(GL_LIGHT0+i,GL_SPOT_DIRECTION,Param);

			glLightf(GL_LIGHT0+i,GL_CONSTANT_ATTENUATION,Light.Cell[i].KC);
			glLightf(GL_LIGHT0+i,GL_LINEAR_ATTENUATION,Light.Cell[i].KL);
			glLightf(GL_LIGHT0+i,GL_QUADRATIC_ATTENUATION,Light.Cell[i].KL);

			glLightf(GL_LIGHT0+i,GL_SPOT_CUTOFF,Light.Cell[i].CosOuterCone);
			break;
		case ZLigh::Z_DIRECTION_DUALSPOT:
			Param=InverMatrix*Light.Cell[i].Position;
			glLightfv(GL_LIGHT0+i,GL_POSITION,Param);
			
			Param=Light.Cell[i].Direction;
			glLightfv(GL_LIGHT0+i,GL_SPOT_DIRECTION,Param);

			glLightf(GL_LIGHT0+i,GL_SPOT_CUTOFF,Light.Cell[i].CosOuterCone);
			glLightf(GL_LIGHT0+i,GL_SPOT_EXPONENT,Light.Cell[i].CosInnerCone);
			break;
		case ZLigh::Z_DIRECTION_DUALSPOT_ATTENUATION:
			Param=InverMatrix*Light.Cell[i].Position;
			glLightfv(GL_LIGHT0+i,GL_POSITION,Param);
			
			Param=Light.Cell[i].Direction;
			glLightfv(GL_LIGHT0+i,GL_SPOT_DIRECTION,Param);

			glLightf(GL_LIGHT0+i,GL_CONSTANT_ATTENUATION,Light.Cell[i].KC);
			glLightf(GL_LIGHT0+i,GL_LINEAR_ATTENUATION,Light.Cell[i].KL);
			glLightf(GL_LIGHT0+i,GL_QUADRATIC_ATTENUATION,Light.Cell[i].KL);

			glLightf(GL_LIGHT0+i,GL_SPOT_CUTOFF,Light.Cell[i].CosOuterCone);
			glLightf(GL_LIGHT0+i,GL_SPOT_EXPONENT,Light.Cell[i].CosInnerCone);
			break;
		}
	}
}
void ZLightManager::ZDrawPosition(unsigned int LightId,ZCursor &Zen,Matrix4x4 &InverMatrix)
{
	static Vector3D LightPosition;
	static float Vec=0.02f;
	LightPosition.Set(InverMatrix*ZGetCell(LightId,Zen).Position);

	glDisable(GL_LIGHTING);
	glEnable(GL_COLOR_MATERIAL);
	glColor3f(1,1,1);
	glBegin(GL_LINES);
		glVertex3f(0,0,0);
		glVertex3fv(LightPosition);
	glEnd();
	glBegin(GL_LINE_LOOP);
		glVertex3f(LightPosition.GetX()-Vec,
				   LightPosition.GetY()-Vec,
				   LightPosition.GetZ()+Vec);
		glVertex3f(LightPosition.GetX()-Vec,
				   LightPosition.GetY()+Vec,
				   LightPosition.GetZ()+Vec);
		glVertex3f(LightPosition.GetX()+Vec,
				   LightPosition.GetY()+Vec,
				   LightPosition.GetZ()+Vec);
		glVertex3f(LightPosition.GetX()+Vec,
				   LightPosition.GetY()-Vec,
				   LightPosition.GetZ()+Vec);
	glEnd();
	glBegin(GL_LINE_LOOP);
		glVertex3f(LightPosition.GetX()-Vec,
				   LightPosition.GetY()-Vec,
				   LightPosition.GetZ()-Vec);
		glVertex3f(LightPosition.GetX()-Vec,
				   LightPosition.GetY()+Vec,
				   LightPosition.GetZ()-Vec);
		glVertex3f(LightPosition.GetX()+Vec,
				   LightPosition.GetY()+Vec,
				   LightPosition.GetZ()-Vec);
		glVertex3f(LightPosition.GetX()+Vec,
				   LightPosition.GetY()-Vec,
				   LightPosition.GetZ()-Vec);
	glEnd();
	glBegin(GL_LINE_LOOP);
		glVertex3f(LightPosition.GetX()-Vec,
				   LightPosition.GetY()-Vec,
				   LightPosition.GetZ()-Vec);
		glVertex3f(LightPosition.GetX()-Vec,
				   LightPosition.GetY()+Vec,
				   LightPosition.GetZ()-Vec);
		glVertex3f(LightPosition.GetX()-Vec,
				   LightPosition.GetY()+Vec,
				   LightPosition.GetZ()+Vec);
		glVertex3f(LightPosition.GetX()-Vec,
				   LightPosition.GetY()-Vec,
				   LightPosition.GetZ()+Vec);
	glEnd();
	glBegin(GL_LINE_LOOP);
		glVertex3f(LightPosition.GetX()+Vec,
				   LightPosition.GetY()-Vec,
				   LightPosition.GetZ()-Vec);
		glVertex3f(LightPosition.GetX()+Vec,
				   LightPosition.GetY()+Vec,
				   LightPosition.GetZ()-Vec);
		glVertex3f(LightPosition.GetX()+Vec,
				   LightPosition.GetY()+Vec,
				   LightPosition.GetZ()+Vec);
		glVertex3f(LightPosition.GetX()+Vec,
				   LightPosition.GetY()-Vec,
				   LightPosition.GetZ()+Vec);
	glEnd();
	glDisable(GL_COLOR_MATERIAL);
	glEnable(GL_LIGHTING);
}
void ZLightManager::ZPrintState(const char* FileName)
{
	ofstream File;
	File.open(FileName,ios::app);
	File<<"->ZLightManager State:"<<endl
		<<"->\tSize: "<<Light.Cell.size()<<endl
		<<"->\tMaterial Id: "<<Light.Id<<endl;
	File.close();
}