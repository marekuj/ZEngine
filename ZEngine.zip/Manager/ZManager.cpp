#include "ZManager.h"

//#include <fstream>
//using namespace std;
ZManager::ZManager(void)
{
}
ZManager::~ZManager(void)
{
}
const char* ZManager::ZLoadMaterial(const char *FileName,ZCursor &Zen)
{
	return Material.ZLoadMaterial(FileName,Zen);
}
const char* ZManager::ZLoadTexture2D(const char *FileName,ZCursor &Zen)
{
	return Texture.ZLoadTexture2D(FileName,Zen);
}
const char* ZManager::ZLoadTextureCube(const char *FileName_PX,const char *FileName_NX,
									   const char *FileName_PY,const char *FileName_NY,
									   const char *FileName_PZ,const char *FileName_NZ,
									   ZCursor &Zen)
{
	return Texture.ZLoadTextureCube(FileName_PX,FileName_NX,FileName_PY,FileName_NY,
									FileName_PZ,FileName_NZ,Zen);
}

const char* ZManager::ZLoadLight(const char *FileName,ZCursor &Zen)
{
	if(!Light.ZIsFree())
	{
		Program.ZAddLight();
	}
	return Light.ZLoadLight(FileName,Zen);
}
const char* ZManager::ZLoadVertex(const char *FileName,ZCursor &Zen)
{
	const char* Error=Program.ZLoadVertex(FileName,Zen);
	if(Error)
	{
		return Error;
	}
	unsigned int LihgtSzie=0;
	if(Program.ZGetCell(Zen.Id[(unsigned int)Zen.Id.size()-1]).LightNameParameter.compare(""))
	{
		LihgtSzie=Light.ZGetSize()-(unsigned int)Program.ZGetCell(Zen.Id[(unsigned int)Zen.Id.size()-1]).LightParameter.size();
	}
	for(unsigned int i=0; i<LihgtSzie; i++)
	{
		Program.ZGetLightParameter(Zen.Id[(unsigned int)Zen.Id.size()-1],(unsigned int)Program.ZGetCell(Zen.Id[(unsigned int)Zen.Id.size()-1]).LightParameter.size(),
									Program.ZGetCell(Zen.Id[(unsigned int)Zen.Id.size()-1]).LightNameParameter.c_str());	
	}
	//LihgtSzie=Light.ZGetSize()-Program.ZGetCell(Zen.Id[Zen.Size-1]).SizeLightParameter;
	return 0;
}
const char* ZManager::ZLoadFragment(const char *FileName,ZCursor &Zen)
{
	const char* Error=Program.ZLoadFragment(FileName,Zen);
	if(Error)
	{
		return Error;
	}
	//3
	unsigned int LihgtSzie=0;
	if(Program.ZGetCell(Zen.Id[(unsigned int)Zen.Id.size()-1]).LightNameParameter.compare(""))
	{
		LihgtSzie=Light.ZGetSize()-(unsigned int)Program.ZGetCell(Zen.Id[(unsigned int)Zen.Id.size()-1]).LightParameter.size();
	}
	for(unsigned int i=0; i<LihgtSzie; i++)
	{
		Program.ZGetLightParameter(Zen.Id[(unsigned int)Zen.Id.size()-1],(unsigned int)Program.ZGetCell(Zen.Id[(unsigned int)Zen.Id.size()-1]).LightParameter.size(),
									Program.ZGetCell(Zen.Id[(unsigned int)Zen.Id.size()-1]).LightNameParameter.c_str());	
	}
	//LihgtSzie=Light.ZGetSize()-Program.ZGetCell(Zen.Id[Zen.Size-1]).SizeLightParameter;
	return 0;
}
Vector4D A,B,C,A1,B1,C1;;
Matrix4x4 M,N,O,M1,N1,O1;
int ak=100000;
void ZManager::ZSetAuto(unsigned int ProgramId,ZCursor &ProgramCursor,
						unsigned int  FirstMaterialId,ZCursor &MaterialCursor,
						unsigned int  FirstTextureId,ZCursor &TextureCursor,
						ZCursor &LightCursor)
{//unsigned int A;
	static Matrix4x4 BuforMatrix;
	static Vector4D BuforVectot;
	Program.ZBindProgram(ProgramId,ProgramCursor);
	for(unsigned int i=0,TexId=FirstTextureId; i<(unsigned int)Program.ZGetCell((unsigned int)ProgramCursor.Id[ProgramId]).Parameter.size(); i++)
	{
		A=Program.ZGetCell(ProgramCursor.Id[ProgramId]).Parameter[i].Type;
		switch(Program.ZGetCell(ProgramCursor.Id[ProgramId]).Parameter[i].Type)
		{
		case ZProg::Z_TEX_2D_S:
			//ok	niewiem czy trzeba bindowa� !?
			Texture.ZBindTexture2D(TexId,TextureCursor);
			Program.ZSetTextureParameter(ProgramId,ProgramCursor,i,Texture.ZGetTexture(TexId,TextureCursor));
			//Program.ZEnableTextureParameter(i,ProgramCursor,TexId);
			Program.ZEnableTextureParameter(ProgramId,ProgramCursor,i);
			TexId++;
			break;
		case ZProg::Z_TEX_2D_M:
			//ok
			Texture.ZBindMultiTexture2D(TexId,TextureCursor);
			Program.ZSetTextureParameter(ProgramId,ProgramCursor,i,Texture.ZGetTexture(TexId,TextureCursor));
			Program.ZEnableTextureParameter(ProgramId,ProgramCursor,i);
			TexId++;
			break;
		case ZProg::Z_TEX_CUBE_S:
			//ok
			Texture.ZBindTextureCube(TexId,TextureCursor);
			Program.ZSetTextureParameter(ProgramId,ProgramCursor,i,Texture.ZGetTexture(TexId,TextureCursor));
			Program.ZEnableTextureParameter(ProgramId,ProgramCursor,i);
			TexId+=6;
			break;
		case ZProg::Z_TEX_CUBE_M:
			//ok
//			Texture.ZBindMultiTexture2D(TexId,TextureCursor);
//			Program.ZSetTextureParameter(ProgramId,ProgramCursor,i,Texture.ZGetTexture(TexId,TextureCursor));
//			Program.ZEnableTextureParameter(ProgramId,ProgramCursor,i);
//			TexId++;
			Texture.ZBindMultiTextureCube(TexId,TextureCursor);
			//Texture.ZBindTextureCube(TexId,TextureCursor);
			
			Program.ZSetTextureParameter(ProgramId,ProgramCursor,i,Texture.ZGetTexture(TexId,TextureCursor));
			Program.ZEnableTextureParameter(ProgramId,ProgramCursor,i);
			TexId+=6;
			break;
		case ZProg::Z_EYE_V:	//ok
			//ProgramCursor.Creator->ZGetViewMatrix().GetInverse()*Vectro4D(0,0,0,1);
			BuforMatrix=ProgramCursor.Creator->ZGetViewMatrix().GetInverse();
			BuforVectot.Set(0,0,0,1); 
			Program.ZSetParameter3fv(ProgramId,ProgramCursor,i,BuforMatrix*BuforVectot);
			break;
		case ZProg::Z_EYE_M:	//ok
			//ProgramCursor.Creator->ZGetModelViewMatrix().GetInverse()*Vectro4D(0,0,0,1);	
			//Program.ZSetParameter3fv(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelViewMatrix().GetInverse()*ProgramCursor.Creator->ZGetViewMatrix().GetColumn(3));
			BuforMatrix=ProgramCursor.Creator->ZGetModelViewMatrix().GetInverse();
			BuforVectot.Set(0,0,0,1); 
			Program.ZSetParameter3fv(ProgramId,ProgramCursor,i,BuforMatrix*BuforVectot);
			break;

		case ZProg::Z_M_P_ID:
			//ProgramCursor.Creator->ZGetProjectionMatrix()
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetProjectionMatrix());
			//Program.ZSetStateMatrixParameter(ProgramId,ProgramCursor,i,CG_GL_PROJECTION_MATRIX,CG_GL_MATRIX_IDENTITY);
			break;
		case ZProg::Z_M_V_ID:
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetViewMatrix());
			break;
		case ZProg::Z_M_M_ID:// ok
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelMatrix());
			break;
		case ZProg::Z_M_VM_ID:
			//ok
			//Program.ZSetStateMatrixParameter(ProgramId,ProgramCursor,i,CG_GL_MODELVIEW_MATRIX,CG_GL_MATRIX_IDENTITY);
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelViewMatrix());
			break;
		case ZProg::Z_M_VPM_ID:
			//ok
			//Program.ZSetStateMatrixParameter(ProgramId,ProgramCursor,i,CG_GL_MODELVIEW_PROJECTION_MATRIX,CG_GL_MATRIX_IDENTITY);
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelViewProjMatrix());
			break;

		case ZProg::Z_M_P_TR:
			Program.ZSetMatrixParameterfr(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetProjectionMatrix());
			break;
		case ZProg::Z_M_V_TR:
			Program.ZSetMatrixParameterfr(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetViewMatrix());
			break;
		case ZProg::Z_M_M_TR:
			Program.ZSetMatrixParameterfr(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelMatrix());
			break;
		case ZProg::Z_M_VM_TR:
			Program.ZSetMatrixParameterfr(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelViewMatrix());
			break;
		case ZProg::Z_M_VPM_TR:
			Program.ZSetMatrixParameterfr(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelViewProjMatrix());
			break;

		case ZProg::Z_M_P_IN:
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetProjectionMatrix().GetInverse());
			break;
		case ZProg::Z_M_V_IN:
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetViewMatrix().GetInverse());
			break;
		case ZProg::Z_M_M_IN:// ok
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelMatrix().GetInverse());
			break;
		case ZProg::Z_M_VM_IN:
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelViewMatrix().GetInverse());
			break;
		case ZProg::Z_M_VPM_IN:
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelViewProjMatrix().GetInverse());
			break;

		case ZProg::Z_M_P_IT:
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetProjectionMatrix().GetInverseTranspose());
			break;
		case ZProg::Z_M_V_IT:
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetViewMatrix().GetInverseTranspose());
			break;
		case ZProg::Z_M_M_IT:
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelMatrix().GetInverseTranspose());
			break;
		case ZProg::Z_M_VM_IT:
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelViewMatrix().GetInverseTranspose());
			break;
		case ZProg::Z_M_VPM_IT:
			Program.ZSetMatrixParameterfc(ProgramId,ProgramCursor,i,ProgramCursor.Creator->ZGetModelViewProjMatrix().GetInverseTranspose());
			break;
		}
	}
	for(unsigned int i=FirstMaterialId; i<(unsigned int)Program.ZGetCell(ProgramCursor.Id[ProgramId]).MaterialParameter.size(); i++)
	{
		//ok
		Material.ZBindMaterial(i,MaterialCursor);
		Program.ZSetMaterialParameter(ProgramId,ProgramCursor,i,Material.ActiveMaterial());
	}
	unsigned int LightSize=0;
	BuforMatrix=ProgramCursor.Creator->ZGetModelViewMatrix().GetInverse();
	//unsigned int a=Program.ZGetCell(ProgramCursor.Id[ProgramId]).SizeLightParameter;
//	int A=Program.ZGetCell(ProgramCursor.Id[ProgramId]).SizeLightParameter;
	for(unsigned int i=0; i<(unsigned int)Program.ZGetCell((unsigned int)ProgramCursor.Id[ProgramId]).LightParameter.size(); i++)
//	for(unsigned int i=0; i<1; i++)
	{
		if(Light.ZGetCell(i).Enable)
		{
			//ok <-> ale mo�na zoptymalizowa� -> Inverse() nad for. 
			//ProgramCursor.Creator->ZGetModelViewMatrix().GetInverse()*ProgramCursor.Creator->ZGetViewMatrix().GetColumn(3);	
			BuforVectot=Light.ZGetCell(i).Position;
			Light.ZGetCell(i).Position.Set(BuforMatrix*BuforVectot);
			Program.ZSetLightParameter(ProgramId,ProgramCursor,LightSize,Light.ZGetCell(i));
			Light.ZGetCell(i).Position.Set(BuforVectot);
			LightSize++;
		}
	}
	if(LightSize)
	{
		//ok
		Light.ZGetGlobalLight().Size=LightSize;
		Program.ZSetGloabalLightParameter(ProgramId,ProgramCursor,Light.ZGetGlobalLight());
	}
//	ak++;
//	if(ak>100)
//	{
//	ofstream File("0.txt",ios::app);
//	File<<"Po�orzenie Kamery w Widoku   : "<<A1<<endl;
//	File<<"Po�orzenie Obiektu  w Model  : "<<B<<endl;
////	File<<"Wynik                        : "<<C<<endl;
////	File<<"Wynik                        : "<<C1<<endl;
//	File<<endl;
//	File.close();
//	ak=0;
//	}
}
void ZManager::ZUnSetAuto(unsigned int ProgramId,ZCursor &ProgramCursor,
							unsigned int  FirstMaterialId,ZCursor &MaterialCursor,
							unsigned int  FirstTextureId,ZCursor &TextureCursor,
							ZCursor &LightCursor)
{
	for(int i=(unsigned int)Program.ZGetCell((unsigned int)ProgramCursor.Id[ProgramId]).Parameter.size(),TexId=FirstTextureId+(unsigned int)TextureCursor.Id.size()-1; i>0; i--)
	{	//i=i-1 bo to unsigned i nie ma liczb ujemnych
		switch(Program.ZGetCell(ProgramCursor.Id[ProgramId]).Parameter[i-1].Type)
		{
		case ZProg::Z_TEX_2D_S:
			Program.ZDisableTextureParameter(ProgramId,ProgramCursor,i-1);
			TexId--;
			break;
		case ZProg::Z_TEX_2D_M:
			Texture.ZUnBindMultiTexture2D(TexId);
			Program.ZDisableTextureParameter(ProgramId,ProgramCursor,i-1);
			TexId--;
			break;
		case ZProg::Z_TEX_CUBE_S:
			Program.ZDisableTextureParameter(ProgramId,ProgramCursor,i-1);
			TexId-=6;
			break;
		case ZProg::Z_TEX_CUBE_M:
			Texture.ZUnBindMultiTextureCube(TexId);
			Program.ZDisableTextureParameter(ProgramId,ProgramCursor,i-1);
			TexId-=6;
			break;
		}
	}
	Program.ZDisableProfile(ProgramId,ProgramCursor);
}