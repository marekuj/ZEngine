#pragma once

#include "../Log/ZLog.h"

#include "../Tree/ZTree.h"
#include "../Type/ZType.h"
#include "../Extension/ZExtension.h"
#include "../Conversion/ZConversion.h"

#include <gl/gl.h>
#include <gl/glext.h>
#include <gl/glaux.h>
#include <gl/glut.h>

#include <gl/wglext.h>

#include "../Math/Matrix4x4.h"
#include "../ZDate.h"

#include <cg/cg.h>							//C for Graphics
#include <cg/cggl.h>						//Cg for OpenGL

#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glu32.lib")
#pragma comment(lib,"glaux.lib")

#pragma comment(lib,"cg.lib")
#pragma comment(lib,"cggl.lib")

class ZProgramManager
{
private:
//public:
	//bool LightPosition;
	ZBindProgram Program;
	CGcontext Context;

public:
	ZProgramManager(void);
	~ZProgramManager(void);

	bool ZIsBind(const char *FileName);											//Sprawdza czy program jest w tablicy program�w(1 - yes |0 - no)
	unsigned int ZGetSize();													//Zwraca ilo�� element�w
	ZProgramCell& ZGetCell(unsigned int Position);								//Zwraca program o podanym numerze
	ZProgramCell& ZGetCell(unsigned int ProgramId,ZCursor &Zen);				//Zwraca program o podanym numerze
	unsigned int ZGetPosition(unsigned int ProgramId,ZCursor &Zen);				//Zwraca pozycje kom�rki w tablicy 

	bool ZLoadVertexZCG(ZProgram &Program,const char *FileName);				//Pobranie danych - vertex programu - z pliku "*.zcg" do pamieci/ZProgram/ (0 - ok |1 - error)
	bool ZLoadFragmentZCG(ZProgram &Program,const char *FileName);				//Pobranie - fragment programu - z pliku "*.zcg" do pamieci/ZProgram/ (0 - ok |1 - error)

	const char* ZLoadVertex(const char *FileName,ZCursor &Zen);					//Wczytanie vertex programu do pamieci karty (0 - ok |~0 - error)
	const char* ZLoadFragment(const char *FileName,ZCursor &Zen);				//Wczytanie fragment programu do pamieci karty (0 - ok |~0 - error)
	
	bool ZBindProgram(unsigned int ProgramId,ZCursor &Zen);						//Bindowanie programu oraz w��czenie profilu (1 - ok |0 - error)	
	bool ZDisableProfile(unsigned int ProgramId,ZCursor &Zen);					//Wy��czenie profilu (1 - ok |0 - error)

	bool ZGetProgram(unsigned int ProgramId,ZCursor &Zen,CGprogram &Return);		//Zwraca uchwyt do programu o podanym numerze (0 - ok |1 - error)
	//zrobi� ZLoadFileCG
	void ZSetParameter1fv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *V);		//Ustawia wektoro 1-elementowy dla Cg
	void ZSetParameter2fv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *V);		//Ustawia wektoro 2-elementowy dla Cg
	void ZSetParameter3fv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *V);		//Ustawia wektoro 3-elementowy dla Cg
	void ZSetParameter4fv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *V);		//Ustawia wektoro 4-elementowy dla Cg
	void ZSetParameter1dv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *V);	//Ustawia wektoro 1-elementowy dla Cg
	void ZSetParameter2dv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *V);	//Ustawia wektoro 2-elementowy dla Cg
	void ZSetParameter3dv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *V);	//Ustawia wektoro 3-elementowy dla Cg
	void ZSetParameter4dv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *V);	//Ustawia wektoro 4-elementowy dla Cg
	void ZSetParameterArray1f(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const float *V);		//Ustawia tablice wektor�w 1-elementowy dla Cg
	void ZSetParameterArray2f(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const float *V);		//Ustawia tablice wektor�w 2-elementowy dla Cg
	void ZSetParameterArray3f(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const float *V);		//Ustawia tablice wektor�w 3-elementowy dla Cg
	void ZSetParameterArray4f(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const float *V);		//Ustawia tablice wektor�w 4-elementowy dla Cg
	void ZSetParameterArray1d(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const double *V);		//Ustawia tablice wektor�w 1-elementowy dla Cg
	void ZSetParameterArray2d(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const double *V);		//Ustawia tablice wektor�w 2-elementowy dla Cg
	void ZSetParameterArray3d(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const double *V);		//Ustawia tablice wektor�w 3-elementowy dla Cg
	void ZSetParameterArray4d(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const double *V);		//Ustawia tablice wektor�w 4-elementowy dla Cg
	void ZSetParameterPointer(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,GLint Fsize,GLenum Type,GLsizei Stride,const GLvoid *Pointer);	//Ustawia tablice elemet�w dla Cg
	void ZSetMatrixParameterfc(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *Matrix);	//Ustawia macierz 4x4 po kolumnach dla Cg
	void ZSetMatrixParameterfr(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *Matrix);	//Ustawia macierz 4x4 po wierszach dla Cg
	void ZSetMatrixParameterdc(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *Matrix);	//Ustawia macierz 4x4 po kolumnach dla Cg
	void ZSetMatrixParameterdr(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *Matrix);	//Ustawia macierz 4x4 po wierszach dla Cg
	void ZSetStateMatrixParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,CGGLenum Matrix,CGGLenum Transform);		//Ustawia macierz 4x4 dla Cg
	void ZSetTextureParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,unsigned int Texture);	//Ustawia teksture dla Cg
 	void ZSetMaterialParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId, ZMaterial &Material);	//Ustawia materia� dla Cg
	void ZSetLightParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId, ZLight &Light);			//Ustawia �wiato dla Cg
	void ZSetGloabalLightParameter(unsigned int ProgramId,ZCursor &Zen, ZGlobalLight &GlobalLight);					//Ustawia �wiato globalne dla Cg

	bool ZGetMaterialParameter(unsigned int Position,unsigned int ParameterId,const char *Name);	//��czy dane Cg z C++ (0 - ok |1 - error)
	bool ZGetLightParameter(unsigned int Position,unsigned int ParameterId,const char *Name);		//��czy dane Cg z C++ (0 - ok |1 - error)
	bool ZGetGloabalLightParameter(unsigned int Position,const char *Name);							//��czy dane Cg z C++ (0 - ok |1 - error)

	void ZEnableTextureParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId);		//W��cza wczytan� teksture dla Cg
	void ZDisableTextureParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId);	//Wy��cz wczytan� teksture dla Cg

	void ZAddLight();
	bool ZCheckCgError(void);																		//Sprawdza czy s� b�edny w Cg (0 - ok |1 - error)
	bool ZCheckCgError(const char *FileName,const char *Situation,const char *ProgramName="");		//Sprawdza czy s� b�edny w Cg (0 - ok |1 - error)
	void ZPrintState(const char* FileName);
};