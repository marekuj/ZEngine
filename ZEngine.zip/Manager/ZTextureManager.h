#pragma once

#include "../Log/ZLog.h"

#include "../Tree/ZTree.h"
#include "../Type/ZType.h"
#include "../Extension/ZExtension.h"

#include <gl/gl.h>
#include <gl/glext.h>
#include <gl/glaux.h>
#include <gl/glut.h>

#include <gl/wglext.h>

#include "../Math/Matrix4x4.h"
#include "../ZDate.h"

#include <cg/cg.h>							//C for Graphics
#include <cg/cggl.h>						//Cg for OpenGL

#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glu32.lib")
#pragma comment(lib,"glaux.lib")

#pragma comment(lib,"cg.lib")
#pragma comment(lib,"cggl.lib")

const float Z_CLEAN_TEXTURE_TIMER=1.0;

class ZTextureManager
{
private:
	ZBindTexture Texture;//zmieni�!  poprawi� aby dobrze przechowywa�o ID tesxtur CUBE(ZCursor &Zen lun ZBindTesxture aby pamieta�o typy textury!!); 
						 //zmieni�!  zrobic porz�dne enumy!!!
protected:
public:
	ZTextureManager(void);
	~ZTextureManager(void);

	bool ZIsBind(const char *FileName);									//Sprawdza czy tekstura jest w tablicy tekstur(1 - yes |0 - no)
	unsigned int ZGetSize();											//Zwraca ilo�� element�w
	ZTextureCell& ZGetCell(unsigned int Position);						//Zwraca teksture o podanym numerze
	ZTextureCell& ZGetCell(unsigned int TextureId,ZCursor &Zen);		//Zwraca teksture o podanym numerze
	unsigned int ZGetPosition(unsigned int TextureId,ZCursor &Zen);		//Zwraca pozycje kom�rki w tablicy 

//	AUX_RGBImageRec *ZLoadBMP(const char* FileName);					//do kasacji ?  Pobranie bmp z dysku do pamieci
	bool ZLoadFileBMP(ZTexture2D &Image,const char *FileName);			//Pobranie danych z pliku "*.bmp" do pamieci/ZTexture2D/ (0 - ok |1 - error)
	bool ZLoadFileTGA(ZTexture2D &Image,const char* FileName);			//Pobranie danych z pliku "*.tga" pamieci/ZTexture2D/ (0 - ok |1 - error)

	bool ZSaveFileBMP(ZTexture2D &Image,const char* FileName);			//Zaisanie obrazu z pamie�i/ZTexture2D/ do pliku "*.bmp" (0 - ok |1 - error)
	bool ZSaveFileTGA(ZTexture2D &Image,const char* FileName);			//Zaisanie obrazu z pamie�i/ZTexture2D/ do pliku "*.tga" (0 - ok |1 - error)

	const char* ZLoadTexture(const char *FileName,ZCursor &Zen,			//Wczytanie tekstury z hdd do pamieci karty (0 - ok |~0 - error)
							 unsigned int TextureType);
	const char* ZLoadTexture2D(const char *FileName,ZCursor &Zen);		//Wczytanie tekstury z hdd do pamieci karty (0 - ok |~0 - error)
	const char* ZLoadTextureCube(const char *FileName_PX,const char *FileName_NX,	//Wczytanie tekstury z hdd do pamieci karty (0 - ok |~0 - error)
								 const char *FileName_PY,const char *FileName_NY,
								 const char *FileName_PZ,const char *FileName_NZ,
								 ZCursor &Zen);

	bool ZLoadUnBindTexture(unsigned int TextureId,ZCursor &Zen,		//Wczytanie pomowne tekstury z hdd do pamieci karty (0 - ok |1 - error)
							const char* FileName,unsigned int TextureType);	
	bool ZLoadUnBindTexture2D(unsigned int TextureId,ZCursor &Zen,		//Wczytanie pomowne tekstury z hdd do pamieci karty (0 - ok |1 - error)
							  const char* FileName);	
	bool ZLoadUnBindTextureCube(unsigned int TextureId,ZCursor &Zen,		//Wczytanie pomowne tekstury z hdd do pamieci karty (0 - ok |1 - error)
							    const char *FileName_PX,const char *FileName_NX,	//Wczytanie tekstury z hdd do pamieci karty (0 - ok |~0 - error)
								const char *FileName_PY,const char *FileName_NY,
								const char *FileName_PZ,const char *FileName_NZ);	
	
	bool ZBindTexture2D(unsigned int TextureId,ZCursor &Zen);			//Bindowanie tekstury, ponowne wszytanie tekstury (1 - ok |0 - error)
	bool ZBindMultiTexture2D(unsigned int TextureId,ZCursor &Zen);		//Bindowanie tekstury, ponowne wszytanie tekstury (1 - ok |0 - error)
	bool ZBindTextureCube(unsigned int TextureId,ZCursor &Zen);			//Bindowanie tekstury, ponowne wszytanie tekstury (1 - ok |0 - error)
	bool ZBindMultiTextureCube(unsigned int TextureId,ZCursor &Zen);	//Bindowanie tekstury, ponowne wszytanie tekstury (1 - ok |0 - error)

	bool ZUnBindMultiTexture2D(unsigned int TextureId);					//Wy��cza jednostki teksturowe (1 - ok |0 - error)
	bool ZUnBindMultiTextureCube(unsigned int TextureId);					//Wy��cza jednostki teksturowe (1 - ok |0 - error)
	void ZCleanTexture(float &DeltaTime);								//Zwalnia nieu�ywane zasoby/wywo�ane w  Space->ZCalculateUni()/ 

	void ZSetAnisotropy(float SamplesAnis);								//Ustawia liczbe pr�bek Anisotropy
	float ZGetAnisotropy(void);											//Zwraca  liczbe pr�bek Anisotropy

	unsigned int ZGetTexture(unsigned int TextureId,ZCursor &Zen);		//Zwraca uchwyt do tekstury o podanym numerze (~0 - ok |0 - error)
	void ZPrintState(const char* FileName);
};