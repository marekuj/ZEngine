#pragma once

#include "ZTextureManager.h"
#include "ZMaterialManager.h"
#include "ZLightManager.h"
#include "ZProgramManager.h"

class ZManager
{
public:
	ZManager(void);
	~ZManager(void);
//private:
	ZTextureManager Texture;
	ZMaterialManager Material;
	ZLightManager Light;
	ZProgramManager Program;

	const char* ZLoadMaterial(const char *FileName,ZCursor &Zen);	//Wczytanie materia�u do pamieci (0 - ok |~0 - error)
	const char* ZLoadTexture2D(const char *FileName,ZCursor &Zen);	//Wczytanie tekstury z pamie�i/ZTexture2D/ do pamieci karty (0 - ok |~0 - error)
	const char* ZLoadTextureCube(const char *FileName_PX,const char *FileName_NX,	//Wczytanie tekstury z hdd do pamieci karty (0 - ok |~0 - error)
								 const char *FileName_PY,const char *FileName_NY,
								 const char *FileName_PZ,const char *FileName_NZ,
								 ZCursor &Zen);
	const char* ZLoadLight(const char *FileName,ZCursor &Zen);		//Wczytanie �wiata do pamieci oraz dodanie parametr�w w ZProgram(0 - ok |~0 - error)
	const char* ZLoadVertex(const char *FileName,ZCursor &Zen);		//Wczytanie programu do pamieci oraz dodanie parametr�w �wiat�a w ZProgram(0 - ok |~0 - error)
	const char* ZLoadFragment(const char *FileName,ZCursor &Zen);	//Wczytanie programu do pamieci oraz dodanie parametr�w �wiat�a w ZProgram(0 - ok |~0 - error)

	void ZSetAuto(unsigned int ProgramId,ZCursor &ProgramCursor,	//Ustawia parametry opisane w pliku o roszerzeniu "*.zcg" 
					unsigned int  FirstMaterialId,ZCursor &MaterialCursor,
					unsigned int  FirstTextureId,ZCursor &TextureCursor,
					ZCursor &LightCursor);							
	void ZUnSetAuto(unsigned int ProgramId,ZCursor &ProgramCursor,	//Zwalnia parametry opisane w pliku o roszerzeniu(te kt�re trzeba) "*.zcg" 
					unsigned int  FirstMaterialId,ZCursor &MaterialCursor,
					unsigned int  FirstTextureId,ZCursor &TextureCursor,
					ZCursor &LightCursor);
};
