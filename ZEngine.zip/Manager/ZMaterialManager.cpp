#include "ZMaterialManager.h"

#include <fstream>
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::ios;

ZMaterialManager::ZMaterialManager(void)
{
	IsActive=0;
}
ZMaterialManager::~ZMaterialManager(void)
{
}
bool ZMaterialManager::ZIsBind(const char *FileName)
{
	return Material.IsBind(FileName);
}
unsigned int ZMaterialManager::ZGetSize()
{
	return (unsigned int)Material.Cell.size();
}
ZMaterialCell& ZMaterialManager::ZGetCell(unsigned int Position)
{
	return Material.Cell[Position];
}
ZMaterialCell& ZMaterialManager::ZGetCell(unsigned int MaterialId,ZCursor &Zen)
{
	return Material.Cell[Zen.Id[MaterialId]];
}
unsigned int ZMaterialManager::ZGetPosition(unsigned int MaterialId,ZCursor &Zen)
{
	return Zen.Id[MaterialId];
}
ZMaterial& ZMaterialManager::ActiveMaterial()
{
	return *IsActive;
}
bool ZMaterialManager::ZLoadFileTXT(ZMaterial &Material,const char *FileName)
{
	ifstream FilePtr;
    char ReadBufor[200];

	FilePtr.open(FileName);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	//Read Heading
    FilePtr.getline(ReadBufor,200,'\n');
	if(strcmp(ReadBufor,"ZEngine Material."))
	{
		FilePtr.close();
		return 1;
	}
	//Read Empty Line
    FilePtr.getline(ReadBufor,200,'\n');
	//Read Material Parameter
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToVector3D(ReadBufor,'[',']',Material.Ambient))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToVector3D(ReadBufor,'[',']',Material.Diffuse))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToVector3D(ReadBufor,'[',']',Material.Specular))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToVector3D(ReadBufor,'[',']',Material.Emission))
	{
		FilePtr.close();
		return 1;
	}
    FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToFloat(ReadBufor,'[',']',Material.Shininess))
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.close();
	return 0;
}
bool ZMaterialManager::ZLoadFileMAT(ZMaterial &Material,const char *FileName)
{
    ifstream FilePtr;

	char Type[10];
	char Version[10];
	char Description[100];

	FilePtr.open(FileName,ios::binary);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.read(Type,sizeof(Type));
	FilePtr.read(Version,sizeof(Version));
	FilePtr.read(Description,sizeof(Description));

	if(strcmp(Type,"mat"))
	{
		FilePtr.close();
		return 1;
	}
	if(!strcmp(Version,"1.0"))
	{
		FilePtr.read((char*)&Material,sizeof(Material));	
		FilePtr.close();
		return 0;
	}
	FilePtr.close();
	return 1;
}
bool ZMaterialManager::ZSaveFileTXT(ZMaterial &Material,const char *FileName)
{
	ofstream FilePtr;

	FilePtr.open(FileName);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	FilePtr<<"ZEngine Material."<<endl<<endl;
	FilePtr<<"Ambient   = ["<<Material.Ambient.GetX()<<','<<Material.Ambient.GetY()<<','<<Material.Ambient.GetZ()<<']'<<endl;
	FilePtr<<"Diffuse   = ["<<Material.Diffuse.GetX()<<','<<Material.Diffuse.GetY()<<','<<Material.Diffuse.GetZ()<<']'<<endl;
	FilePtr<<"Specular  = ["<<Material.Specular.GetX()<<','<<Material.Specular.GetY()<<','<<Material.Specular.GetZ()<<']'<<endl;
	FilePtr<<"Emission  = ["<<Material.Emission.GetX()<<','<<Material.Emission.GetY()<<','<<Material.Emission.GetZ()<<']'<<endl;
	FilePtr<<"Shininess = ["<<Material.Shininess<<']'<<endl;
	
	FilePtr.close();
	return 0;
}
bool ZMaterialManager::ZSaveFileMAT(ZMaterial &Material,const char *FileName)
{
    ofstream FilePtr;

	char Type[10]="mat";
	char Version[10]="1.0";
	char Description[100]="ZEngine Material.";

	FilePtr.open(FileName,ios::binary);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
	FilePtr.write(Type,sizeof(Type));
	FilePtr.write(Version,sizeof(Version));
	FilePtr.write(Description,sizeof(Description));

	FilePtr.write((char*)&Material,sizeof(Material));	

	FilePtr.close();
	return 0;
}
const char* ZMaterialManager::ZLoadMaterial(const char *FileName,ZCursor &Zen)
{
	ZMaterial Stuff;	
	char FileBuf[5];
	size_t FileLenght=strlen(FileName);
	FileBuf[0]=FileName[FileLenght-4];
	FileBuf[1]=FileName[FileLenght-3];
	FileBuf[2]=FileName[FileLenght-2];
	FileBuf[3]=FileName[FileLenght-1];
	FileBuf[4]='\0';
	
	if(!strcmp(FileBuf,".txt"))
	{
		if(ZLoadFileTXT(Stuff,FileName))
		{
			#ifdef Z_MATERIAL_MANAGER_LOG
			ZPrintLog(Z_FILE_NAME_LOG,Z_MATERIAL_MANAGER_LOG_ERROR,FileName);
			#endif
			return FileName;
		}
	}
	else if(!strcmp(FileBuf,".mat"))
	{
		if(ZLoadFileMAT(Stuff,FileName))
		{
			#ifdef Z_MATERIAL_MANAGER_LOG
			ZPrintLog(Z_FILE_NAME_LOG,Z_MATERIAL_MANAGER_LOG_ERROR,FileName);
			#endif
			return FileName;
		}
	}
	else
	{
		#ifdef Z_MATERIAL_MANAGER_LOG
		ZPrintLog(Z_FILE_NAME_LOG,Z_MATERIAL_MANAGER_LOG_ERROR,FileName);
		#endif
		return FileName;
	}

	if(!Material.IsBind(FileName))
	{
		#ifdef Z_MATERIAL_MANAGER_LOG
		ZPrintLog(Z_FILE_NAME_LOG,Z_MATERIAL_MANAGER_LOG_OK,FileName);
		#endif
		Material.AddSize(FileName);
		Material.Cell[Material.Id]=Stuff;
	}
	#ifdef Z_MATERIAL_MANAGER_LOG
	else
	{
		ZPrintLog(Z_FILE_NAME_LOG,Z_MATERIAL_MANAGER_LOG_BIND,FileName);
	}
	#endif
	Zen.AddSize();
	Zen.Id[(unsigned int)Zen.Id.size()-1]=Material.Id;

	IsActive=&Material.Cell[Material.Id];

	#ifdef Z_MATERIAL_MANAGER_PRINT_STATE
	ZPrintState(Z_FILE_NAME_LOG);
	#endif
	#ifdef Z_OPENGL_ENABLE_STATE
	glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,Material.Cell[Material.Id].Ambient);
	glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,Material.Cell[Material.Id].Diffuse);
	glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,Material.Cell[Material.Id].Specular);
	glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,Material.Cell[Material.Id].Emission);
	glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,Material.Cell[Material.Id].Shininess);
	#endif
	return 0;
}
bool ZMaterialManager::ZBindMaterial(unsigned int MaterialId,ZCursor &Zen)
{
	if(Material.Cell.size()>MaterialId)	
	{
		Material.Id=Zen.Id[MaterialId];
		IsActive=&Material.Cell[Material.Id];

		#ifdef Z_OPENGL_ENABLE_STATE
		glMaterialfv(GL_FRONT_AND_BACK,GL_AMBIENT,Material.Cell[Material.Id].Ambient);
		glMaterialfv(GL_FRONT_AND_BACK,GL_DIFFUSE,Material.Cell[Material.Id].Diffuse);
		glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,Material.Cell[Material.Id].Specular);
		glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,Material.Cell[Material.Id].Emission);
		glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,Material.Cell[Material.Id].Shininess);
		#endif
		return 1;
	}
	return 0;
}
bool ZMaterialManager::GetMaterial(unsigned int MaterialId,ZCursor &Zen,ZMaterial &Return)
{
	if(Material.Cell.size()>MaterialId)
	{
		Return=Material.Cell[Zen.Id[MaterialId]];
		return 0;
	}
	return 1;
}
void ZMaterialManager::ZPrintState(const char* FileName)
{
	ofstream File;
	File.open(FileName,ios::app);
	File<<"->ZMaterialManager State:"<<endl
		<<"->\tSize: "<<Material.Cell.size()<<endl
		<<"->\tMaterial Id: "<<Material.Id<<endl;
	File.close();
}