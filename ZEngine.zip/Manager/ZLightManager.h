#pragma once

#include "../Log/ZLog.h"

#include "../Tree/ZTree.h"
#include "../Type/ZType.h"
#include "../Extension/ZExtension.h"
#include "../Conversion/ZConversion.h"

#include <gl/gl.h>
#include <gl/glext.h>
#include <gl/glaux.h>
#include <gl/glut.h>

#include <gl/wglext.h>

#include "../Math/Matrix4x4.h"
#include "../ZDate.h"

#include <cg/cg.h>							//C for Graphics
#include <cg/cggl.h>						//Cg for OpenGL

#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glu32.lib")
#pragma comment(lib,"glaux.lib")

#pragma comment(lib,"cg.lib")
#pragma comment(lib,"cggl.lib")

class ZLightManager
{
private:
	ZBindLight Light;

public:
	ZLightManager(void);
	~ZLightManager(void);

	bool ZIsFree();													//Sprawdza czy jest nieu�ywane miejsce w tablicy �wiate�(1 - yes |0 - no)
	unsigned int ZGetSize();										//Zwraca ilo�� element�w
	ZLightCell& ZGetCell(unsigned int Position);					//Zwraca �wiat�o o podanym numerze
	ZLightCell& ZGetCell(unsigned int LightId,ZCursor &Zen);		//Zwraca �wiat�o o podanym numerze
	unsigned int ZGetPosition(unsigned int LightId,ZCursor &Zen);	//Zwraca pozycje kom�rki w tablicy 
	
	ZGlobalLight& ZGetGlobalLight();								//Zwraca strukture swiat�o globalne
	
	bool ZLoadFileTXT(ZLight &Light,const char *FileName);			//Pobranie danych z pliku "*.txt" do pamieci/ZLight/ (0 - ok |1 - error)
	bool ZLoadFileLIG(ZLight &Light,const char *FileName);			//Pobranie danych z pliku "*.lig" do pamieci/ZLight/ (0 - ok |1 - error)

	bool ZSaveFileTXT(ZLight &Light,const char *FileName);			//Zaisanie materia�u z pamie�i/ZLight/ do pliku "*.txt" (0 - ok |1 - error)
	bool ZSaveFileLIG(ZLight &Light,const char *FileName);			//Zaisanie materia�u z pamie�i/ZLight/ do pliku "*.lig" (0 - ok |1 - error)

	const char* ZLoadLight(const char *FileName,ZCursor &Zen);		//Wczytanie �wiata do pamieci (0 - ok |~0 - error)

	bool ZGetLight(unsigned int LightId,ZCursor &Zen,ZLight &Return);		//Zwraca �wiat�o  o podanym numerze (0 - ok |1 - error)

	void ZDrawPosition(unsigned int LightId,ZCursor &Zen,Matrix4x4 &InverMatrix);	//Rysuje znacznik swiat�a
	void ZSetOpengGL(Matrix4x4 &InverMatrix);										//Liczy �wiat�o
	void ZPrintState(const char* FileName);
};
