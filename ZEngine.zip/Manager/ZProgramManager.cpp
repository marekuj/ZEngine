#include "ZProgramManager.h"

#include <string>
using std::string;

#include <fstream>
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::ios;

ZProgramManager::ZProgramManager(void)
{
	Context=cgCreateContext();
//	LightPosition=0;
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Create Context");
	#endif
}
ZProgramManager::~ZProgramManager(void)
{
	cgDestroyContext(Context);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Destroy Context");
	#endif
}
bool ZProgramManager::ZIsBind(const char *FileName)
{
	return Program.IsBind(FileName);
}
unsigned int ZProgramManager::ZGetSize()
{
	return (unsigned int)Program.Cell.size();
}
ZProgramCell& ZProgramManager::ZGetCell(unsigned int Position)
{
	return Program.Cell[Position];
}
ZProgramCell& ZProgramManager::ZGetCell(unsigned int ProgramId,ZCursor &Zen)
{
	return Program.Cell[Zen.Id[ProgramId]];
}
unsigned int ZGetPosition(unsigned int ProgramId,ZCursor &Zen)
{
	return Zen.Id[ProgramId];
}
bool ZProgramManager::ZLoadVertexZCG(ZProgram &Program,const char *FileName)
{
	unsigned int SizeParameter=0;
	ifstream FilePtr;
    char ReadBufor[200];

	FilePtr.open(FileName);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
    //Read Heading
    FilePtr.getline(ReadBufor,200,'\n');
	if(strcmp(ReadBufor,"ZEngine Shader."))
	{
		FilePtr.close();
		return 1;
	}
    //Read Empty Line
    FilePtr.getline(ReadBufor,200,'\n');
    //Read Vertex Program Name 
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZCutString(ReadBufor,'[',']',Program.Name))
	{
		FilePtr.close();
		return 1;
	}
	//Read Vertex Program Type
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToCGEnum(ReadBufor,'[',']',Program.ProgramType))
	{
		FilePtr.close();
		return 1;
	}
    //Read Vertex Program Profile 
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToCGProfile(ReadBufor,'[',']',Program.Profile))
	{
		FilePtr.close();
		return 1;
	}
	//Read Vertex Program Entry
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZCutString(ReadBufor,'[',']',Program.Entry))
	{
		FilePtr.close();
		return 1;
	}
	//Read Vertex Program Number Parameter
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToUnsignedInt(ReadBufor,'[',']',SizeParameter))
	{
		FilePtr.close();
		return 1;
	}
	//Read Vertex Program Parameter
	Program.ZCreateParameter(SizeParameter);
	for(unsigned int i=0; i<SizeParameter; i++)
	{
		FilePtr.getline(ReadBufor,200,'\n');
		if(ZCutString(ReadBufor,'[',':',Program.Parameter[i].Name) || ZStringToTypeParameter(ReadBufor,':',']',Program.Parameter[i].Type))
		{
			FilePtr.close();
			return 1;
		}
	}
	FilePtr.close();
	return 0;
}
bool ZProgramManager::ZLoadFragmentZCG(ZProgram &Program,const char *FileName)
{
	unsigned int SizeParameter=0;
	ifstream FilePtr;
    char ReadBufor[200];
	unsigned int BufF=0;
	FilePtr.open(FileName);
	if(!FilePtr)	
	{
		FilePtr.close();
		return 1;
	}
    //Read Heading
    FilePtr.getline(ReadBufor,200,'\n');
	if(strcmp(ReadBufor,"ZEngine Shader."))
	{
		FilePtr.close();
		return 1;
	}
    //Read Empty Line
    FilePtr.getline(ReadBufor,200,'\n');
    //Read Vertex Program
    FilePtr.getline(ReadBufor,200,'\n');
    FilePtr.getline(ReadBufor,200,'\n');
    FilePtr.getline(ReadBufor,200,'\n');
    FilePtr.getline(ReadBufor,200,'\n');
	//Read Vertex Program Number Parameter
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToUnsignedInt(ReadBufor,'[',']',BufF))
	{
		FilePtr.close();
		return 1;
	}
	for(unsigned int i=0; i<BufF; i++)
	{
	    FilePtr.getline(ReadBufor,200,'\n');
	}
    //Read Empty Line
    FilePtr.getline(ReadBufor,200,'\n');
    //Read Fragment Program Name 
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZCutString(ReadBufor,'[',']',Program.Name))
	{
		FilePtr.close();
		return 1;
	}
	//Read Fragment Program Type
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToCGEnum(ReadBufor,'[',']',Program.ProgramType))
	{
		FilePtr.close();
		return 1;
	}
    //Read Fragment Program Profile 
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToCGProfile(ReadBufor,'[',']',Program.Profile))
	{
		FilePtr.close();
		return 1;
	}
	//Read Fragment Program Entry
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZCutString(ReadBufor,'[',']',Program.Entry))
	{
		FilePtr.close();
		return 1;
	}
	//Read Fragment Program Number Parameter
	FilePtr.getline(ReadBufor,200,'\n');
	if(ZStringToUnsignedInt(ReadBufor,'[',']',SizeParameter))
	{
		FilePtr.close();
		return 1;
	}
	//Read Fragment Program Parameter
	Program.ZCreateParameter(SizeParameter);
	for(unsigned int i=0; i<SizeParameter; i++)
	{
		FilePtr.getline(ReadBufor,200,'\n');
		if(ZCutString(ReadBufor,'[',':',Program.Parameter[i].Name) || ZStringToTypeParameter(ReadBufor,':',']',Program.Parameter[i].Type))
		{
			FilePtr.close();
			return 1;
		}
	}
	FilePtr.close();
	return 0;
}
const char* ZProgramManager::ZLoadVertex(const char *FileName,ZCursor &Zen)
{
	//if(LightPosition) 
	//{
	//	if(cgGetLastListing(Context)!=0)
	//		return cgGetLastListing(Context);
	//	return "Error: Cg Create Vertex Program From File";
	//}
	ZProgram Shader;
	string NameParameterBuf;
	char FileBuf[5];
	size_t FileLenght=strlen(FileName);
	FileBuf[0]=FileName[FileLenght-4];
	FileBuf[1]=FileName[FileLenght-3];
	FileBuf[2]=FileName[FileLenght-2];
	FileBuf[3]=FileName[FileLenght-1];
	FileBuf[4]='\0';
	
	if(!strcmp(FileBuf,".zcg"))
	{
		if(ZLoadVertexZCG(Shader,FileName))
		{
			#ifdef Z_CG_PROGRAM_MANAGER_LOG
			ZPrintLog(Z_FILE_NAME_LOG,Z_CG_PROGRAM_MANAGER_LOG_ERROR,Shader.Name.c_str());
			#endif
			return FileName;
		}
	}
	else
	{
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZPrintLog(Z_FILE_NAME_LOG,Z_CG_PROGRAM_MANAGER_LOG_ERROR,Shader.Name.c_str());
		#endif
		return FileName;
	}
//	Program.IsBind(Shader.Name.c_str());
//	Program.IsBind(Shader.Name.c_str());
	if(!Program.IsBind(Shader.Name.c_str()))
	{
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZPrintLog(Z_FILE_NAME_LOG,Z_CG_PROGRAM_MANAGER_LOG_OK,Shader.Name.c_str());
		#endif
		Program.AddSize(Shader.Name.c_str()); //,SizeParameterBuf
		cgGLSetOptimalOptions(Shader.Profile);
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Optimal Options",Shader.Name.c_str());
		#endif
		Program.Cell[Program.Id].Profile=Shader.Profile; 
		Program.Cell[Program.Id].ProgramId=cgCreateProgramFromFile(
										   Context,
										   Shader.ProgramType,
										   Shader.Name.c_str(),
										   Shader.Profile,
										   Shader.Entry.c_str(),
										   Shader.Args);
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Create Vertex Program",Shader.Name.c_str());
		#endif
		if(!cgIsProgramCompiled(Program.Cell[Program.Id].ProgramId))		
		{
//			LightPosition=1;
			if(cgGetLastListing(Context)!=0)
				return cgGetLastListing(Context);
			return "Error: Cg Create Vertex Program From File";
		}
		cgGLLoadProgram(Program.Cell[Program.Id].ProgramId);
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Load Vertex Program",Shader.Name.c_str());
		#endif
		if(!cgGLIsProgramLoaded(Program.Cell[Program.Id].ProgramId))
		{
			return "Error: Cg Load Vertex Program From File";
		}
		if(ZCheckCgError()) return "Error: Cg Create Fragment Program From File";
		for(unsigned int i=0,pn=0,pm=0; i<(unsigned int)Shader.Parameter.size(); i++)
		{
			if(Shader.Parameter[i].Type>ZProg::Z_ERR && Shader.Parameter[i].Type<ZProg::Z_MAT)
			{
				Program.Cell[Program.Id].AddParameter(1);
				Program.Cell[Program.Id].Parameter[pn].Type=Shader.Parameter[i].Type;
				Program.Cell[Program.Id].Parameter[pn].Value=cgGetNamedParameter(
													  Program.Cell[Program.Id].ProgramId,
													  Shader.Parameter[i].Name.c_str());
				if(!cgIsParameter(Program.Cell[Program.Id].Parameter[pn].Value)) 
				return "Program Manager - Param is not a valid parameter";
				#ifdef Z_CG_PROGRAM_MANAGER_LOG
				ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Get Name Parameter",Shader.Name.c_str());
				#endif
				pn++;
			}
			else if(Shader.Parameter[i].Type==ZProg::Z_MAT)
			{
				if(ZGetMaterialParameter(Program.Id,pm,Shader.Parameter[i].Name.c_str()))
				{
					#ifdef Z_CG_PROGRAM_MANAGER_LOG
					ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Get Name Parameter",Shader.Name.c_str());
					#endif
					return "Program Manager - Param is not a valid Material parameter";

				}
				pm++;
			}
			else if(Shader.Parameter[i].Type==ZProg::Z_LIG)
			{
				Program.Cell[Program.Id].LightNameParameter=Shader.Parameter[i].Name;
			}
			else if(Shader.Parameter[i].Type==ZProg::Z_GLOB_LIG)
			{
				if(ZGetGloabalLightParameter(Program.Id,Shader.Parameter[i].Name.c_str()))
				{
					#ifdef Z_CG_PROGRAM_MANAGER_LOG
					ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Get Name Parameter",Shader.Name.c_str());
					#endif
					return "Program Manager - Param is not a valid Gloabal Light parameter";
				}
			}
			else
			{
				return "Program Manager - Bad Type Parameter";
			}
		}
	}
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	else
	{
		ZPrintLog(Z_FILE_NAME_LOG,Z_CG_PROGRAM_MANAGER_LOG_BIND,Shader.Name.c_str());
	}
	#endif
	Zen.AddSize();
	Zen.Id[(unsigned int)Zen.Id.size()-1]=Program.Id;
	#ifdef Z_CG_PROGRAM_MANAGER_PRINT_STATE
	ZPrintState(Z_FILE_NAME_LOG);
	#endif
	return 0;
}
const char* ZProgramManager::ZLoadFragment(const char *FileName,ZCursor &Zen)
{
	//if(LightPosition)
	//{
	//	if(cgGetLastListing(Context)!=0)
	//		return cgGetLastListing(Context);
	//	return "Error: Cg Create Vertex Program From File";
	//}
	ZProgram Shader;
	string NameParameterBuf;
	char FileBuf[5];
	size_t FileLenght=strlen(FileName);
	FileBuf[0]=FileName[FileLenght-4];
	FileBuf[1]=FileName[FileLenght-3];
	FileBuf[2]=FileName[FileLenght-2];
	FileBuf[3]=FileName[FileLenght-1];
	FileBuf[4]='\0';
	
	if(!strcmp(FileBuf,".zcg"))
	{
		if(ZLoadFragmentZCG(Shader,FileName))
		{
			#ifdef Z_CG_PROGRAM_MANAGER_LOG
			ZPrintLog(Z_FILE_NAME_LOG,Z_CG_PROGRAM_MANAGER_LOG_ERROR,Shader.Name.c_str());
			#endif
			return FileName;
		}
	}
	else
	{
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZPrintLog(Z_FILE_NAME_LOG,Z_CG_PROGRAM_MANAGER_LOG_ERROR,Shader.Name.c_str());
		#endif
		return FileName;
	}
	if(!Program.IsBind(Shader.Name.c_str()))
	{
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZPrintLog(Z_FILE_NAME_LOG,Z_CG_PROGRAM_MANAGER_LOG_OK,Shader.Name.c_str());
		#endif
		Program.AddSize(Shader.Name.c_str()); //,SizeParameterBuf
		cgGLSetOptimalOptions(Shader.Profile);
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Optimal Options",Shader.Name.c_str());
		#endif
		Program.Cell[Program.Id].Profile=Shader.Profile; 
		Program.Cell[Program.Id].ProgramId=cgCreateProgramFromFile(
										   Context,
										   Shader.ProgramType,
										   Shader.Name.c_str(),
										   Shader.Profile,
										   Shader.Entry.c_str(),
										   Shader.Args);
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Create Fragment Program",Shader.Name.c_str());
		#endif
		if(!cgIsProgramCompiled(Program.Cell[Program.Id].ProgramId))		
		{
//			LightPosition=1;
			if(cgGetLastListing(Context)!=0)
				return cgGetLastListing(Context);
			return "Error: Cg Create Fragment Program From File";
		}
		cgGLLoadProgram(Program.Cell[Program.Id].ProgramId);
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Load Fragment Program",Shader.Name.c_str());
		#endif
		if(!cgGLIsProgramLoaded(Program.Cell[Program.Id].ProgramId))
		{
			return "Error: Cg Load Fragment Program From File";
		}
		if(ZCheckCgError()) return "Error: Cg Create Fragment Program From File";
		for(unsigned int i=0,pn=0,pm=0; i<(unsigned int)Shader.Parameter.size(); i++)
		{
			if(Shader.Parameter[i].Type>ZProg::Z_ERR && Shader.Parameter[i].Type<ZProg::Z_MAT)
			{
				Program.Cell[Program.Id].AddParameter(1);
				Program.Cell[Program.Id].Parameter[pn].Type=Shader.Parameter[i].Type;
				Program.Cell[Program.Id].Parameter[pn].Value=cgGetNamedParameter(
													  Program.Cell[Program.Id].ProgramId,
													  Shader.Parameter[i].Name.c_str());
				if(!cgIsParameter(Program.Cell[Program.Id].Parameter[pn].Value)) 
					return "Program Manager - Param is not a valid parameter";
				#ifdef Z_CG_PROGRAM_MANAGER_LOG
				ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Get Name Parameter",Shader.Name.c_str());
				#endif
				pn++;
			}
			else if(Shader.Parameter[i].Type==ZProg::Z_MAT)
			{
				if(ZGetMaterialParameter(Program.Id,pm,Shader.Parameter[i].Name.c_str()))
				{
					#ifdef Z_CG_PROGRAM_MANAGER_LOG
					ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Get Name Parameter",Shader.Name.c_str());
					#endif
					return "Program Manager - Param is not a valid Material parameter";
				}
				pm++;
			}
			else if(Shader.Parameter[i].Type==ZProg::Z_LIG)
			{
				Program.Cell[Program.Id].LightNameParameter=Shader.Parameter[i].Name;
			}
			else if(Shader.Parameter[i].Type==ZProg::Z_GLOB_LIG)
			{
				if(ZGetGloabalLightParameter(Program.Id,Shader.Parameter[i].Name.c_str()))
				{
					#ifdef Z_CG_PROGRAM_MANAGER_LOG
					ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Get Name Parameter",Shader.Name.c_str());
					#endif
					return "Program Manager - Param is not a valid Gloabal Light parameter";
				}
			}
			else
			{
				return "Program Manager - Bad Type Parameter";
			}
		}
	}
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	else
	{
		ZPrintLog(Z_FILE_NAME_LOG,Z_CG_PROGRAM_MANAGER_LOG_BIND,Shader.Name.c_str());
	}
	#endif
	Zen.AddSize();
	Zen.Id[(unsigned int)Zen.Id.size()-1]=Program.Id;
	#ifdef Z_CG_PROGRAM_MANAGER_PRINT_STATE
	ZPrintState(Z_FILE_NAME_LOG);
	#endif
	return 0;
}
bool ZProgramManager::ZBindProgram(unsigned int ProgramId,ZCursor &Zen)
{
	if((unsigned int)Program.Cell.size()>ProgramId)	
	{
		cgGLBindProgram(Program.Cell[Zen.Id[ProgramId]].ProgramId);
		cgGLEnableProfile(Program.Cell[Zen.Id[ProgramId]].Profile);
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Bind Profile");
		#endif
		return 1;
	}
	return 0;
}
bool ZProgramManager::ZDisableProfile(unsigned int ProgramId,ZCursor &Zen)
{
	if((unsigned int)Program.Cell.size()>ProgramId)	
	{
		cgGLDisableProfile(Program.Cell[Zen.Id[ProgramId]].Profile);
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Disable Profile");
		#endif
		return 1;
	}
	return 0;
}
bool ZProgramManager::ZGetProgram(unsigned int ProgramId,ZCursor &Zen,CGprogram &Return)
{
	if((unsigned int)Program.Cell.size()>ProgramId)
	{
		Return=Program.Cell[Zen.Id[ProgramId]].ProgramId;
		#ifdef Z_CG_PROGRAM_MANAGER_LOG
		ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Get Program");
		#endif
		return 0;
	}
	return 1;	
}
void ZProgramManager::ZSetParameter1fv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *V)
{
	cgGLSetParameter1fv(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter 1fv");
	#endif
}
void ZProgramManager::ZSetParameter2fv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *V)
{
	cgGLSetParameter2fv(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter 2fv");
	#endif
}
void ZProgramManager::ZSetParameter3fv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *V)
{
	cgGLSetParameter3fv(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter 3fv");
	#endif
}
void ZProgramManager::ZSetParameter4fv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *V)
{
	cgGLSetParameter4fv(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter 4fv");
	#endif
}
void ZProgramManager::ZSetParameter1dv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *V)
{
	cgGLSetParameter1dv(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter 1dv");
	#endif
}
void ZProgramManager::ZSetParameter2dv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *V)
{
	cgGLSetParameter2dv(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter 2dv");
	#endif
}
void ZProgramManager::ZSetParameter3dv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *V)
{
	cgGLSetParameter3dv(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter 3dv");
	#endif
}
void ZProgramManager::ZSetParameter4dv(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *V)
{
	cgGLSetParameter4dv(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter 4dv");
	#endif
}
void ZProgramManager::ZSetParameterArray1f(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const float *V)
{
	cgGLSetParameterArray1f(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Offset,Nelements,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Array 1f");
	#endif
}
void ZProgramManager::ZSetParameterArray2f(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const float *V)
{
	cgGLSetParameterArray2f(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Offset,Nelements,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Array 2f");
	#endif
}
void ZProgramManager::ZSetParameterArray3f(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const float *V)
{
	cgGLSetParameterArray3f(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Offset,Nelements,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Array 3f");
	#endif
}
void ZProgramManager::ZSetParameterArray4f(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const float *V)
{
	cgGLSetParameterArray4f(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Offset,Nelements,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Array 4f");
	#endif
}
void ZProgramManager::ZSetParameterArray1d(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const double *V)
{
	cgGLSetParameterArray1d(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Offset,Nelements,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Array 1d");
	#endif
}
void ZProgramManager::ZSetParameterArray2d(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const double *V)
{
	cgGLSetParameterArray2d(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Offset,Nelements,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Array 2d");
	#endif
}
void ZProgramManager::ZSetParameterArray3d(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const double *V)
{
	cgGLSetParameterArray3d(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Offset,Nelements,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Array 3d");
	#endif
}
void ZProgramManager::ZSetParameterArray4d(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,long Offset,long Nelements,const double *V)
{
	cgGLSetParameterArray4d(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Offset,Nelements,V);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Array 4d");
	#endif
}
void ZProgramManager::ZSetParameterPointer(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,GLint Fsize,GLenum Type,GLsizei Stride,const GLvoid *Pointer)
{
	cgGLSetParameterPointer(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Fsize,Type,Stride,Pointer);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Pointer");
	#endif
}
void ZProgramManager::ZSetMatrixParameterfc(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *Matrix)
{
	cgGLSetMatrixParameterfc(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Matrix);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Matrix Parameter fc");
	#endif
}
void ZProgramManager::ZSetMatrixParameterfr(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const float *Matrix)
{
	cgGLSetMatrixParameterfr(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Matrix);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Matrix Parameter fr");
	#endif
}
void ZProgramManager::ZSetMatrixParameterdc(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *Matrix)
{
	cgGLSetMatrixParameterdc(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Matrix);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Matrix Parameter dc");
	#endif
}
void ZProgramManager::ZSetMatrixParameterdr(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,const double *Matrix)
{
	cgGLSetMatrixParameterdr(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Matrix);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Matrix Parameter dr");
	#endif
}
void ZProgramManager::ZSetStateMatrixParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,CGGLenum Matrix,CGGLenum Transform)   
{
	cgGLSetStateMatrixParameter(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Matrix,Transform);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set State Matrix Parameter");
	#endif
}
void ZProgramManager::ZSetTextureParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId,unsigned int Texture)
{
	cgGLSetTextureParameter(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value,Texture);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Texture Parameter");
	#endif
}
void ZProgramManager::ZSetMaterialParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId, ZMaterial &Material)
{
	cgGLSetParameter3fv(Program.Cell[Zen.Id[ProgramId]].MaterialParameter[ParameterId].Ambient,Material.Ambient);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Material Ambient 3f");
	#endif
	cgGLSetParameter3fv(Program.Cell[Zen.Id[ProgramId]].MaterialParameter[ParameterId].Diffuse,Material.Diffuse);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Material Diffuse 3f");
	#endif
	cgGLSetParameter3fv(Program.Cell[Zen.Id[ProgramId]].MaterialParameter[ParameterId].Specular,Material.Specular);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Material Specular 3f");
	#endif
	cgGLSetParameter3fv(Program.Cell[Zen.Id[ProgramId]].MaterialParameter[ParameterId].Emission,Material.Emission);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Material Emission 3f");
	#endif
	cgGLSetParameter1f(Program.Cell[Zen.Id[ProgramId]].MaterialParameter[ParameterId].Shininess,Material.Shininess);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Material Shininess 1f");
	#endif
}
void ZProgramManager::ZSetLightParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId, ZLight &Light)
{
	cgGLSetParameter1f(Program.Cell[Zen.Id[ProgramId]].LightParameter[ParameterId].Type,Light.Type);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Light Type 1f");
	#endif
	cgGLSetParameter3fv(Program.Cell[Zen.Id[ProgramId]].LightParameter[ParameterId].Position,Light.Position);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Light Position 3f");
	#endif
	cgGLSetParameter3fv(Program.Cell[Zen.Id[ProgramId]].LightParameter[ParameterId].Color,Light.Color);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Light Color 3f");
	#endif
	cgGLSetParameter1f(Program.Cell[Zen.Id[ProgramId]].LightParameter[ParameterId].KC,Light.KC);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Light KC 1f");
	#endif
	cgGLSetParameter1f(Program.Cell[Zen.Id[ProgramId]].LightParameter[ParameterId].KL,Light.KL);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Light KL 1f");
	#endif
	cgGLSetParameter1f(Program.Cell[Zen.Id[ProgramId]].LightParameter[ParameterId].KQ,Light.KQ);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Light KQ 1f");
	#endif
	cgGLSetParameter3fv(Program.Cell[Zen.Id[ProgramId]].LightParameter[ParameterId].Direction,Light.Direction);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Light Direction 3f");
	#endif
	cgGLSetParameter1f(Program.Cell[Zen.Id[ProgramId]].LightParameter[ParameterId].CosInnerCone,Light.CosInnerCone);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Light CosInnerCone 1f");
	#endif
	cgGLSetParameter1f(Program.Cell[Zen.Id[ProgramId]].LightParameter[ParameterId].CosOuterCone,Light.CosOuterCone);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Light CosOuterCone 1f");
	#endif
}
void ZProgramManager::ZSetGloabalLightParameter(unsigned int ProgramId,ZCursor &Zen, ZGlobalLight &GlobalLight)
{
	cgGLSetParameter3fv(Program.Cell[Zen.Id[ProgramId]].GlobalLightParameter.Ambient,GlobalLight.Ambient);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Global Light Ambient 3f");
	#endif
	cgGLSetParameter1f(Program.Cell[Zen.Id[ProgramId]].GlobalLightParameter.Size,GlobalLight.Size);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Set Parameter Global Light Size 1f");
	#endif
}
bool ZProgramManager::ZGetMaterialParameter(unsigned int Position,unsigned int ParameterId,const char *Name)
{
	string NameParameterBuf;
	Program.Cell[Position].AddMaterialParameter(1);
	//Read Material Ambient
	NameParameterBuf=Name;
	NameParameterBuf+=".Ambient";
	Program.Cell[Position].MaterialParameter[ParameterId].Ambient=cgGetNamedParameter(
												Program.Cell[Position].ProgramId,
												NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].MaterialParameter[ParameterId].Ambient)) 
		return 1;
	//Read Material Diffuse
	NameParameterBuf=Name;
	NameParameterBuf+=".Diffuse";
	Program.Cell[Position].MaterialParameter[ParameterId].Diffuse=cgGetNamedParameter(
												Program.Cell[Position].ProgramId,
												NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].MaterialParameter[ParameterId].Diffuse)) 
		return 1;
	//Read Material Specular
	NameParameterBuf=Name;
	NameParameterBuf+=".Specular";
	Program.Cell[Position].MaterialParameter[ParameterId].Specular=cgGetNamedParameter(
												Program.Cell[Position].ProgramId,
												NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].MaterialParameter[ParameterId].Specular)) 
		return 1;
	//Read Material Emission
	NameParameterBuf=Name;
	NameParameterBuf+=".Emission";
	Program.Cell[Position].MaterialParameter[ParameterId].Emission=cgGetNamedParameter(
												Program.Cell[Position].ProgramId,
												NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].MaterialParameter[ParameterId].Emission)) 
		return 1;
	//Read Material Shininess
	NameParameterBuf=Name;
	NameParameterBuf+=".Shininess";
	Program.Cell[Position].MaterialParameter[ParameterId].Shininess=cgGetNamedParameter(
												Program.Cell[Position].ProgramId,
												NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].MaterialParameter[ParameterId].Shininess)) 
		return 1;
	return 0;
}
bool ZProgramManager::ZGetLightParameter(unsigned int Position,unsigned int ParameterId,const char *Name)
{
	const int Size=11;
	char BufF[Size];
	string NameParameterBegin;
	string NameParameterBuf;
	Program.Cell[Position].AddLightParameter(1);

	NameParameterBegin=Name;
	ZIntToString((unsigned int)Program.Cell[Position].LightParameter.size()-1,Size,BufF);
	NameParameterBegin+='[';
	NameParameterBegin+=BufF;
	NameParameterBegin+="]";
	//Read Light Type
	NameParameterBuf=NameParameterBegin;
	NameParameterBuf+=".Type";
	Program.Cell[Position].LightParameter[ParameterId].Type=cgGetNamedParameter(
													Program.Cell[Position].ProgramId,
													NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].LightParameter[ParameterId].Type)) 
		return 1;
	//Read Light Position
	NameParameterBuf=NameParameterBegin;
	NameParameterBuf+=".Position";
	Program.Cell[Position].LightParameter[ParameterId].Position=cgGetNamedParameter(
													Program.Cell[Position].ProgramId,
													NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].LightParameter[ParameterId].Position)) 
		return 1;
	//Read Light Color
	NameParameterBuf=NameParameterBegin;
	NameParameterBuf+=".Color";
	Program.Cell[Position].LightParameter[ParameterId].Color=cgGetNamedParameter(
													Program.Cell[Position].ProgramId,
													NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].LightParameter[ParameterId].Color)) 
		return 1;
	//Read Light KC
	NameParameterBuf=NameParameterBegin;
	NameParameterBuf+=".KC";
	Program.Cell[Position].LightParameter[ParameterId].KC=cgGetNamedParameter(
													Program.Cell[Position].ProgramId,
													NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].LightParameter[ParameterId].KC)) 
		return 1;
	//Read Light KL
	NameParameterBuf=NameParameterBegin;
	NameParameterBuf+=".KL";
	Program.Cell[Position].LightParameter[ParameterId].KL=cgGetNamedParameter(
													Program.Cell[Position].ProgramId,
													NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].LightParameter[ParameterId].KL)) 
		return 1;
	//Read Light KQ
	NameParameterBuf=NameParameterBegin;
	NameParameterBuf+=".KQ";
	Program.Cell[Position].LightParameter[ParameterId].KQ=cgGetNamedParameter(
													Program.Cell[Position].ProgramId,
													NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].LightParameter[ParameterId].KQ)) 
		return 1;
	//Read Light Direction
	NameParameterBuf=NameParameterBegin;
	NameParameterBuf+=".Direction";
	Program.Cell[Position].LightParameter[ParameterId].Direction=cgGetNamedParameter(
													Program.Cell[Position].ProgramId,
													NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].LightParameter[ParameterId].Direction)) 
		return 1;
	//Read Light CosInnerCone
	NameParameterBuf=NameParameterBegin;
	NameParameterBuf+=".CosInnerCone";
	Program.Cell[Position].LightParameter[ParameterId].CosInnerCone=cgGetNamedParameter(
													Program.Cell[Position].ProgramId,
													NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].LightParameter[ParameterId].CosInnerCone)) 
		return 1;
	//Read Light CosOuterCone
	NameParameterBuf=NameParameterBegin;
	NameParameterBuf+=".CosOuterCone";
	Program.Cell[Position].LightParameter[ParameterId].CosOuterCone=cgGetNamedParameter(
													Program.Cell[Position].ProgramId,
													NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].LightParameter[ParameterId].CosOuterCone)) 
		return 1;
	return 0;
}
bool ZProgramManager::ZGetGloabalLightParameter(unsigned int Position,const char *Name)
{
	string NameParameterBuf;
	//Read GloabalLight Ambient
	NameParameterBuf=Name;
	NameParameterBuf+=".Ambient";
	Program.Cell[Position].GlobalLightParameter.Ambient=cgGetNamedParameter(
												Program.Cell[Position].ProgramId,
												NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].GlobalLightParameter.Ambient)) 
		return 1;
	//Read GloabalLight Size
	NameParameterBuf=Name;
	NameParameterBuf+=".Size";
	Program.Cell[Position].GlobalLightParameter.Size=cgGetNamedParameter(
												Program.Cell[Position].ProgramId,
												NameParameterBuf.c_str());
	if(!cgIsParameter(Program.Cell[Position].GlobalLightParameter.Size)) 
		return 1;
	return 0;
}
void ZProgramManager::ZEnableTextureParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId)
{
	cgGLEnableTextureParameter(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Enable Texture Parameter");
	#endif
}
void ZProgramManager::ZDisableTextureParameter(unsigned int ProgramId,ZCursor &Zen,unsigned int ParameterId)
{
	cgGLDisableTextureParameter(Program.Cell[Zen.Id[ProgramId]].Parameter[ParameterId].Value);
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
	ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Disable Texture Parameter");
	#endif
}
void ZProgramManager::ZAddLight()
{
	for(unsigned int i=0; i<(unsigned int)Program.Cell.size();i++)
	{
		if(Program.Cell[i].LightNameParameter.compare(""))
		{
			if(ZGetLightParameter(i,(unsigned int)Program.Cell[i].LightParameter.size(),Program.Cell[i].LightNameParameter.c_str()))
			{
				#ifdef Z_CG_PROGRAM_MANAGER_LOG
				ZCheckCgError(Z_CG_FILE_NAME_ERROR,"Get Name Parameter");
				#endif
			}
		}
	}
}
bool ZProgramManager::ZCheckCgError(void)
{
	CGerror Error;
	const char *StringError = cgGetLastErrorString(&Error);
	return (Error!=CG_NO_ERROR);
}
bool ZProgramManager::ZCheckCgError(const char *FileName,const char *Situation,const char *ProgramName)
{
	CGerror Error;
	const char *StringError = cgGetLastErrorString(&Error);
	if(Error!=CG_NO_ERROR)
	{
		ofstream File(FileName,ios::app);
		File<<"Program Manager["<<ProgramName<<"] - "<<Situation<<' '<<StringError<<endl;
		if(Error == CG_COMPILER_ERROR)
		{
			File<<endl<<cgGetLastListing(Context)<<endl;
		}
		File.close();
		return 1;
	}
	return 0;
}
void ZProgramManager::ZPrintState(const char* FileName)
{
	ofstream File;
	File.open(FileName,ios::app);
	File<<"->ZProgramManager State:"<<endl
		<<"->\tSize: "<<Program.Cell.size()<<endl
		<<"->\tProgram Id: "<<Program.Id<<endl;
	File.close();
}