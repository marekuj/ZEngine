#pragma once

#include "../Log/ZLog.h"

#include "../Tree/ZTree.h"
#include "../Type/ZType.h"
#include "../Extension/ZExtension.h"
#include "../Conversion/ZConversion.h"

#include <gl/gl.h>
#include <gl/glext.h>
#include <gl/glaux.h>
#include <gl/glut.h>

#include <gl/wglext.h>

#include "../Math/Matrix4x4.h"
#include "../ZDate.h"

#include <cg/cg.h>							//C for Graphics
#include <cg/cggl.h>						//Cg for OpenGL

#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glu32.lib")
#pragma comment(lib,"glaux.lib")

#pragma comment(lib,"cg.lib")
#pragma comment(lib,"cggl.lib")

class ZMaterialManager
{
private:
//public:
	ZBindMaterial Material;
	ZMaterial *IsActive;

public:
	ZMaterialManager(void);
	~ZMaterialManager(void);

	bool ZIsBind(const char *FileName);									//Sprawdza czy materia� jest w tablicy materia��w(1 - yes |0 - no)
	unsigned int ZGetSize();											//Zwraca ilo�� element�w
	ZMaterialCell& ZGetCell(unsigned int Position);						//Zwraca matria� o podanym numerze
	ZMaterialCell& ZGetCell(unsigned int MaterialId,ZCursor &Zen);		//Zwraca matria� o podanym numerze
	unsigned int ZGetPosition(unsigned int MaterialId,ZCursor &Zen);	//Zwraca pozycje kom�rki w tablicy 
	ZMaterial& ActiveMaterial();
	
	bool ZLoadFileTXT(ZMaterial &Material,const char *FileName);		//Pobranie danych z pliku "*.txt" do pamieci/ZMaterial/ (0 - ok |1 - error)
	bool ZLoadFileMAT(ZMaterial &Material,const char *FileName);		//Pobranie danych z pliku "*.mat" do pamieci/ZMaterial/ (0 - ok |1 - error)

	bool ZSaveFileTXT(ZMaterial &Material,const char *FileName);		//Zaisanie materia�u z pamie�i/ZMaterial/ do pliku "*.txt" (0 - ok |1 - error)
	bool ZSaveFileMAT(ZMaterial &Material,const char *FileName);		//Zaisanie materia�u z pamie�i/ZMaterial/ do pliku "*.mat" (0 - ok |1 - error)

	const char* ZLoadMaterial(const char *FileName,ZCursor &Zen);		//Wczytanie materia�u do pamieci (0 - ok |~0 - error)
	
	bool ZBindMaterial(unsigned int MaterialId,ZCursor &Zen);			//Bindowanie materia�u (1 - ok |0 - error)	

	bool GetMaterial(unsigned int MaterialId,ZCursor &Zen,ZMaterial &Return);		//Zwraca materia�  o podanym numerze (0 - ok |1 - error)
	void ZPrintState(const char* FileName);
};
