#include "ZConversion.h"

using std::string;

bool ZCutString(char* String,char FlagLeft,char FlagRight,string &Zen)
{
	Zen.clear();
	unsigned int k=0;
	for(unsigned int i=0; i<strlen(String); i++)
	{
		switch(k)
		{
		case 0:
			if(String[i]==FlagLeft) k=1;
			break;
		case 1:
			if(String[i]==FlagRight) 
			{
				k=2;
			}
			else 
			{
				Zen+=String[i];
			}
			break;
		case 2:
			i=(unsigned int)strlen(String);
			break;
		}
	}
	return !(k==2);
}
bool ZStringToInt(char* String,char FlagLeft,char FlagRight,int &Zen)
{
	const int Szie=11;
	char BufF[Szie];
	unsigned int k=0;
	for(unsigned int i=0,j=0; i<strlen(String); i++)
	{
		switch(k)
		{
		case 0:
			if(String[i]==FlagLeft) k=1;
			break;
		case 1:
			if(String[i]==FlagRight) 
			{
				BufF[j]='\0';
				j=0;
				k=2;
			}
			else 
			{
				if(j<Szie) 
				{
					BufF[j]=String[i];
					j++;
				}
				else return 1;
			}
			break;
		case 2:
			i=(unsigned int)strlen(String);
			break;
		}
	}
	Zen=atoi(BufF);
	return !(k==2);
}
bool ZStringToUnsignedInt(char* String,char FlagLeft,char FlagRight,unsigned int &Zen)
{
	const int Szie=11;
	char BufF[Szie];
	char UnBufF=0;		//nietrzeba == BufF[0]
	unsigned int k=0;
	for(unsigned int i=0,j=0; i<strlen(String); i++)
	{
		switch(k)
		{
		case 0:
			if(String[i]==FlagLeft) 
			{
				k=1;
				if(i+1<strlen(String))	UnBufF=String[i+1];
			}
			break;
		case 1:
			if(String[i]==FlagRight) 
			{
				BufF[j]='\0';
				j=0;
				k=2;
			}
			else 
			{
				if(j<Szie) 
				{
					BufF[j]=String[i];
					j++;
				}
				else return 1;
			}
			break;
		case 2:
			i=(unsigned int)strlen(String);
			break;
		}
	}
	Zen=(unsigned int)atoi(BufF);
	return !(k==2) || UnBufF=='-';
}
bool ZStringToFloat(char* String,char FlagLeft,char FlagRight,float &Zen)	  								//0 - OK
{
	const int Szie=11;
	char BufF[Szie];
	unsigned int k=0;
	for(unsigned int i=0,j=0; i<strlen(String); i++)
	{
		switch(k)
		{
		case 0:
			if(String[i]==FlagLeft) k=1;
			break;
		case 1:
			if(String[i]==FlagRight) 
			{
				BufF[j]='\0';
				j=0;
				k=2;
			}
			else 
			{
				if(j<Szie) 
				{
					BufF[j]=String[i];
					j++;
				}
				else return 1;
			}
			break;
		case 2:
			i=(unsigned int)strlen(String);
			break;
		}
	}
	Zen=(float)atof(BufF);
	return !(k==2);
}
bool ZStringToVector3D(char* String,char FlagLeft,char FlagRight,Vector3D &Zen)
{
	const int Szie=11;
	char BufX[Szie];
	char BufY[Szie];
	char BufZ[Szie];
	unsigned int k=0;
	for(unsigned int i=0,j=0; i<strlen(String); i++)
	{
		switch(k)
		{
		case 0:
			if(String[i]==FlagLeft) k=1;
			//else return 1;
			break;
		case 1:
			if(String[i]==',') 
			{
				BufX[j]='\0';
				j=0;
				k=2;
			}
			else 
			{
				if(j<Szie) 
				{
					BufX[j]=String[i];
					j++;
				}
				else return 1;
			}
			break;
		case 2:
			if(String[i]==',') 
			{
				BufY[j]='\0';
				j=0;
				k=3;
			}
			else 
			{
				if(j<Szie) 
				{
					BufY[j]=String[i];
					j++;
				}
				else return 1;
			}
			break;
		case 3:
			if(String[i]==FlagRight) 
			{
				BufZ[j]='\0';
				j=0;
				k=4;
			}
			else 
			{
				if(j<Szie) 
				{
					BufZ[j]=String[i];
					j++;
				}
				else return 1;
			}
			break;
		case 4:
			i=(unsigned int)strlen(String);
			break;
		}
	}
	Zen.Set((float)atof(BufX),(float)atof(BufY),(float)atof(BufZ));
	return !(k==4);
}
bool ZStringToTypeLight(char* String,char FlagLeft,char FlagRight,float &Zen)
{
	const int Szie=51;
	char BufF[Szie];
	unsigned int k=0;
	for(unsigned int i=0,j=0; i<strlen(String); i++)
	{
		switch(k)
		{
		case 0:
			if(String[i]==FlagLeft) k=1;
			break;
		case 1:
			if(String[i]==FlagRight) 
			{
				BufF[j]='\0';
				j=0;
				k=2;
			}
			else 
			{
				if(j<Szie) 
				{
					BufF[j]=String[i];
					j++;
				}
				else return 1;
			}
			break;
		case 2:
			i=(unsigned int)strlen(String);
			break;
		}
	}
	if(!strcmp(BufF,"Position")) Zen=ZLigh::Z_POSITION;
	else if(!strcmp(BufF,"Position_Attenuation")) Zen=ZLigh::Z_POSITION_ATTENUATION;
	else if(!strcmp(BufF,"Direction_SingleCpot")) Zen=ZLigh::Z_DIRECTION_SINGLESPOT;
	else if(!strcmp(BufF,"Direction_SingleCpot_Attenuation")) Zen=ZLigh::Z_DIRECTION_SINGLESPOT_ATTENUATION;
	else if(!strcmp(BufF,"Direction_DualCpot")) Zen=ZLigh::Z_DIRECTION_DUALSPOT;
	else if(!strcmp(BufF,"Direction_DualCpot_Attenuation")) Zen=ZLigh::Z_DIRECTION_DUALSPOT_ATTENUATION;
	else Zen=ZLigh::Z_ERR;
	return !(k==2);
}
bool ZStringToTypeParameter(char* String,char FlagLeft,char FlagRight,unsigned int &Zen)
{
	const int Szie=51;
	char BufF[Szie];
	unsigned int k=0;
	for(unsigned int i=0,j=0; i<strlen(String); i++)
	{
		switch(k)
		{
		case 0:
			if(String[i]==FlagLeft) k=1;
			break;
		case 1:
			if(String[i]==FlagRight) 
			{
				BufF[j]='\0';
				j=0;
				k=2;
			}
			else 
			{
				if(j<Szie) 
				{
					BufF[j]=String[i];
					j++;
				}
				else return 1;
			}
			break;
		case 2:
			i=(unsigned int)strlen(String);
			break;
		}
	}
	if(!strcmp(BufF,"1fv")) Zen=ZProg::Z_1FV;
	else if(!strcmp(BufF,"2fv")) Zen=ZProg::Z_2FV;
	else if(!strcmp(BufF,"3fv")) Zen=ZProg::Z_3FV;
	else if(!strcmp(BufF,"4fv")) Zen=ZProg::Z_4FV;
	else if(!strcmp(BufF,"1dv")) Zen=ZProg::Z_1DV;
	else if(!strcmp(BufF,"2dv")) Zen=ZProg::Z_2DV;
	else if(!strcmp(BufF,"3dv")) Zen=ZProg::Z_3DV;
	else if(!strcmp(BufF,"4dv")) Zen=ZProg::Z_4DV;
	else if(!strcmp(BufF,"a1f")) Zen=ZProg::Z_A1F;
	else if(!strcmp(BufF,"a2f")) Zen=ZProg::Z_A2F;
	else if(!strcmp(BufF,"a3f")) Zen=ZProg::Z_A3F;
	else if(!strcmp(BufF,"a4f")) Zen=ZProg::Z_A4F;
	else if(!strcmp(BufF,"a1d")) Zen=ZProg::Z_A1D;
	else if(!strcmp(BufF,"a2d")) Zen=ZProg::Z_A2D;
	else if(!strcmp(BufF,"a3d")) Zen=ZProg::Z_A3D;
	else if(!strcmp(BufF,"a4d")) Zen=ZProg::Z_A4D;
	else if(!strcmp(BufF,"mfr")) Zen=ZProg::Z_MFR;
	else if(!strcmp(BufF,"mfc")) Zen=ZProg::Z_MFC;
	else if(!strcmp(BufF,"mdr")) Zen=ZProg::Z_MDR;
	else if(!strcmp(BufF,"mdc")) Zen=ZProg::Z_MDC;
	else if(!strcmp(BufF,"smx")) Zen=ZProg::Z_SMX;
	else if(!strcmp(BufF,"tex")) Zen=ZProg::Z_TEX;

	else if(!strcmp(BufF,"ZTEX_2D_S")) Zen=ZProg::Z_TEX_2D_S;
	else if(!strcmp(BufF,"ZTEX_2D_M")) Zen=ZProg::Z_TEX_2D_M;
	else if(!strcmp(BufF,"ZTEX_CUBE_S")) Zen=ZProg::Z_TEX_CUBE_S;
	else if(!strcmp(BufF,"ZTEX_CUBE_M")) Zen=ZProg::Z_TEX_CUBE_M;

	else if(!strcmp(BufF,"ZEYE_V")) Zen=ZProg::Z_EYE_V;
	else if(!strcmp(BufF,"ZEYE_M")) Zen=ZProg::Z_EYE_M;

	else if(!strcmp(BufF,"ZPM_ID")) Zen=ZProg::Z_M_P_ID;
	else if(!strcmp(BufF,"ZVM_ID")) Zen=ZProg::Z_M_V_ID;
	else if(!strcmp(BufF,"ZMM_ID")) Zen=ZProg::Z_M_M_ID;
	else if(!strcmp(BufF,"ZVMM_ID")) Zen=ZProg::Z_M_VM_ID;
	else if(!strcmp(BufF,"ZVMPM_ID")) Zen=ZProg::Z_M_VPM_ID;

	else if(!strcmp(BufF,"ZPM_TR")) Zen=ZProg::Z_M_P_TR;
	else if(!strcmp(BufF,"ZVM_TR")) Zen=ZProg::Z_M_V_TR;
	else if(!strcmp(BufF,"ZMM_TR")) Zen=ZProg::Z_M_M_TR;
	else if(!strcmp(BufF,"ZVMM_TR")) Zen=ZProg::Z_M_VM_TR;
	else if(!strcmp(BufF,"ZVMPM_TR")) Zen=ZProg::Z_M_VPM_TR;

	else if(!strcmp(BufF,"ZPM_IN")) Zen=ZProg::Z_M_P_IN;
	else if(!strcmp(BufF,"ZVM_IN")) Zen=ZProg::Z_M_V_IN;
	else if(!strcmp(BufF,"ZMM_IN")) Zen=ZProg::Z_M_M_IN;
	else if(!strcmp(BufF,"ZVMM_IN")) Zen=ZProg::Z_M_VM_IN;
	else if(!strcmp(BufF,"ZVMPM_IN")) Zen=ZProg::Z_M_VPM_IN;

	else if(!strcmp(BufF,"ZPM_IT")) Zen=ZProg::Z_M_P_IT;
	else if(!strcmp(BufF,"ZVM_IT")) Zen=ZProg::Z_M_V_IT;
	else if(!strcmp(BufF,"ZMM_IT")) Zen=ZProg::Z_M_M_IT;
	else if(!strcmp(BufF,"ZVMM_IT")) Zen=ZProg::Z_M_VM_IT;
	else if(!strcmp(BufF,"ZVMPM_IT")) Zen=ZProg::Z_M_VPM_IT;

	else if(!strcmp(BufF,"ZMaterial")) Zen=ZProg::Z_MAT;
	else if(!strcmp(BufF,"ZLighting")) Zen=ZProg::Z_LIG;
	else if(!strcmp(BufF,"ZGlobLigh")) Zen=ZProg::Z_GLOB_LIG;
	else Zen=ZProg::Z_ERR;
	return !(k==2);
}
bool ZStringToCGProfile(char* String,char FlagLeft,char FlagRight,CGprofile &Zen)
{	//wykorzysta� funkcje Cg;
	string ReadBuforS;
	if(ZCutString(String,'[',']',ReadBuforS)) return 1;
	if(!ReadBuforS.compare("AUTO_VP"))
	{
		Zen=cgGLGetLatestProfile(CG_GL_VERTEX);
		//Zen=Zen=CG_PROFILE_VP40;
		return 0;
	}
	else if(!ReadBuforS.compare("AUTO_FP"))
	{
		Zen=cgGLGetLatestProfile(CG_GL_FRAGMENT);
		Zen=Zen=CG_PROFILE_FP40;
		return 0;
	}
	else
	{
		Zen=cgGetProfile(ReadBuforS.c_str());
		return 0;
	}
	return 1;
}
bool ZStringToCGEnum(char* String,char FlagLeft,char FlagRight,CGenum &Zen)
{
	string ReadBuforS;
	if(ZCutString(String,'[',']',ReadBuforS)) return 1;
	if(!ReadBuforS.compare("SOURCE"))
	{
		Zen=CG_SOURCE;
		return 0;
	}
	else if(!ReadBuforS.compare("OBJECT"))
	{
		Zen=CG_OBJECT;
		return 0;
	}
	return 1;
}
bool ZIntToString(int Int,int ZenSize,char *Zen)
{
	_itoa_s(Int,Zen,ZenSize,10);
	return 0; 
}