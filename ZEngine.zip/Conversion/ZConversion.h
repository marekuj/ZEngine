#pragma once

#include <string>

#include "../Type/ZType.h"
#include "../Extension/ZExtension.h"

#include <gl/gl.h>
#include <gl/glext.h>
#include <gl/glaux.h>
#include <gl/glut.h>

#include <gl/wglext.h>

#include <cg/cg.h>							//C for Graphics
#include <cg/cggl.h>						//Cg for OpenGL

#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glu32.lib")
#pragma comment(lib,"glaux.lib")

#pragma comment(lib,"cg.lib")
#pragma comment(lib,"cggl.lib")


bool ZCutString(char* String,char FlagLeft,char FlagRight,std::string &Zen);					//Wycina z �a�cucha do Stringa (0 - ok |1 - error)
bool ZStringToInt(char* String,char FlagLeft,char FlagRight,int &Zen);					//Konwersja �a�cucha do Int (0 - ok |1 - error)
bool ZStringToUnsignedInt(char* String,char FlagLeft,char FlagRight,unsigned int &Zen);	//Konwersja �a�cucha do Unsigned Int (0 - ok |1 - error)
bool ZStringToFloat(char* String,char FlagLeft,char FlagRight,float &Zen);				//Konwersja �a�cucha do Float (0 - ok |1 - error)
bool ZStringToVector3D(char* String,char FlagLeft,char FlagRight,Vector3D &Zen);		//Konwersja �a�cucha do Vector3d (0 - ok |1 - error)
bool ZStringToTypeLight(char* String,char FlagLeft,char FlagRight,float &Zen);			//Konwersja �a�cucha do TypeLight (0 - ok |1 - error)
bool ZStringToTypeParameter(char* String,char FlagLeft,char FlagRight,unsigned int &Zen);	//Konwersja �a�cucha do TypeParameter (0 - ok |1 - error)
bool ZStringToCGProfile(char* String,char FlagLeft,char FlagRight,CGprofile &Zen);		//Konwersja �a�cucha do CGprofile (0 - ok |1 - error)
bool ZStringToCGEnum(char* String,char FlagLeft,char FlagRight,CGenum &Zen);			//Konwersja �a�cucha do CGenum (0 - ok |1 - error)

bool ZIntToString(int Int,int ZenSize,char *Zen);													//Konwersja Int do �a�cucha (0 - ok |1 - error)