#pragma once
#include <windows.h>

#include "Object/ZObject.h"
#include "Camera/ZCamera.h"

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glext.h>
#include <gl/wglext.h>		

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")


struct ZWindow
{
	HINSTANCE hInstance;
	WNDPROC	WndProc;
	WNDCLASS WndClass;
	HWND   hWnd;
 	HDC hDC;
    HGLRC hRC; 
	ZWindow(WNDPROC	nWndProc=0,HINSTANCE nhInstance=0)
	{
		WndProc=nWndProc;
		hInstance=nhInstance;
	}
};
struct ZPixelBuffer
{
	HPBUFFERARB Buffer;
	HDC         hDC;
	HGLRC       hRC;
	int			Height;
	int			Width;
};
struct ZObjectBuffer
{
	HPBUFFERARB *FrameBuffer;
	HDC *FrameHDC;
	HGLRC* FrameHRC;
	HDC *OpenGLHDC;
	HGLRC* OpenGLHRC;
	ZTree* StartDraw; 
	
	ZCamera* Test;

	GLuint RenderTexture;
	int	Height;
	int	Width;
	int	Angle;
	GLfloat *PozEye;
	GLfloat *RotEye;
	void ZRenderToCube();
	void ZSetCubeView(const int CubeFace);//ponizej nie dzia�a do poprawy
	friend void ZSetBuffer(ZCamera* T,ZObject* FindDraw,ZObjectBuffer &ZBuffer,ZWindow *ZWin,ZPixelBuffer *ZPixBuf);
	GLfloat TMatrix[16];
	
private:
	void ZInit();
};
