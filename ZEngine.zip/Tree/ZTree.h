#pragma once
#include "ZNode.h"
#include "../Math/Matrix4x4.h"

class ZTree : public ZNode
{
private:
	static unsigned int S_GenId;
	static unsigned int S_HowMany;
	unsigned int Id;

protected:
	std::string ComponentName;				//Nazwa Klasy	

	virtual void ZOnLoad(void){};					//Przygotowanie obiekt -> ZGenerate();
	virtual void ZOnPrepare(void){};				//Przygotowanie obiekt -> Wykrywa zderzenia;
	virtual void ZOnDraw(void){};					//Rysuje obiekt -> ZDraw();
	virtual void ZOnAnimate(float &DeltaTime){};	//Wyznacza po�o�enie obiektu -> ZCalculate();
//protected:
//protected:
public:
	//ZPhysisc Physisc;
	virtual void ZSetTexture(unsigned int NrTexture){}	//Ustawienia tekstury(wczutywanej)
public:
	ZTree(ZTree *Parent=0);
	virtual ~ZTree(void);

	static unsigned int ZHowMany(void);	//Zwraca liczbe element�w klasy
	unsigned int ZGetId(void);			//Zwraca Id obiektu

	ZTree* ZFindRoot(void);						//Znajduje korze� drzewa
	ZTree* ZFindIdUp(unsigned int ExampleID);	//Wyszukuje element po Id w g�re drzewa
	ZTree* ZFindIdDown(unsigned int ExampleID);	//Wyszukuje element po Id w d� drzewa
	ZTree* ZFindIdUp(const char *ExampleComponent);		//Wyszukuje pierwszy element po nazwe w g�re drzewa
	ZTree* ZFindIdDown(const char *ExampleComponent);	//Wyszukuje pierwszy element po nazwe w d� drzewa
public:
	virtual Matrix4x4 ZGetModelMatrix(void){return Matrix4x4();}
	virtual Matrix4x4 ZGetViewMatrix(void){return Matrix4x4();}
	virtual Matrix4x4 ZGetProjectionMatrix(void){return Matrix4x4();}
	virtual Matrix4x4 ZGetModelViewMatrix(void){return Matrix4x4();}
	virtual Matrix4x4 ZGetModelViewProjMatrix(void){return Matrix4x4();}
public:
	virtual void ZLoad(void);				//Tworzenie obiektu -> ZGenarateSczene
	virtual void ZPrepare(void);			//Przygotowanie obiekt�w -> Wykrywanie zderze�
	virtual void ZAnimate(float DeltaTime);		//Wyznacza po�o�enie obiekt�w -> ZCalculateScene();
	virtual void ZDraw(void);			//Rysuje obiekty -> ZDrawScene();
public:
	//Obs�uga komunikat�w
	virtual void ZMessageBox(std::string Message);		//Wypisanie b�edu i wyj�cie z programu
	virtual void ZMessageBox(const char *Message);		//Wypisanie komunikatu
	virtual void ZErrorMessageBox(std::string Message);	//Wypisanie b�edu i wyj�cie z programu
	virtual void ZErrorMessageBox(const char *Message);	//Wypisanie komunikatu
	virtual void ZErrorLoadMessageBox(const char *FileName);	//B��d wczytania pliku
	virtual void ZErrorLoadMessageBox(std::string FileName);	//B��d wczytania pliku
};