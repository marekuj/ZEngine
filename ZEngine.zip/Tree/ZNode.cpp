#include "ZNode.h"

ZNode::ZNode(ZNode *Parent)
{
	ParentNode=0;
	ChildNode=0;
	PrevNode=this;
	NextNode=this;
	if(Parent)
	{
		ZAttachTo(Parent);
	}
}
ZNode::~ZNode(void)
{
	ZDetach();
	while(ChildNode)
	{
		delete ChildNode;
	}
}
bool ZNode::ZHasParent(void)
{
	return (ParentNode!=0);
}
bool ZNode::ZHasChild(void)
{
	return (ChildNode!=0);
}
bool ZNode::ZIsFirstChild(void)
{
	if(ParentNode)
	   return (ParentNode->ChildNode==this);
	else
	   return false;
}
bool ZNode::ZIsLastChild(void)
{
	if(ParentNode)
		return (ParentNode->ChildNode->PrevNode==this);
	else
	   return false;
}
void ZNode::ZAttachTo(ZNode *NewParent)
{
	//je�eli w�ze� nale�y juz do listy to usuwa go z listy
	if(ParentNode)
		ZDetach();
	ParentNode=NewParent;
	if(ParentNode->ChildNode)
	{
		PrevNode=ParentNode->ChildNode->PrevNode;
		NextNode=ParentNode->ChildNode;
		ParentNode->ChildNode->PrevNode->NextNode=this;
		ParentNode->ChildNode->PrevNode=this;
	}
	else
	{
		ParentNode->ChildNode=this;      //brak w�z�a podrz�dnego
	}
}
void ZNode::ZAttach(ZNode *NewChild)
{
	//je�eli w�ze� nale�y juz do listy to usuwa go z listy
	if (NewChild->ZHasParent())
	   NewChild->ZDetach();
	NewChild->ParentNode=this;
	if(ChildNode)
	{
		NewChild->PrevNode=ChildNode->PrevNode;
		NewChild->NextNode=ChildNode;
		ChildNode->PrevNode->NextNode=NewChild;
		ChildNode->PrevNode=NewChild;
	}
	else 
		ChildNode = NewChild;
}
void ZNode::ZDetach(void)
{
	//je�li jest pierwszy na li�cie 
	if (ParentNode && ParentNode->ChildNode==this)
	{
	   if (NextNode!=this)
			ParentNode->ChildNode=NextNode;
	   else
			ParentNode->ChildNode=0;
	}
	//usuwa po��czenie

	PrevNode->NextNode=NextNode;
	NextNode->PrevNode=PrevNode;
	//w�ze� nie nale�y ju� do listy
	PrevNode=this;
	NextNode=this;
}
unsigned int ZNode::ZCountNodes(void)
{
	if (ChildNode)
	   return ChildNode->ZCountNodes()+1;
	else
	   return 1;
}