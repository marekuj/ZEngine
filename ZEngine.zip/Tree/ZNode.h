#pragma once

class ZNode				//W�ze� drzewa
{
protected:
     ZNode *ParentNode;  // W�ze� nadrz�dny
     ZNode *ChildNode;   // W�ze� podrz�dny
     ZNode *PrevNode;    // Poprzedni w�ze� siostrzany
     ZNode *NextNode;    // Nast�pny  w�ze� siostrzany
public:
	ZNode(ZNode *Parent=0);
	virtual ~ZNode(void);

	bool ZHasParent(void);		//Czy w�ze� posiada rodzica	
	bool ZHasChild(void);		//Czy w�ze� posiada potomka
	bool ZIsFirstChild(void);	//Czy w�ze� stanowi pocz�tek listy w�z��w siostrzanych
	bool ZIsLastChild(void);		//Czy w�ze� stanowi koniec listy w�z��w siostrzanych
    void ZAttachTo(ZNode *NewParent);	//Umieszcza w�e� na li�cie cyklicznej danego w�z�a nadrz�dnego
    void ZAttach(ZNode *NewChild);		//Dodaje w�ze� podrz�dny
	void ZDetach(void);					//Usuwa w�ze� z listy

	unsigned int ZCountNodes(void);		//Zlicza w�z�y(rz�d drzewa)
};