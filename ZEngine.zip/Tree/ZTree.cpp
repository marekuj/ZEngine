#include "ZTree.h"

#include <iostream>
using std::string;

unsigned int ZTree::S_GenId=0;
unsigned int ZTree::S_HowMany=0;

ZTree::ZTree(ZTree *Parent):ZNode(Parent)
{
	Id=S_GenId++;
	S_HowMany++;
	ComponentName="ZTree";
}
ZTree::~ZTree(void)
{
	S_HowMany--;
//	ZNode::~ZNode();
}
unsigned int ZTree::ZHowMany(void)
{
	return S_HowMany;
}
unsigned int ZTree::ZGetId()
{
	return Id;
}
ZTree* ZTree::ZFindRoot(void)
{
	if(ParentNode)
		return ((ZTree*)ParentNode)->ZFindRoot();
	return this;
}
ZTree* ZTree::ZFindIdUp(unsigned int ExampleID)
{
	if(Id==ExampleID) return this; 
	if(ZHasParent())
		return ((ZTree*)ParentNode)->ZFindIdUp(ExampleID);
	if(ZHasParent() && !ZIsLastChild())
		return ((ZTree*)NextNode)->ZFindIdUp(ExampleID);
	return 0;
}
ZTree* ZTree::ZFindIdDown(unsigned int ExampleID)
{
	if(Id==ExampleID) return this; 
	if(ZHasChild())
		return ((ZTree*)ChildNode)->ZFindIdDown(ExampleID);
	if(ZHasParent() && !ZIsLastChild())
		return ((ZTree*)NextNode)->ZFindIdDown(ExampleID);
	return 0;
}
ZTree* ZTree::ZFindIdUp(const char *ExampleComponent)
{
	if(!ComponentName.compare(ExampleComponent)) return this; 
	if(ZHasParent())
		return ((ZTree*)ParentNode)->ZFindIdUp(ExampleComponent);
	if(ZHasParent() && !ZIsLastChild())
		return ((ZTree*)NextNode)->ZFindIdUp(ExampleComponent);
	return 0;
}
ZTree* ZTree::ZFindIdDown(const char *ExampleComponent)
{
	if(!ComponentName.compare(ExampleComponent)) return this; 
	if(ZHasChild())
		return ((ZTree*)ChildNode)->ZFindIdDown(ExampleComponent);
	if(ZHasParent() && !ZIsLastChild())
		return ((ZTree*)NextNode)->ZFindIdDown(ExampleComponent);
	return 0;
}
void ZTree::ZLoad(void)
{
	ZOnLoad();
	if(ZHasChild())
		((ZTree*)ChildNode)->ZLoad();
	if(ZHasParent() && !ZIsLastChild())
		((ZTree*)NextNode)->ZLoad();
}
void ZTree::ZPrepare(void)
{
	ZOnPrepare();
	if(ZHasChild())
		((ZTree*)ChildNode)->ZPrepare();
	if(ZHasParent() && !ZIsLastChild())
		((ZTree*)NextNode)->ZPrepare();
}
void ZTree::ZAnimate(float DeltaTime)
{
	ZOnAnimate(DeltaTime);
	if(ZHasChild())
		((ZTree*)ChildNode)->ZAnimate(DeltaTime);
	if(ZHasParent() && !ZIsLastChild())
		((ZTree*)NextNode)->ZAnimate(DeltaTime);
}
void ZTree::ZDraw(void)
{
	ZOnDraw();
	if(ZHasChild())
		((ZTree*)ChildNode)->ZDraw();
	if(ZHasParent() && !ZIsLastChild())
		((ZTree*)NextNode)->ZDraw();
}
void ZTree::ZMessageBox(string Message)
{
	ZFindIdUp("ZBaseEngine")->ZMessageBox(Message);
}
void ZTree::ZMessageBox(const char *Message)
{
	ZFindIdUp("ZBaseEngine")->ZMessageBox(Message);
}
void ZTree::ZErrorMessageBox(string Message)
{
	ZFindIdUp("ZBaseEngine")->ZErrorMessageBox(Message);
}
void ZTree::ZErrorMessageBox(const char *Message)
{
	ZFindIdUp("ZBaseEngine")->ZErrorMessageBox(Message);
}
void ZTree::ZErrorLoadMessageBox(const char *FileName)
{
	ZFindIdUp("ZBaseEngine")->ZErrorLoadMessageBox(FileName);
}
void ZTree::ZErrorLoadMessageBox(string FileName)
{
	ZFindIdUp("ZBaseEngine")->ZErrorLoadMessageBox(FileName);
}
