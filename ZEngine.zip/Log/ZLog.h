#pragma once

#define Z_OPENGL_ENABLE_STATE		//aktualizuje stan danych OpenGL(Materai�,�wiat�a, Macierze itp.)

#define Z_ENABLE_LOG
#ifdef Z_ENABLE_LOG

	#define Z_FILE_NAME_LOG "Data/Log/Log.txt"
	void ZPrintBeginLog(const char* FileName);
	void ZPrintChapterLog(const char* FileName,const char* AddLog,const char* AddFileName);
	void ZPrintLog(const char* FileName,const char* AddLog,const char* AddFileName);

	#define Z_TREE_LOG
	#ifdef Z_TREE_LOG

		#define Z_TREE_OBJECT_NAME_LOG "ZEngine Object Type: "

		#define Z_TREE_FIND_COMPONENT_LOG_OK "ZTree Find Component: "
		#define Z_TREE_FIND_COMPONENT_LOG_ERROR "Tree No Find Component: "
	#endif

	#define Z_PHYSISC_LOG
	#ifdef Z_PHYSISC_LOG

		#define Z_PHYSISC_LOG_OK "ZPhysisc Load File: "
		#define Z_PHYSISC_LOG_ERROR "ZPhysisc Error File: "
	#endif

	#define Z_TEXTURE_MANAGER_LOG
	#ifdef Z_TEXTURE_MANAGER_LOG

		#define Z_TEXTURE_MANAGER_PRINT_STATE

		#define Z_TEXTURE_MANAGER_LOG_OK "ZTextureManager Load File: "
		#define Z_TEXTURE_MANAGER_LOG_BIND "ZTextureManager File Is Bind: "
		#define Z_TEXTURE_MANAGER_LOG_ERROR "ZTextureManager Error File: "
	#endif

	#define Z_MATERIAL_MANAGER_LOG
	#ifdef Z_MATERIAL_MANAGER_LOG
		
		#define Z_MATERIAL_MANAGER_PRINT_STATE

		#define Z_MATERIAL_MANAGER_LOG_OK "ZMaterialManager Load File: "
		#define Z_MATERIAL_MANAGER_LOG_BIND "ZMaterialManager File Is Bind: "
		#define Z_MATERIAL_MANAGER_LOG_ERROR "ZMaterialManager Error File: "
	#endif

	#define Z_LIGHT_MANAGER_LOG
	#ifdef Z_LIGHT_MANAGER_LOG
		
		#define Z_LIGHT_MANAGER_PRINT_STATE
		#define Z_LIGHT_MANAGER_DRAW_LIGHT			

		#define Z_LIGHT_MANAGER_LOG_OK "ZLightManager Load File: "
		#define Z_LIGHT_MANAGER_LOG_ERROR "ZLightManager Error File: "
	#endif

	#define Z_CG_PROGRAM_MANAGER_LOG
	#ifdef Z_CG_PROGRAM_MANAGER_LOG
		
		#define Z_CG_PROGRAM_MANAGER_PRINT_STATE
		#define Z_CG_FILE_NAME_ERROR "Data/Log/CgError.txt"

		#define Z_CG_PROGRAM_MANAGER_LOG_OK "ZProgramManager Load File: "
		#define Z_CG_PROGRAM_MANAGER_LOG_BIND "ZProgramManager File Is Bind: "
		#define Z_CG_PROGRAM_MANAGER_LOG_ERROR "ZProgramManager Error File: "
	#endif

#endif