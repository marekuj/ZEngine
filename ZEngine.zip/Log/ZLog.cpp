#include "ZLog.h"

#include <fstream>
using std::ofstream;
using std::endl;
using std::ios;

#ifdef Z_ENABLE_LOG
void ZPrintBeginLog(const char* FileName)
{
	ofstream File;
	File.open(FileName,ios::app);
	File<<endl
		<<"ZEngine Compilation version: "<<__DATE__<<' '<<__TIME__
		<<endl;
	File.close();
}
void ZPrintChapterLog(const char* FileName,const char* AddLog,const char* AddFileName)
{
	ofstream File;
	File.open(FileName,ios::app);
	File<<endl
		<<AddLog<<AddFileName<<endl;
	File.close();
}
void ZPrintLog(const char* FileName,const char* AddLog,const char* AddFileName)
{
	ofstream File;
	File.open(FileName,ios::app);
	File<<"->"<<AddLog<<AddFileName<<endl;
	File.close();
}
#endif