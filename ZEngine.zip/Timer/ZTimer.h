#pragma once

#include <windows.h>

class ZTimer
{
private:
	LARGE_INTEGER StartTime;
	LARGE_INTEGER TicksPerSecond;
	LARGE_INTEGER CurrentTime;
	float Frames;
public:
	ZTimer(void);
	~ZTimer(void);
	bool ZSet(void);			//(0 - ok | 1 - error) 
	float ZGetSeconds(void);
	void ZAddFrames(void);
	float ZGetFPS(float UpTime=1.0f);//UpTime okres  aktualizacji danych
};
