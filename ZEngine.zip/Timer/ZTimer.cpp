#include "ZTimer.h"

ZTimer::ZTimer(void)
{
	StartTime.QuadPart=0;
	TicksPerSecond.QuadPart=0;
	CurrentTime.QuadPart=0;
	Frames=0;
}
ZTimer::~ZTimer(void)
{
}
bool ZTimer::ZSet(void)
{
	if (!QueryPerformanceFrequency(&TicksPerSecond))
	{
		return true;
	}
	QueryPerformanceCounter(&StartTime);
	return false;
}
float ZTimer::ZGetSeconds(void)
{
	static LARGE_INTEGER LastTime=StartTime;
	static float Seconds=0;	
	QueryPerformanceCounter(&CurrentTime);
	Seconds=((float)CurrentTime.QuadPart-(float)LastTime.QuadPart)/(float)TicksPerSecond.QuadPart;
	LastTime=CurrentTime;
	return Seconds;
}
void ZTimer::ZAddFrames(void)
{
	Frames++;
}
float ZTimer::ZGetFPS(float UpTime)
{
	static LARGE_INTEGER LastTime=StartTime;
	static float LocalTime=0;
	static float Seconds=0;	
	static float Fps=0;
	QueryPerformanceCounter(&CurrentTime);
	Seconds=((float)CurrentTime.QuadPart-(float)LastTime.QuadPart)/(float)TicksPerSecond.QuadPart;
	LocalTime+=Seconds;
	if(LocalTime>=UpTime)
	{
		Fps=(float)Frames*(1.0f/Seconds);
		LastTime=CurrentTime;
		Frames=0;
		LocalTime=0;
	}
	return Fps;
}